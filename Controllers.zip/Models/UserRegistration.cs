﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace UPPCL_WebAPI.Models
{
    public class User
    {

        [Required(ErrorMessage = "Name Field is Required", AllowEmptyStrings = false)]
        public string Name { get; set; }

        [DataType(DataType.Date), DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        public Nullable<System.DateTime> Dob { get; set; }

        [Required(ErrorMessage = "EmailId Field is Required", AllowEmptyStrings = false)]
        public string EmailId { get; set; }

        [Required(ErrorMessage = "MobileNo Field is Required", AllowEmptyStrings = false)]
        public string MobileNo { get; set; }
    }
    public class UserMaster
    {
        public string Name { get; set; }
        public DateTime Dob { get; set; }
        public string EmailId { get; set; }
        public string MobileNo { get; set; }
        public string Password { get; set; }
        public string UserType { get; set; }
        public string ClientIPAddress { get; set; }
        public string PasswordEncrypt { get; set; }
    }
    public class RegisteredUser
    {
        public object UserId { get; set; }
        public string LoginId { get; set; }
        public string MobileNo { get; set; }
        public string Message { get; set; }
    }
    public class DisplayMessage
    {
        public string Message { get; set; }
        public string Type { get; set; }

    }
    public class UserLoginmaster
    {
        public string Password { get; set; }
        public Int64 UserId { get; set; }
        public string Name { get; set; }
        public int? IsBlock { get; set; }
        public string EmailId { get; set; }
        public string UserType { get; set; }
        public string LoginId { get; set; }
        public string Dob { get; set; }
        public string ExternalUserId { get; set; }
        public Int64 ApplicationId { get; set; }
        public string ProfilePic { get; set; }
        public int? logincount { get; set; }
        public bool? Descom1912 { get; set; }
        public string MobileNo { get; set; }


    }
    public class UserLogin
    {
        [Required(ErrorMessage = "LoginidOrMobile Field is Required", AllowEmptyStrings = false)]
        [DisplayName("Email or Mobile")]
        public string LoginidOrMobile { get; set; }

        [Required(ErrorMessage = "Password Field is Required", AllowEmptyStrings = false)]
        public string Password { get; set; }
    }
    public class ForgetPass
    {
        [Required(ErrorMessage = "LoginId Field is Required", AllowEmptyStrings = false)]
        [DisplayName("LoginId or Mobile")]
        public string LoginId { get; set; }

    }
    public class OTPVerification
    {
        [Required(ErrorMessage = "OTP Field is Required", AllowEmptyStrings = false)]
        public string OTP { get; set; }
    }
    public class ChangePassword
    {

        [Required(ErrorMessage = "NewPassword Field is Required", AllowEmptyStrings = false)]
        public string NewPassword { get; set; }

        [Required(ErrorMessage = "ConfirmPassword Field is Required", AllowEmptyStrings = false)]
        [Compare("NewPassword")]
        public string ConfirmPassword { get; set; }
    }
}