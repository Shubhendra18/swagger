﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using UPPCL_WebAPI.Models;
namespace UPPCL_WebAPI.Models
{
    public class UPPCLContext : DbContext
    {
        public UPPCLContext()
            : base("EODBModule")
        {
        }

        public RegisteredUser CreateUser(UserMaster model)
        {

            var sqlParam = new SqlParameter[] { 
                new SqlParameter {ParameterName="@Name",Value=model.Name},
                new SqlParameter {ParameterName="@Dob",Value=model.Dob},
                new SqlParameter {ParameterName="@MobileNo",Value=model.MobileNo},
                new SqlParameter {ParameterName="@EmailId",Value=model.EmailId},
                new SqlParameter {ParameterName="@Password",Value=model.Password}, 
                new SqlParameter {ParameterName="@UserType",Value=model.UserType},   
                new SqlParameter {ParameterName="@ClientIPAddress",Value=model.ClientIPAddress},   
                new SqlParameter {ParameterName="@PasswordEncrypt",Value=model.PasswordEncrypt},   
                 };
            var sqlQuery = @"Proc_InsertRegistrationDetails @Name,@Dob,@MobileNo,@EmailId,@Password,@UserType,@ClientIPAddress,@PasswordEncrypt";
            var res = this.Database.SqlQuery<RegisteredUser>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }
        public UserLoginmaster LoginUser(string LoginId)
        {
            var sqlParam = new SqlParameter[] { 
                new SqlParameter {ParameterName="@LoginId",Value=LoginId}
                 };
            var sqlQuery = @"Proc_getUserLogin @LoginId";
            var res = this.Database.SqlQuery<UserLoginmaster>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }
        public UserLoginmaster ForgetPassword(string LoginId)
        {
            var sqlParam = new SqlParameter[] { 
                new SqlParameter {ParameterName="@LoginId",Value=LoginId}
                 };
            var sqlQuery = @"Proc_getProfileDetails_LoginId @LoginId";
            var res = this.Database.SqlQuery<UserLoginmaster>(sqlQuery, sqlParam).FirstOrDefault();
            return res;

        }

    }
}