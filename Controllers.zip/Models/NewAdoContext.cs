﻿using Microsoft.Practices.EnterpriseLibrary.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Web;
using System.Web.Configuration;
using System.Web.UI.WebControls;

namespace UPPCL_WebAPI.Models
{
    public class NewAdoContext
    {
        SqlConnection con;
        SqlCommand cmd;
        SqlDataAdapter adp;
        public NewAdoContext()
        {
            string connString = WebConfigurationManager.ConnectionStrings["EODBModule"].ConnectionString;
            con = new SqlConnection(connString);
        }
        #region OTP

        public Int64 InsertOTP(string OTP, string OTPFor, string IPAddress, string mobileno, string SmsText, string smsStatus, Int64 ApplicationId, Int64 TransId, string LoginId, int flag)
        {

            int result = 0;
            SqlCommand cmd = new SqlCommand();
            DataTable dt = new DataTable();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "PROC_OTPLogsWithSMSLogs";
            cmd.Parameters.Add("@TransId", SqlDbType.BigInt).Value = TransId;
            cmd.Parameters.Add("@LoginId", SqlDbType.VarChar).Value = LoginId;
            cmd.Parameters.Add("@OTP", SqlDbType.VarChar).Value = OTP;
            cmd.Parameters.Add("@OTPFor", SqlDbType.VarChar).Value = OTPFor;
            cmd.Parameters.Add("@IPAddress", SqlDbType.VarChar).Value = IPAddress;
            cmd.Parameters.Add("@MobileNo", SqlDbType.VarChar).Value = mobileno;
            cmd.Parameters.Add("@SMSText", SqlDbType.VarChar).Value = SmsText;
            cmd.Parameters.Add("@SMSStatus", SqlDbType.VarChar).Value = smsStatus;
            cmd.Parameters.Add("@ApplicationId", SqlDbType.BigInt).Value = ApplicationId;
            cmd.Parameters.Add("@Flag", SqlDbType.Int).Value = flag;
            cmd.Parameters.Add("@Msg", SqlDbType.Int);
            cmd.Parameters["@Msg"].Direction = ParameterDirection.Output;



            cmd.Connection = con;
            con.Open();
            try
            {
                //SqlDataAdapter adp = new SqlDataAdapter(cmd);
                //adp.Fill(dt);
                cmd.ExecuteNonQuery();
                result = Convert.ToInt32(cmd.Parameters["@Msg"].Value);
                con.Close();
            }
            catch (Exception ex)
            {
                con.Close();
            }
            return result;
        }

        public Int64 CheckOTP(string OTP, Int64 TransId, string LoginId, int flag)
        {

            DataTable dt = new DataTable();
            string _proc = "PROC_OTPLogsWithSMSLogs";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDbCommand = objDatabase.GetStoredProcCommand(_proc);
            objDatabase.AddInParameter(objDbCommand, "@TransId", DbType.Int64, TransId);
            objDatabase.AddInParameter(objDbCommand, "@LoginId", DbType.String, LoginId);
            objDatabase.AddInParameter(objDbCommand, "@OTP", DbType.String, OTP);
            objDatabase.AddInParameter(objDbCommand, "@OTPFor", DbType.String, "");
            objDatabase.AddInParameter(objDbCommand, "@IPAddress", DbType.String, "");
            objDatabase.AddInParameter(objDbCommand, "@MobileNo", DbType.String, "");
            objDatabase.AddInParameter(objDbCommand, "@SMSText", DbType.String, "");
            objDatabase.AddInParameter(objDbCommand, "@SMSStatus", DbType.String, "");
            objDatabase.AddInParameter(objDbCommand, "@ApplicationId", DbType.Int64, 0);
            objDatabase.AddInParameter(objDbCommand, "@Flag", DbType.Int32, flag);
            objDatabase.AddInParameter(objDbCommand, "@Msg", DbType.Int32, 0);
            //cmd.Parameters["@Msg"].Direction = ParameterDirection.Output;
            try
            {
                IDataReader dr = objDatabase.ExecuteReader(objDbCommand);
                dt.Load(dr);
            }
            catch
            {
                dt = null;
            }
            return Convert.ToInt64(dt.Rows[0][0].ToString());
        }

        #endregion


        public int InserSMSLog(string mobileno, string SmsText, string smsStatus, Int64 ApplicationId)
        {
            int result = 0;
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "PROC_SMSLog";
            cmd.Parameters.Add("@MobileNo", SqlDbType.VarChar).Value = mobileno;
            cmd.Parameters.Add("@SMSText", SqlDbType.VarChar).Value = SmsText;
            cmd.Parameters.Add("@SMSStatus", SqlDbType.VarChar).Value = smsStatus;
            cmd.Parameters.Add("@ApplicationId", SqlDbType.BigInt).Value = ApplicationId;
            cmd.Connection = con;
            con.Open();
            try
            {
                result = cmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception ex)
            {
                con.Close();
            }
            return result;
        }

        public static int InserEmailLog(string mailTo, string MailCC, string MailSub, string MailBody, Boolean Status, string ResponceMessage)
        {
            int result = 0;

            SqlConnection con = new SqlConnection();
            string connString = WebConfigurationManager.ConnectionStrings["EODBModule"].ConnectionString;
            con = new SqlConnection(connString);

            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "Procs_InsertEmailLogDetails";
            cmd.Parameters.Add("@MailTo", SqlDbType.VarChar).Value = mailTo;
            cmd.Parameters.Add("@MailCC", SqlDbType.VarChar).Value = MailCC;
            cmd.Parameters.Add("@MailSub", SqlDbType.VarChar).Value = MailSub;
            cmd.Parameters.Add("@MailBody", SqlDbType.VarChar).Value = MailBody;
            cmd.Parameters.Add("@Status", SqlDbType.Bit).Value = Status;
            cmd.Parameters.Add("@ResponceMessage", SqlDbType.VarChar).Value = ResponceMessage;

            cmd.Connection = con;
            con.Open();
            try
            {
                result = cmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception ex)
            {
                con.Close();
            }
            return result;
        }

        public static string ServerName
        {
            get
            {
                String _ServerName = System.Configuration.ConfigurationManager.ConnectionStrings["ServerName"].ConnectionString;
                if (String.IsNullOrEmpty(_ServerName))
                    return "Admin";

                else
                    return _ServerName;
            }
        }

        public static DataTable YearList()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("yearId");
            dt.Columns.Add("YearName");
            for (int i = 2016; i <= DateTime.Now.Year; i++)
            {
                DataRow dr = dt.NewRow();
                dr["yearId"] = i;
                dr["YearName"] = i;
                dt.Rows.Add(dr);
            }
            return dt;
        }

        public string EncodeTo64(string toEncode)
        {
            try
            {
                byte[] toEncodeAsBytes = System.Text.Encoding.Unicode.GetBytes(toEncode);
                string returnValue = System.Convert.ToBase64String(toEncodeAsBytes);
                return returnValue;
            }
            catch (Exception ex) { return ex.Message; }
        }

        public string DecodeFrom64(string encodedData)
        {
            try
            {
                byte[] encodedDataAsBytes = System.Convert.FromBase64String(encodedData);
                string returnValue = System.Text.Encoding.Unicode.GetString(encodedDataAsBytes);
                return returnValue;
            }
            catch (Exception ex) { return ex.Message; }
        }

        public string FillCapctha()
        {
            try
            {

                Random random = new Random();

                string combination = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";

                StringBuilder captcha = new StringBuilder();

                for (int i = 0; i < 6; i++)
                {
                    captcha.Append(combination[random.Next(combination.Length)]);
                }

                return captcha.ToString().ToUpper();

                //imgCaptcha.ImageUrl = "GenerateCaptcha.aspx?" + DateTime.Now.Ticks.ToString();

            }
            catch (Exception ex)
            {
                return "";
            }
        }

        public DataTable GetApplicantDetailsByAppid(Int64 ApplicantID)
        {
            DataTable dt = new DataTable();
            string _proc = "Procs_GetApplicantDetailsByApplicantId";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDbCommand = objDatabase.GetStoredProcCommand(_proc);
            objDatabase.AddInParameter(objDbCommand, "@ApplicantID", DbType.Int64, ApplicantID);

            try
            {
                IDataReader dr = objDatabase.ExecuteReader(objDbCommand);
                dt.Load(dr);
            }
            catch
            {
                dt = null;
            }
            return dt;
        }

        #region Query_Aditi
        public DataTable GetApplicantDetailsByAppidForQuery(Int64 ApplicantID, string currentStep)
        {
            DataTable dt = new DataTable();
            string _proc = "Procs_GetApplicantDetailsByApplicantIdForQuery";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDbCommand = objDatabase.GetStoredProcCommand(_proc);
            objDatabase.AddInParameter(objDbCommand, "@ApplicantID", DbType.Int64, ApplicantID);
            objDatabase.AddInParameter(objDbCommand, "@currentStep", DbType.String, currentStep);
            try
            {
                IDataReader dr = objDatabase.ExecuteReader(objDbCommand);
                dt.Load(dr);
            }
            catch
            {
                dt = null;
            }
            return dt;
        }
        #endregion


        public DataSet GetPaymentDetailsByAppId(Int64 ApplicantID)
        {
            DataSet ds = new DataSet();
            string _proc = "Proc_GetPaymentDetailsByAppId";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDbCommand = objDatabase.GetStoredProcCommand(_proc);
            objDatabase.AddInParameter(objDbCommand, "@ApplicantID", DbType.Int64, ApplicantID);

            try
            {
                ds = objDatabase.ExecuteDataSet(objDbCommand);
            }
            catch
            {
                ds = null;
            }
            return ds;
        }

        #region  convert in Hashcode
        public string SingleHashing(string value)
        {
            string hashCode = "";
            hashCode = System.Web.Security.FormsAuthentication.HashPasswordForStoringInConfigFile(value, "MD5");
            return hashCode;
        }

        public string doubleHashing(string value, string seed)
        {
            string newvalue = value + seed;
            string hashCode = "";
            hashCode = System.Web.Security.FormsAuthentication.HashPasswordForStoringInConfigFile(newvalue, "MD5");
            return hashCode;
        }


        #endregion

        /// <summary>
        /// Get Calc Parameters
        /// </summary>
        /// <param name="procId">procId=1 for Select feeder type </param>
        /// <param name="KeyId"></param>
        /// <param name="subKeyId"></param>
        /// <returns></returns>
        public DataTable getdataForWebServiceDropdowns(int procId, int KeyId = 0, int subKeyId = 0)
        {
            DataSet ds = new DataSet();
            string _proc = "Proc_BindDropdownListDatawithWebService";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDbCommand = objDatabase.GetStoredProcCommand(_proc);
            objDatabase.AddInParameter(objDbCommand, "@procId", DbType.Int32, procId);
            objDatabase.AddInParameter(objDbCommand, "@KeyId", DbType.Int32, KeyId);
            objDatabase.AddInParameter(objDbCommand, "@subKeyId", DbType.Int32, subKeyId);

            try
            {
                ds = objDatabase.ExecuteDataSet(objDbCommand);
                return ds.Tables[0];
            }
            catch
            {
                DataTable dt = new DataTable();
                return dt;
            }

        }

        //for Get MimeType of uploaded document 
        public string GetMimeType(string extension)
        {
            if (extension == null)
                throw new ArgumentNullException("extension");

            if (extension.StartsWith("."))
            {
                extension = extension.Substring(1);
            }
            switch (extension.ToLower())
            {
                case "jpeg": return "image/jpeg";
                case "jpg": return "image/jpeg";
                case "png": return "image/png";
                case "pdf": return "application/pdf";
                default: return "application/octet-stream";
            }
        }
        public int InserNiveshMitraSMSLog(string mobileno, string SmsText, string smsStatus, Int64 ApplicantID)
        {
            int result = 0;
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "Proc_InsertNiveshMitraSMSLog";
            cmd.Parameters.Add("@MobileNumber", SqlDbType.VarChar).Value = mobileno;
            cmd.Parameters.Add("@SentMessage", SqlDbType.VarChar).Value = SmsText;
            cmd.Parameters.Add("@SentStatus", SqlDbType.VarChar).Value = smsStatus;
            cmd.Parameters.Add("@ApplicantID", SqlDbType.BigInt).Value = ApplicantID;
            cmd.Connection = con;
            con.Open();
            try
            {
                result = cmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception ex)
            {
                con.Close();
            }
            return result;
        }

        #region Imam Ali

        public DataTable GetDivisionForForward(Int64 DivisionID)
        {
            DataTable dt = new DataTable();
            string _proc = "Procs_GetDivisionForForward";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDbCommand = objDatabase.GetStoredProcCommand(_proc);
            objDatabase.AddInParameter(objDbCommand, "@DivisionID", DbType.Int64, DivisionID);
            try
            {
                IDataReader dr = objDatabase.ExecuteReader(objDbCommand);
                dt.Load(dr);
            }
            catch
            {
                dt = null;
            }
            return dt;
        }

        public int UpdateDivisionForForward(string DivisionID, Int64 ApplicationId)
        {
            int result = 0;

            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "Procs_UpdateDivisionForForward";
            cmd.Parameters.Add("@DivisionID", SqlDbType.VarChar).Value = DivisionID;
            cmd.Parameters.Add("@ApplicationId", SqlDbType.BigInt).Value = ApplicationId;

            cmd.Connection = con;
            con.Open();
            try
            {
                result = cmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception ex)
            {
                con.Close();
            }
            return result;
        }

        public DataTable GetFeasibilityByAppid(Int64 ApplicationId)
        {
            DataTable dt = new DataTable();
            string _proc = "Procs_GetFeasibilityStatus";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDbCommand = objDatabase.GetStoredProcCommand(_proc);
            objDatabase.AddInParameter(objDbCommand, "@ApplicationID", DbType.Int64, ApplicationId);

            try
            {
                IDataReader dr = objDatabase.ExecuteReader(objDbCommand);
                dt.Load(dr);
            }
            catch
            {
                dt = null;
            }
            return dt;
        }
        #endregion

        #region EDistrictService
        #region Insert Send Request
        public int InsertSendRequest(string requestKey, string deptRegistrationId, string serviceResponse, string transIp)
        {

            int result = 0;
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "proc_InsertSendRequest_EDistrict";
            cmd.Parameters.Add("@requestKey", SqlDbType.VarChar).Value = requestKey;
            cmd.Parameters.Add("@deptRegistrationId", SqlDbType.VarChar).Value = deptRegistrationId;
            cmd.Parameters.Add("@serviceResponse", SqlDbType.VarChar).Value = serviceResponse;
            cmd.Parameters.Add("@transIp", SqlDbType.VarChar).Value = transIp;
            cmd.Connection = con;
            con.Open();
            try
            {
                result = cmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception ex)
            {
                con.Close();
            }
            return result;

        }
        #endregion

        #region Insert Send Request
        public int InsertSendResponse(string requestKey, string deptRegistrationId, string serviceResponse, string applicationNumber, string serviceCode, string applicationType, string transIp)
        {
            int result = 0;
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "proc_InsertSendResponse_EDistrict";
            cmd.Parameters.Add("@requestKey", SqlDbType.VarChar).Value = requestKey;
            cmd.Parameters.Add("@deptRegistrationId", SqlDbType.VarChar).Value = deptRegistrationId;
            cmd.Parameters.Add("@serviceResponse", SqlDbType.VarChar).Value = serviceResponse;
            cmd.Parameters.Add("applicationNumber", SqlDbType.VarChar).Value = applicationNumber;
            cmd.Parameters.Add("@serviceCode", SqlDbType.VarChar).Value = serviceCode;
            cmd.Parameters.Add("@applicationType", SqlDbType.VarChar).Value = applicationType;
            cmd.Parameters.Add("@transIp", SqlDbType.VarChar).Value = transIp;
            cmd.Connection = con;
            con.Open();
            try
            {
                result = cmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception ex)
            {
                con.Close();
            }

            return result;
        }
        #endregion
        #endregion

    }
}
