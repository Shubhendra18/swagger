﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace UPPCL_WebAPI.Models
{
    public class ApplicationFormModelStep1
    {
        public Int64 ApplicationId { get; set; }
        public string DiscomId { get; set; }
        public string DistrictId { get; set; }
        public string DivisionId { get; set; }
        public string ApplicationNo { get; set; }
        public string ApplicantName { get; set; }
        public string FatherHusbandName { get; set; }
        public string ApplicantPicUrl { get; set; }
        public string Occupation { get; set; }
        public string CHouseno { get; set; }
        public string CBulidingname { get; set; }
        public string CArea { get; set; }
        public string CommunicationAddres { get; set; }
        public string CPincode { get; set; }
        public string CPhoneNo { get; set; }
        public string ConnHouseno { get; set; }
        public string ConnBulidingname { get; set; }
        public string ConnArea { get; set; }
        public string ConnectionAddress { get; set; }
        public string ConnPincode { get; set; }
        public string ConnPhoneNo { get; set; }
        public string PHouseno { get; set; }
        public string PBulidingname { get; set; }
        public string PArea { get; set; }
        public string PermanentAddress { get; set; }
        public string PPincode { get; set; }
        public string PPhnoneNo { get; set; }
        public decimal PlotSizesqft { get; set; }
        public decimal CoveredAreasqft { get; set; }
        public decimal LoadKVA { get; set; }
        public string SupplyPurpose { get; set; }
        public string VoltRatioCapacityDistance { get; set; }
        public string WorkCompltitionCertificateUrl { get; set; }
        public int evidencetype { get; set; }
        public string rentAggrType { get; set; }
        public string rentUrl { get; set; }
        public string DocumentaryEvidUrl { get; set; }
        public string ipaddress { get; set; }
        public Int64 UserId { get; set; }
        public decimal Amount { get; set; }
        public string NearestEletricitySubstation { get; set; }
        public bool? isBPL { get; set; }
        public string BPLUrl { get; set; }
        public string MotherName { get; set; }
        public int IdProofType { get; set; }
        public string IdProofUrl { get; set; }
        public string IDnumber { get; set; }
        public string ResponsiblePerson { get; set; }
        public string appRequestKey { get; set; }
        public string CommDistrict { get; set; }
        public string PermanentDistrict { get; set; }
        public string ConnDistrict { get; set; }
        public string Gender { get; set; }
        public bool? IsMartialStatus { get; set; }

    }

    public class ImageData
    {
        public string Caption { get; set; }
        public string PicUrl { get; set; }
    }
}