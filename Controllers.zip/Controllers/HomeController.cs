﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using UPPCL_WebAPI.Models;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using UPPCL_WebAPI.Filters;
using AttributeRouting;
using AttributeRouting.Web.Http;
using System.IO;
using System.Data;
using System.Web.Security;
using System.Text;
namespace UPPCL_WebAPI.Controllers
{
    [RoutePrefix("uppcl")]
    public class HomeController : ApiController
    {
        DisplayMessage displayMessage = new DisplayMessage();
        Common objCom = new Common();
        UPPCLContext da = new UPPCLContext();
        clsDivision objdiv = new clsDivision();

        /// <summary>
        /// Submit User Details For Registration
        /// </summary>
        /// <remarks>
        /// All Fields Are Required,DOB must be a datetime type,Email and Mobile Should be Unique.
        /// </remarks>
        /// <param name="user">
        /// Submit The Values for user take reference from example value
        /// </param>
        /// <returns></returns>
        [ValidateModel]
        [HttpRoute("SignUp")]
        public HttpResponseMessage PostUserRegistraion(User user)
        {
            string Pasword = RandomPassword.Generate(7, 9);
            string enryptPassword = objCom.SingleHashing(Pasword);
            RegisteredUser data = null;
            if (ModelState.IsValid)
            {
                UserMaster userMaster = new UserMaster();
                userMaster.Name = user.Name;
                userMaster.EmailId = user.EmailId;
                userMaster.MobileNo = user.MobileNo;
                userMaster.Dob = Convert.ToDateTime(user.Dob);
                userMaster.Password = Pasword;
                userMaster.UserType = "A";
                userMaster.ClientIPAddress = Common.GetIPAddress();
                userMaster.PasswordEncrypt = enryptPassword;
                data = da.CreateUser(userMaster);
                if (data != null)
                {
                    if (data.Message != "This Mobile No. is already Exists" && data.Message != "This Email is already Exists")
                    {
                        displayMessage.Message = "Your Registration for Applying for New Electricity Connection is done successfully";
                        displayMessage.Type = "succ001";
                        // HttpContext.Current.Session["Message"] = "Your Registration for Applying for New Electricity Connection is done successfully and your Login Credentials (Login ID & Password) have been sent to your registered Mobile No.( xxxxxx" + data.MobileNo.ToString().Substring(data.MobileNo.ToString().Length - 4) + ")";
                        sendMailMsg(data.LoginId, Pasword, user.Name, user.MobileNo, user.EmailId);
                        return Request.CreateResponse(HttpStatusCode.Created, displayMessage);
                    }
                    else
                    {
                        HttpError myCustomError = new HttpError(data.Message) { { "Type", "warn003" } };
                        return Request.CreateErrorResponse(HttpStatusCode.NotAcceptable, myCustomError);
                    }
                }
                else
                {
                    HttpError myCustomError = new HttpError("Something went wrong user can't Register now please try again letter") { { "Type", "warn003" } };
                    return Request.CreateErrorResponse(HttpStatusCode.BadRequest, myCustomError);
                }
            }
            else
            {
                HttpError myCustomError = new HttpError("User Not Created") { { "Type", "warn003" } };
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, myCustomError);
            }
        }

        /// <summary>
        /// Submit LoginId Or Mobile and Password to Check User Login
        /// </summary>
        /// <remarks>
        /// All Fields Are Required,Submit LoginId/Mobile and Password that is given to user mobile
        /// </remarks>
        /// <param name="userLogin">
        /// Submit The Values for userLogin take reference from example value
        /// </param>
        /// <returns></returns>
        [ValidateModel]
        [HttpRoute("SignIn")]
        public HttpResponseMessage PostUserSignIn(UserLogin userLogin)
        {
            UserLoginmaster dt = da.LoginUser(userLogin.LoginidOrMobile);
            if (dt != null && dt.UserType.ToString() == "A")
            {
                string dbpas = objCom.SingleHashing(userLogin.Password);
                if (dbpas == dt.Password)
                {
                    displayMessage.Message = "Login successfull";
                    displayMessage.Type = "succ001";
                    return Request.CreateResponse(HttpStatusCode.OK, new { displayMessage, dt.UserId, dt.UserType, dt.Name, dt.MobileNo, dt.EmailId, dt.Dob, dt.ProfilePic });
                }
                else
                {
                    HttpError myCustomError = new HttpError("Please Enter Valid Password") { { "Type", "warn003" } };
                    return Request.CreateErrorResponse(HttpStatusCode.NotFound, myCustomError);
                }
            }
            else
            {
                HttpError myCustomError = new HttpError("Please Enter Valid Login ID / Mobile Number") { { "Type", "warn003" } };
                return Request.CreateErrorResponse(HttpStatusCode.NotFound, myCustomError);
            }
        }

        /// <summary>
        /// Submit LoginId To Request Password Forget 
        /// </summary>
        /// <remarks>
        /// LoginId is Required Field,After Submiting User got A transaction ID
        /// </remarks>
        /// <param name="LoginId">
        /// Submit The Value for LoginId 
        /// </param>
        /// <returns></returns>
        [ValidateModel]
        [HttpRoute("ForgetPassowrd")]
        public HttpResponseMessage PostForgetPassowrd(string LoginId)
        {
            string type = "", loginId = "";
            UserLoginmaster data = null;

            data = da.ForgetPassword(LoginId);
            loginId = LoginId;
            type = "A";
            if (MailMsg.CheckOTP("123456", 0, LoginId, 3) > 3)
            {
                HttpError myCustomError = new HttpError("You have exceeded the number of allowed OTP Request attempts. Please try next day") { { "Type", "warn003" } };
                return Request.CreateErrorResponse(HttpStatusCode.NotAcceptable, myCustomError);
            }
            else
            {
                if (data != null)
                {
                    if (!String.IsNullOrEmpty(data.MobileNo.ToString()) && data.MobileNo.ToString().Length == 10)
                    {
                        string otp = CreateOTP_Numeric();
                        string msgString = "OTP is " + otp + " for reset your password. Do not share the otp and password with any one for security reasons-" + Common.ServerName;
                        string status = MailMsg.SMSSend(msgString, data.MobileNo.ToString().Trim(), true);

                        Int64 transId = MailMsg.InsertOTP(otp, type, Common.GetIPAddress(), data.MobileNo.ToString().Trim(), msgString, status, SessionManager.ApplicantId, 0, loginId, 1);
                        if (status.Trim().ToLower() == "success" || true)
                        {
                            //HttpContext.Current.Session["Key"] = data.UserId;
                            if (transId > 0)
                            {
                                //Session["OTPsuccessmsg"] = "An OTP has been sent to your registered Mobile No. Please fill and submit that OTP in the respective field to proceed.";
                                //Session["UType"] = type;
                                //Response.Redirect("~/frmResetPasswordWithOTP.aspx?Key=ytFcz");
                                displayMessage.Message = "An OTP has been sent to your registered Mobile No. Please fill and submit that OTP in the respective field to proceed.Redirecting to OtpVerification Page";
                                displayMessage.Type = "succ001";
                                return Request.CreateResponse(HttpStatusCode.OK, new { displayMessage, transId, data.UserId });
                            }
                            else
                            {
                                HttpError myCustomError = new HttpError("Try Again Later") { { "Type", "warn003" } };
                                return Request.CreateErrorResponse(HttpStatusCode.NotAcceptable, myCustomError);
                            }
                        }
                        else
                        {
                            HttpError myCustomError = new HttpError("The SMS Service is not working Properly kindly go throw other option for Reset password.") { { "Type", "warn003" } };
                            return Request.CreateErrorResponse(HttpStatusCode.NotAcceptable, myCustomError);
                        }
                    }
                    else
                    {
                        HttpError myCustomError = new HttpError("Your Mobile No. is not mapped with your account, please contact to your 'Department' OR 'Administration' for mapped Mobile No.") { { "Type", "warn003" } };
                        return Request.CreateErrorResponse(HttpStatusCode.NotAcceptable, myCustomError);
                    }

                }
                else
                {
                    HttpError myCustomError = new HttpError("Account Not Exist.") { { "Type", "warn003" } };
                    return Request.CreateErrorResponse(HttpStatusCode.NotFound, myCustomError);
                }
            }
        }


        /// <summary>
        /// Enter The OTP For The Forget Password That is given to the User Mobile
        /// </summary>
        /// <remarks>
        /// OTP and TransactionId is Required Field,After Submiting User Can Reset The Password
        /// </remarks>
        /// <param name="LoginId">
        /// Submit The Value for LoginId 
        /// </param>
        /// <param name="otp">Submit The OTP</param>
        /// <param name="TransactionId">Submit Transaction ID</param>
        /// <returns></returns>
        [ValidateModel]
        [HttpRoute("OtpVerificationForForgetPassword")]
        public HttpResponseMessage PostOtpVerification(string otp, Int64 TransactionId)
        {
            //if (HttpContext.Current.Session["TransIdOTP"] == null)
            //{
            if (TransactionId == null)
            {
                HttpError myCustomError = new HttpError("Please Send Otp From Forget Password First") { { "Type", "warn003" } };
                return Request.CreateErrorResponse(HttpStatusCode.NotAcceptable, myCustomError);
            }
            // Int64 StransId = Convert.ToInt64(HttpContext.Current.Session["TransIdOTP"].ToString());
            Int64 StransId = Convert.ToInt64(TransactionId);

            Int64 transId = MailMsg.InsertOTP(otp, "", Common.GetIPAddress(), "", "", "", 0, StransId, "", 2);
            if (MailMsg.CheckOTP(otp, StransId, "", 2) == 1)
            {
                displayMessage.Message = "Your OTP has been verified. Kindly change your password to proceed.Redirecting to ResetPassword Page";
                displayMessage.Type = "succ001";
                return Request.CreateResponse(HttpStatusCode.OK, displayMessage);
            }
            else
            {
                HttpError myCustomError = new HttpError("Invalid OTP.") { { "Type", "warn003" } };
                return Request.CreateErrorResponse(HttpStatusCode.NotAcceptable, myCustomError);
            }
        }



        /// <summary>
        /// Submit Change Password Details for Reset The Password
        /// </summary>
        /// <remarks>
        /// All Fields are Required ,After Reset Passowrd User got a Confirmation Page
        /// </remarks>
        /// <param name="UserId">User ID</param>
        /// <param name="NewPassword">Submit New Password</param>
        /// <param name="ConfirmPassword">Confirm Your Password</param>
        /// <returns></returns>
        [ValidateModel]
        [HttpRoute("ResetPassword")]
        public HttpResponseMessage PostResetPassword(Int64 UserId, string NewPassword, string ConfirmPassword)
        {
            //int id = Convert.ToInt32(HttpContext.Current.Session["Key"]);
            if (UserId != 0)
            {

                string hashpwd = objCom.SingleHashing(NewPassword);
                int a = objdiv.updatePasswordBYuserId(NewPassword, hashpwd, UserId);
                if (a > 0)
                {
                    displayMessage.Message = "Password Changed Successfully.Redirecting to Login Page";
                    displayMessage.Type = "succ001";
                    return Request.CreateResponse(HttpStatusCode.OK, displayMessage);
                }
                else
                {
                    HttpError myCustomError = new HttpError("New password and Retype New Password must be same.") { { "Type", "warn003" } };
                    return Request.CreateErrorResponse(HttpStatusCode.NotAcceptable, myCustomError);
                }
            }
            else
            {
                HttpError myCustomError = new HttpError("User Id Can not be 0, Please Provide UserId") { { "Type", "warn003" } };
                return Request.CreateErrorResponse(HttpStatusCode.NotAcceptable, myCustomError);
            }
        }




        public string CreateOTP_Numeric()
        {

            Random random = new Random();

            int Size = 6;
            string input = "1234567890";
            StringBuilder builder = new StringBuilder();
            char ch;
            for (int i = 0; i < Size; i++)
            {
                ch = input[random.Next(0, input.Length)];
                builder.Append(ch);
            }
            return builder.ToString();

        }
        void sendMailMsg(string LoginId, string Password, string name, string mobile, string email)
        {
            try
            {
                string mailBody = "";
                // string msgString = "Thank you for registering on UPPCL website for new electricity connection. Your Login ID: " + LoginId + " and your Password: " + Password;
                string msgString = "Dear " + name + ", Your Registration for Applying for New Electricity Connection is done successfully. Your Login Details are Login ID: " + LoginId + " and Password: " + Password + ".";
                string status = MailMsg.SMSSend(msgString, mobile, true);
                //MailMsg.SMSLog(msgString, mobile, status, SessionManager.ApplicantId);
                StreamReader reader = new StreamReader(HttpContext.Current.Server.MapPath("~/EmailTemplets/Registration.html"));
                mailBody = reader.ReadToEnd();
                mailBody = mailBody.Replace("[User]", name);
                mailBody = mailBody.Replace("[UserName]", LoginId);
                mailBody = mailBody.Replace("[Password]", Password);
                MailMsg.sendMail(email, "", "Regarding Login Credentials for UPPCL, New Electricity Connection Web Portal", mailBody);

            }
            catch
            {

            }
        }

    }
}

