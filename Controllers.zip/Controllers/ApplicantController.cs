﻿using AttributeRouting;
using AttributeRouting.Web.Http;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Hosting;
using System.Web.Http;
using System.Web.Mvc;
using UPPCL_WebAPI.Filters;
using UPPCL_WebAPI.Models;

namespace UPPCL_WebAPI.Controllers
{
    [RoutePrefix("Applicant")]
    public class ApplicantController : ApiController
    {
        void sendMailMsg()
        {
            try
            {
                DataTable dt = objdiv.GetApplicantDetailsforMail(Convert.ToInt32(SessionManager.ApplicantId));

                #region Code TO send msg to Applicant
                string msgString = "Dear Applicant, Your application for New Electricity Connection is submitted and your Application No. is " + Convert.ToString(dt.Rows[0]["applicationNo"]) + ". Kindly pay processing fee within next 7 days otherwise your application shall be liable for rejection. " + Common.ServerName;

                string status = MailMsg.SMSSend(msgString, Convert.ToString(dt.Rows[0]["mobileno"]), true);
                MailMsg.SMSLog(msgString, Convert.ToString(dt.Rows[0]["mobileno"]), status, SessionManager.ApplicantId);
                #endregion
                string mailBody = "";
                StreamReader reader = new StreamReader(HostingEnvironment.MapPath("~/EmailTemplets/ApplicationForm.html"));
                mailBody = reader.ReadToEnd();
                mailBody = mailBody.Replace("[User]", Convert.ToString(dt.Rows[0]["ApplicantName"]));
                mailBody = mailBody.Replace("[ApplicationNo]", Convert.ToString(dt.Rows[0]["applicationNo"]));
                MailMsg.sendMail(Convert.ToString(dt.Rows[0]["EmailId"]), "", "Regarding Application form", mailBody);

            }
            catch
            {

            }

        }
        clsApplicant objApplicant = new clsApplicant();
        clsDivision objdiv = new clsDivision();
        Common objCommon = new Common();
        DisplayMessage displayMessage = new DisplayMessage();
        bool? isbPL;
        ///<summary>
        ///Submit Step1 Application Form Details
        ///</summary>
        ///<returns></returns>
        [ValidateModel]
        [HttpRoute("ApplicationFormStep1")]
        [FileOperationFilter.SwaggerFormAttribute()]

        public HttpResponseMessage PostUserRegistraion()
        {
            ApplicationFormModelStep1 model = new ApplicationFormModelStep1();
            var httpRequest = HttpContext.Current.Request;

            string HdnFDDocumentaryevidence = null;
            string hdnIdproof = null;
            string HdnFDWCCBLForm = null;
            string hdnUploadPhoto = null;
            string hdnBPL = null;
            string renturl = null;


            var BplCardFile = httpRequest.Files["BplCard"];
            var UserPicFile = httpRequest.Files["UserPic"];
            var EvidenceFile = httpRequest.Files["Evidence"];
            var IDProofFile = httpRequest.Files["IDProof"];
            var BLFormFile = httpRequest.Files["BLForm"];
            var renturlFile = httpRequest.Files["RentDoc"];


            hdnBPL = new String(Path.GetFileNameWithoutExtension(BplCardFile.FileName).Take(10).ToArray()).Replace(" ", "-");
            hdnUploadPhoto = new String(Path.GetFileNameWithoutExtension(UserPicFile.FileName).Take(10).ToArray()).Replace(" ", "-");
            HdnFDDocumentaryevidence = new String(Path.GetFileNameWithoutExtension(EvidenceFile.FileName).Take(10).ToArray()).Replace(" ", "-");
            hdnIdproof = new String(Path.GetFileNameWithoutExtension(IDProofFile.FileName).Take(10).ToArray()).Replace(" ", "-");
            HdnFDWCCBLForm = new String(Path.GetFileNameWithoutExtension(BLFormFile.FileName).Take(10).ToArray()).Replace(" ", "-");
            renturl = new String(Path.GetFileNameWithoutExtension(renturlFile.FileName).Take(10).ToArray()).Replace(" ", "-");


            hdnBPL = hdnBPL + DateTime.Now.ToString("yymmssfff") + Path.GetExtension(BplCardFile.FileName);
            hdnUploadPhoto = hdnUploadPhoto + DateTime.Now.ToString("yymmssfff") + Path.GetExtension(UserPicFile.FileName);
            HdnFDDocumentaryevidence = HdnFDDocumentaryevidence + DateTime.Now.ToString("yymmssfff") + Path.GetExtension(EvidenceFile.FileName);
            hdnIdproof = hdnIdproof + DateTime.Now.ToString("yymmssfff") + Path.GetExtension(IDProofFile.FileName);
            HdnFDWCCBLForm = HdnFDWCCBLForm + DateTime.Now.ToString("yymmssfff") + Path.GetExtension(BLFormFile.FileName);
            renturl = renturl + DateTime.Now.ToString("yymmssfff") + Path.GetExtension(renturlFile.FileName);


            BplCardFile.SaveAs(HttpContext.Current.Server.MapPath("~/uppclDocs/" + hdnBPL));
            UserPicFile.SaveAs(HttpContext.Current.Server.MapPath("~/uppclDocs/" + hdnUploadPhoto));
            EvidenceFile.SaveAs(HttpContext.Current.Server.MapPath("~/uppclDocs/" + HdnFDDocumentaryevidence));
            IDProofFile.SaveAs(HttpContext.Current.Server.MapPath("~/uppclDocs/" + hdnIdproof));
            BLFormFile.SaveAs(HttpContext.Current.Server.MapPath("~/uppclDocs/" + HdnFDWCCBLForm));
            renturlFile.SaveAs(HttpContext.Current.Server.MapPath("~/uppclDocs/" + renturlFile));


            model.ApplicationId = Convert.ToInt64(httpRequest["ApplicationId"]);
            model.DiscomId = "0";
            model.DistrictId = httpRequest["DistrictId"];
            model.DivisionId = httpRequest["DivisionId"];
            model.ApplicationNo = "";
            model.ApplicantName = httpRequest["ApplicantName"];
            model.FatherHusbandName = httpRequest["FatherHusbandName"];
            model.ApplicantPicUrl = "~/uppclDocs/" + hdnUploadPhoto;
            model.Occupation = httpRequest["Occupation"];
            model.CHouseno = httpRequest["CHouseno"];
            model.CBulidingname = httpRequest["CBulidingname"];
            model.CArea = httpRequest["CArea"];
            model.CommunicationAddres = "";
            model.CPincode = httpRequest["CPincode"];
            model.CPhoneNo = httpRequest["CPhoneNo"];
            model.ConnHouseno = httpRequest["ConnHouseno"];
            model.ConnBulidingname = httpRequest["ConnBulidingname"];
            model.ConnArea = httpRequest["ConnArea"];
            model.ConnectionAddress = "";
            model.ConnPincode = httpRequest["ConnPincode"];
            model.ConnPhoneNo = httpRequest["ConnPhoneNo"];
            model.PHouseno = httpRequest["PHouseno"];
            model.PBulidingname = httpRequest["PBulidingname"];
            model.PArea = httpRequest["PArea"];
            model.PermanentAddress = "";
            model.PPincode = httpRequest["PPincode"];
            model.PPhnoneNo = httpRequest["PPhnoneNo"];
            model.PlotSizesqft = Convert.ToDecimal(httpRequest["PlotSizesqft"]);
            model.CoveredAreasqft = Convert.ToDecimal(httpRequest["CoveredAreasqft"]);
            model.LoadKVA = Convert.ToDecimal(httpRequest["LoadKVA"]);
            model.SupplyPurpose = httpRequest["SupplyPurpose"];
            model.VoltRatioCapacityDistance = "";
            model.WorkCompltitionCertificateUrl = "~/uppclDocs/" + HdnFDWCCBLForm;
            model.evidencetype = Convert.ToInt32(httpRequest["evidencetype"]);
            model.rentAggrType = httpRequest["rentAggrType"];
            model.rentUrl = "~/uppclDocs/" + renturlFile;
            model.DocumentaryEvidUrl = "~/uppclDocs/" + HdnFDDocumentaryevidence;
            model.ipaddress = Common.GetIPAddress();
            model.UserId = Convert.ToInt64(httpRequest["UserId"]);
            model.Amount = 0;
            model.NearestEletricitySubstation = httpRequest["NearestEletricitySubstation"];
            model.isBPL = Convert.ToBoolean(httpRequest["isBPL"]);
            model.BPLUrl = "~/uppclDocs/" + hdnBPL;
            model.MotherName = httpRequest["MotherName"];
            model.IdProofType = Convert.ToInt32(httpRequest["IdProofType"]);
            model.IdProofUrl = "~/uppclDocs/" + hdnIdproof;
            model.IDnumber = httpRequest["IDnumber"];
            model.ResponsiblePerson = string.Empty;
            model.appRequestKey = string.Empty;
            model.CommDistrict = httpRequest["CommDistrict"];
            model.PermanentDistrict = httpRequest["PermanentDistrict"];
            model.ConnDistrict = httpRequest["ConnDistrict"];
            model.Gender = httpRequest["Gender"];
            model.IsMartialStatus = Convert.ToBoolean(httpRequest["IsMartialStatus"]);



            isbPL = null;
            if(model.isBPL != null)
            {
                isbPL = Convert.ToBoolean(Convert.ToInt32(model.isBPL));
            }
            int i = 0;
            if(model.isBPL == null)
            {
                i = 1;
            }

            if(!string.IsNullOrEmpty(model.ApplicantPicUrl) || SessionManager.Descom1912 == true)
            {
                if(!string.IsNullOrEmpty(model.DocumentaryEvidUrl) || SessionManager.Descom1912 == true)
                {
                    if(!string.IsNullOrEmpty(model.IdProofUrl) || SessionManager.Descom1912 == true)
                    {
                        if(!string.IsNullOrEmpty(model.BPLUrl) || SessionManager.Descom1912 == true)
                        {
                            string Flag = "";
                            if(model.SupplyPurpose == "1" && Convert.ToInt32(Convert.ToDecimal(model.LoadKVA)) > 1 && i == 1)
                            {
                                HttpError myCustomError = new HttpError("Max load allowed for BPL Consumer is 1KW.") { { "Type", "warn003" } };
                                return Request.CreateErrorResponse(HttpStatusCode.NotAcceptable, myCustomError);
                            }

                            else
                            {

                                if(model.SupplyPurpose == "3" && Convert.ToInt32(model.LoadKVA) > 9)
                                {
                                    HttpError myCustomError = new HttpError("Please visit to nivesh mitra portal for more than or equal 9KW load connection") { { "Type", "warn003" } };
                                    return Request.CreateErrorResponse(HttpStatusCode.NotAcceptable, myCustomError);
                                }
                                else if(model.BPLUrl == "1" && SessionManager.userType == "A")
                                {
                                    HttpError myCustomError = new HttpError("Please Upload BPL Document !") { { "Type", "warn003" } };
                                    return Request.CreateErrorResponse(HttpStatusCode.NotAcceptable, myCustomError);
                                }
                                else
                                {
                                    string CommnicationAddress = model.CHouseno + " ," + model.CBulidingname + " " + model.CArea;
                                    string PermanentAddress = model.PHouseno + " ," + model.PBulidingname + " " + model.PArea;
                                    string ConnectionAddress = model.ConnHouseno + " ," + model.ConnBulidingname + " " + model.ConnArea;
                                    DataTable dtResult =
                                        objApplicant.InsertUpdateApplicantFormDetails(
                                        model.ApplicationId,
                                        model.DiscomId,
                                        model.DistrictId,
                                        model.DivisionId,
                                        model.ApplicationNo,
                                        model.ApplicantName,
                                        model.FatherHusbandName,
                                        model.ApplicantPicUrl,
                                        model.Occupation,
                                        model.CHouseno,
                                        model.CBulidingname,
                                        model.CArea,
                                        CommnicationAddress,
                                        model.CPincode,
                                        model.CPhoneNo,
                                        model.ConnHouseno,
                                        model.ConnBulidingname,
                                        model.ConnArea,
                                        ConnectionAddress,
                                        model.ConnPincode,
                                        model.ConnPhoneNo,
                                        model.PHouseno,
                                        model.PBulidingname,
                                        model.PArea,
                                        PermanentAddress,
                                        model.PPincode,
                                        model.PPhnoneNo,
                                        model.PlotSizesqft,
                                        model.CoveredAreasqft,
                                        model.LoadKVA,
                                        model.SupplyPurpose,
                                        "",
                                        model.WorkCompltitionCertificateUrl,
                                           model.evidencetype,
                                           model.rentAggrType,
                                          model.rentUrl,
                                           model.DocumentaryEvidUrl,
                                           model.ipaddress,
                                           model.UserId,
                                           model.Amount,
                                           model.NearestEletricitySubstation,
                                           model.isBPL,
                                           model.BPLUrl,
                                           model.MotherName,
                                           model.IdProofType,
                                            model.IdProofUrl,
                                            model.IDnumber,
                                            model.ResponsiblePerson,
                                            model.appRequestKey,
                                            model.CommDistrict,
                                            model.PermanentDistrict,
                                            model.ConnDistrict,
                                           model.Gender,
                                            Convert.ToBoolean(model.IsMartialStatus));

                                    if(dtResult.Rows.Count > 0)
                                    {
                                        if(dtResult.Rows[0]["ApplicantId"].ToString() != "0" && dtResult.Rows[0]["Flag"].ToString() != "0")
                                        {
                                            if(!string.IsNullOrEmpty(SessionManager.AppRequestKey) && ConfigurationManager.AppSettings["AllowEDistrict"].ToString() == "Y")
                                            {
                                                EDistrictServiceClass ed = new EDistrictServiceClass();
                                                string applicationNum = dtResult.Rows[0]["ApplicationNo"].ToString();

                                                int serviceCode = Convert.ToInt32(EDistrict_ServiceCode.EP);
                                                bool result = ed.postServiceResponse(SessionManager.AppRequestKey, applicationNum, serviceCode.ToString(), "EP");

                                                if(result)
                                                {
                                                    objApplicant.InsertApplicationSteps(Convert.ToInt64(dtResult.Rows[0]["ApplicantId"].ToString()), "Step1");
                                                    objApplicant.UpdateApplicationSteps(Convert.ToInt64(dtResult.Rows[0]["ApplicantId"].ToString()), "Step1");

                                                    SessionManager.ApplicantId = Convert.ToInt64(dtResult.Rows[0]["ApplicantId"].ToString());

                                                    if(dtResult.Rows[0]["Flag"].ToString() == "2")
                                                    {
                                                        displayMessage.Message = "Record Updated Successfully ";
                                                        displayMessage.Type = "succ001";
                                                        Flag = "Upt";

                                                        return Request.CreateResponse(HttpStatusCode.OK, new { displayMessage, Flag });
                                                    }
                                                    if(dtResult.Rows[0]["Flag"].ToString() == "1")
                                                    {
                                                        displayMessage.Message = "Record Saved Successfully ";
                                                        displayMessage.Type = "succ001";
                                                        Flag = "New";

                                                        return Request.CreateResponse(HttpStatusCode.OK, new { displayMessage, Flag });
                                                    }
                                                    sendMailMsg();
                                                    displayMessage.Message = "frmSuccessReg.aspx";
                                                    displayMessage.Type = "succ001";
                                                    return Request.CreateResponse(HttpStatusCode.OK, new { displayMessage, Flag });
                                                    //Response.Redirect("frmSuccessReg.aspx?flg=" + Flag + "", false);
                                                }
                                                else
                                                {
                                                    HttpError myCustomError = new HttpError("Some Error Occur!") { { "Type", "warn003" } };
                                                    return Request.CreateErrorResponse(HttpStatusCode.BadRequest, myCustomError);
                                                }

                                            }
                                            else
                                            {
                                                objApplicant.InsertApplicationSteps(Convert.ToInt64(dtResult.Rows[0]["ApplicantId"].ToString()), "Step1");
                                                objApplicant.UpdateApplicationSteps(Convert.ToInt64(dtResult.Rows[0]["ApplicantId"].ToString()), "Step1");

                                                SessionManager.ApplicantId = Convert.ToInt64(dtResult.Rows[0]["ApplicantId"].ToString());

                                                if(dtResult.Rows[0]["Flag"].ToString() == "2")
                                                {

                                                    displayMessage.Message = "Record Updated Successfully";
                                                    displayMessage.Type = "succ001";
                                                    Flag = "Upt";

                                                    return Request.CreateResponse(HttpStatusCode.OK, new { displayMessage, Flag });
                                                }
                                                if(dtResult.Rows[0]["Flag"].ToString() == "1")
                                                {
                                                    displayMessage.Message = "Record Saved Successfully ";
                                                    displayMessage.Type = "succ001";
                                                    Flag = "New";

                                                    return Request.CreateResponse(HttpStatusCode.OK, new { displayMessage, Flag });
                                                }
                                                sendMailMsg();
                                                displayMessage.Message = "frmSuccessReg.aspx";
                                                displayMessage.Type = "succ001";
                                                return Request.CreateResponse(HttpStatusCode.OK, new { displayMessage, Flag });
                                                //Response.Redirect("frmSuccessReg.aspx?flg=" + Flag + "", false);
                                            }

                                        }
                                        else
                                        {
                                            HttpError myCustomError = new HttpError(dtResult.Rows[0]["Msg"].ToString()) { { "Type", "warn003" } };
                                            return Request.CreateErrorResponse(HttpStatusCode.BadRequest, myCustomError);
                                        }
                                    }

                                    else
                                    {
                                        HttpError myCustomError = new HttpError("Record Not Inserted Please Try Again !") { { "Type", "warn003" } };
                                        return Request.CreateErrorResponse(HttpStatusCode.BadRequest, myCustomError);
                                    }
                                }
                            }


                        }
                        else if(string.IsNullOrEmpty(model.BPLUrl) && model.SupplyPurpose == "1")
                        {
                            HttpError myCustomError = new HttpError("If B&L form is not available then please upload signed copy of Self-declaration form. To download the format of Self-declaration form <a href='../Content/writereaddata/PDF/selfdeclaration.pdf' target='_blank'>Click Here</a>!") { { "Type", "warn003" } };
                            return Request.CreateErrorResponse(HttpStatusCode.NotAcceptable, myCustomError);
                        }
                        else if(string.IsNullOrEmpty(model.BPLUrl) && model.SupplyPurpose != "1")
                        {
                            HttpError myCustomError = new HttpError("Please upload B&L form!") { { "Type", "warn003" } };
                            return Request.CreateErrorResponse(HttpStatusCode.NotAcceptable, myCustomError);
                        }
                    }
                    else if(string.IsNullOrEmpty(model.IdProofUrl))
                    {
                        HttpError myCustomError = new HttpError("Please Upload Id Proof !") { { "Type", "warn003" } };
                        return Request.CreateErrorResponse(HttpStatusCode.NotAcceptable, myCustomError);
                    }
                }

                else if(string.IsNullOrEmpty(model.DocumentaryEvidUrl))
                {
                    HttpError myCustomError = new HttpError("Please Upload Evidence Document !") { { "Type", "warn003" } };
                    return Request.CreateErrorResponse(HttpStatusCode.NotAcceptable, myCustomError);
                }
            }
            else if(string.IsNullOrEmpty(model.ApplicantPicUrl))
            {
                HttpError myCustomError = new HttpError("Please Upload Photo !") { { "Type", "warn003" } };
                return Request.CreateErrorResponse(HttpStatusCode.NotAcceptable, myCustomError);
            }

            return Request.CreateResponse(HttpStatusCode.Created);

        }















        //[ValidateModel]
        //[HttpRoute("upload")]
        //[FileOperationFilter.SwaggerFormAttribute()]
        //public HttpResponseMessage PostUserFile()
        //{
        //    string imageName = null;
        //    var httpRequest = HttpContext.Current.Request;
        //    var postedFile = httpRequest.Files["Image"];
        //    imageName = new String(Path.GetFileNameWithoutExtension(postedFile.FileName).Take(10).ToArray()).Replace(" ", "-");
        //    imageName = imageName + DateTime.Now.ToString("yymmssfff") + Path.GetExtension(postedFile.FileName);
        //    var filePath = HttpContext.Current.Server.MapPath("~/UploadData/" + imageName);
        //    postedFile.SaveAs(filePath);
        //    string name = httpRequest["ImageCaption"];
        //    //Save to DB

        //    return Request.CreateResponse(HttpStatusCode.Created);
        //}
    }

}
