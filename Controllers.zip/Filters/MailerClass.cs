﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net.Mail;
using System.Web;
namespace UPPCL_WebAPI.Filters
{
    /// <summary>
    /// Summary description for MailerClass
    /// </summary>
    public class MailerClass
    {
        public MailerClass()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        public string sendMail(string[] mailTo, string[] BCCMailID1, string[] mailCC, string mailFrom, string mailMsg, string mailSub)
        {
            MailMessage mlMsg = new MailMessage();
            SmtpClient smpt = new SmtpClient(ConfigurationManager.ConnectionStrings["MailServer"].ToString(), 25);

            if (ConfigurationManager.ConnectionStrings["MailUserID"].ToString() != "")
            {
                smpt.Credentials = new System.Net.NetworkCredential(ConfigurationManager.ConnectionStrings["MailUserID"].ToString(), ConfigurationManager.ConnectionStrings["MailUserPWD"].ToString());
            }


            foreach (string mt in mailTo)
            {
                if (mt != null)
                {
                    if (mt.Trim() != "")
                    {
                        mlMsg.To.Add(mt);
                    }
                }
            }

            if (BCCMailID1 != null)
            {
                foreach (var bcc in BCCMailID1)
                {
                    if (bcc != null)
                    {
                        if (bcc.Trim() != "")
                        {
                            mlMsg.Bcc.Add(bcc);
                        }
                    }
                }
            }

            if (mailCC != null)
            {
                foreach (var cc in mailCC)
                {
                    if (cc != null)
                    {
                        if (cc.Trim() != "")
                        {
                            mlMsg.CC.Add(cc);
                        }
                    }
                }
            }

            try
            {
                string[] cp = ConfigurationManager.ConnectionStrings["copyMail"].ConnectionString.Split(';');

                if (cp != null)
                {
                    foreach (var bcc in cp)
                    {
                        if (bcc != null)
                        {
                            if (bcc.Trim() != "")
                            {
                                mlMsg.Bcc.Add(bcc);
                            }
                        }
                    }
                }
            }
            catch (Exception t)
            {

            }


            mlMsg.From = new MailAddress(mailFrom);



            mlMsg.Body = mailMsg;
            mlMsg.Subject = mailSub;
            //mlMsg.BodyEncoding = System.Text.Encoding.Unicode;
            mlMsg.IsBodyHtml = true;

            try
            {
                smpt.Send(mlMsg);

                return "Success";
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public string sendMail(string[] mailTo, string[] BCCMailID1, string[] mailCC, string mailFrom, string mailMsg, string mailSub, string Attachment)
        {
            MailMessage mlMsg = new MailMessage();
            SmtpClient smpt = new SmtpClient(ConfigurationManager.ConnectionStrings["MailServer"].ToString(), 25);

            if (ConfigurationManager.ConnectionStrings["MailUserID"].ToString() != "")
            {
                smpt.Credentials = new System.Net.NetworkCredential(ConfigurationManager.ConnectionStrings["MailUserID"].ToString(), ConfigurationManager.ConnectionStrings["MailUserPWD"].ToString());
            }


            foreach (string mt in mailTo)
            {
                if (mt != null)
                {
                    if (mt.Trim() != "")
                    {
                        mlMsg.To.Add(mt);
                    }
                }
            }

            if (BCCMailID1 != null)
            {
                foreach (var bcc in BCCMailID1)
                {
                    if (bcc != null)
                    {
                        if (bcc.Trim() != "")
                        {
                            mlMsg.Bcc.Add(bcc);
                        }
                    }
                }
            }

            if (mailCC != null)
            {
                foreach (var cc in mailCC)
                {
                    if (cc != null)
                    {
                        if (cc.Trim() != "")
                        {
                            mlMsg.CC.Add(cc);
                        }
                    }
                }
            }

            try
            {
                string[] cp = ConfigurationManager.ConnectionStrings["copyMail"].ConnectionString.Split(';');

                if (cp != null)
                {
                    foreach (var bcc in cp)
                    {
                        if (bcc != null)
                        {
                            if (bcc.Trim() != "")
                            {
                                mlMsg.Bcc.Add(bcc);
                            }
                        }
                    }
                }
            }
            catch (Exception t)
            {

            }


            mlMsg.From = new MailAddress(mailFrom);
            if (Attachment != null)
            {
                try
                {
                    string Path = HttpContext.Current.Server.MapPath(Attachment);
                    mlMsg.Attachments.Add(new Attachment((Path)));
                }
                catch
                {
                }
            }
            mlMsg.Body = mailMsg;
            mlMsg.Subject = mailSub;
            mlMsg.BodyEncoding = System.Text.Encoding.Unicode;
            mlMsg.IsBodyHtml = true;

            try
            {
                smpt.Send(mlMsg);

                return "Success";
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }
}