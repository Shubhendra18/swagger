﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Http.Controllers;
using System.Web.Http.Filters;
using System.Net.Http;

namespace UPPCL_WebAPI.Filters
{
    public class ValidateModelAttribute : ActionFilterAttribute
    {
        public override void OnActionExecuting(HttpActionContext filterContext)
        {
            if (filterContext.ModelState.IsValid == false)
            {
                filterContext.Response = filterContext.Request.CreateErrorResponse(
                    HttpStatusCode.BadRequest, filterContext.ModelState
                    );
            }
        }
    }
}