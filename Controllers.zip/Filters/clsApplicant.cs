﻿using Microsoft.Practices.EnterpriseLibrary.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Web;
namespace UPPCL_WebAPI.Filters
{
    public class clsApplicant
    {
        public clsApplicant()
        {
            //
            // TODO: Add constructor logic here
            //
        }
        public DataTable getSDO()
        {
            DataTable dt = new DataTable();
            try
            {
                string proc_ = "proc_getALLSDO";
                Database objDatabase = DatabaseFactory.CreateDatabase();
                DbCommand objDbCommand = objDatabase.GetStoredProcCommand(proc_);
                IDataReader idr = objDatabase.ExecuteReader(objDbCommand);
                dt.Load(idr);


            }
            catch (Exception ex)
            {
                return null;
            }
            return dt;
        }
        public DataTable getAllEvidenceProof()
        {
            DataTable dt = new DataTable();
            try
            {
                string proc_ = "proc_getAllEvidence";
                Database objDatabase = DatabaseFactory.CreateDatabase();
                DbCommand objDbCommand = objDatabase.GetStoredProcCommand(proc_);
                IDataReader idr = objDatabase.ExecuteReader(objDbCommand);
                dt.Load(idr);

            }
            catch (Exception ex)
            {
                return null;
            }
            return dt;
        }
        public DataTable UpdatePaymentDetails(string ApplicationID, string Transaction_ID, string Transaction_DateTime)
        {
            DataTable dt = new DataTable();
            try
            {
                string proc_ = "Proc_UpdatePaymentDetails";
                Database objDatabase = DatabaseFactory.CreateDatabase();
                DbCommand objDbCommand = objDatabase.GetStoredProcCommand(proc_);
                objDatabase.AddInParameter(objDbCommand, "@ApplicationID", DbType.String, ApplicationID);
                objDatabase.AddInParameter(objDbCommand, "@Transaction_ID", DbType.String, Transaction_ID);
                objDatabase.AddInParameter(objDbCommand, "@Transaction_DateTime", DbType.String, Transaction_DateTime);

                IDataReader idr = objDatabase.ExecuteReader(objDbCommand);
                dt.Load(idr);

            }
            catch (Exception ex)
            {
                return null;
            }
            return dt;
        }

        public DataTable InsertUpdateApplicantFormDetails(
            Int64 ApplicationId,
            string DiscomId,
            string DistrictId,
            string DivisionId,
            string ApplicationNo,
            string ApplicantName,
            string FatherHusbandName,
            string ApplicantPicUrl,
            string Occupation,
            string CHouseno,
            string CBuildingname,
            string CArea,
            string CommunicationAddres,
            string CPincode,
            string CPhoneNo,
            string ConnHouseno,
            string ConnBuildingname,
            string ConnArea,
            string ConnectionAddress,
            string ConnPincode,
            string ConnPhoneNo,
            string PHouseno,
            string PBuildingname,
            string PArea,
            string PermanentAddress,
            string PPincode,
            string PPhnoneNo,
            decimal PlotSizesqft,
            decimal CoveredAreasqft,
            decimal LoadKVA,
            string SupplyPurpose,
            string VoltRatioCapacityDistance,
            string WorkCompltitionCertificateUrl,
            int evidencetype,
            string rentAggrType,
            string rentUrl,
            string DocumentaryEvidUrl,
            string ipaddress,
            Int64 UserId,
            decimal Amount,
            string NearestEletricitySubstation,
            bool? isBPL,
            string BPLUrl,
            string Mothername,
            int IDProofType,
            string docIdproofUrl,
            string IDnumber,
            string RespPerson,
            string appRequestKey,
            string CommDistrict,
            string PermanentDistrict,
            string SiteDistrict,
            string Gender,
            bool? IsMartialStatus)
        {
            DataTable dt = new DataTable();
            int result = 0;
            string _proc = "Procs_InsertUpdateApplicantFormDetails";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDbCommand = objDatabase.GetStoredProcCommand(_proc);

            objDatabase.AddInParameter(objDbCommand, "@ApplicationId", DbType.Int64, ApplicationId);
            objDatabase.AddInParameter(objDbCommand, "@DiscomId", DbType.String, DiscomId);
            objDatabase.AddInParameter(objDbCommand, "@DistrictId", DbType.String, DistrictId);
            objDatabase.AddInParameter(objDbCommand, "@DivisionId", DbType.String, DivisionId);
            objDatabase.AddInParameter(objDbCommand, "@ApplicationNo", DbType.String, ApplicationNo);

            objDatabase.AddInParameter(objDbCommand, "@ApplicantName", DbType.String, ApplicantName);
            objDatabase.AddInParameter(objDbCommand, "@FatherHusbandName", DbType.String, FatherHusbandName);
            objDatabase.AddInParameter(objDbCommand, "@ApplicantPicUrl", DbType.String, ApplicantPicUrl);
            objDatabase.AddInParameter(objDbCommand, "@Occupation", DbType.String, Occupation);
            objDatabase.AddInParameter(objDbCommand, "@CHouseno", DbType.String, CHouseno);
            objDatabase.AddInParameter(objDbCommand, "@CBulidingname", DbType.String, CBuildingname);
            objDatabase.AddInParameter(objDbCommand, "@CArea", DbType.String, CArea);
            objDatabase.AddInParameter(objDbCommand, "@CommunicationAddres", DbType.String, CommunicationAddres);
            objDatabase.AddInParameter(objDbCommand, "@CPincode", DbType.String, CPincode);

            objDatabase.AddInParameter(objDbCommand, "@CPhoneNo", DbType.String, CPhoneNo);
            objDatabase.AddInParameter(objDbCommand, "@ConnHouseno", DbType.String, ConnHouseno);
            objDatabase.AddInParameter(objDbCommand, "@ConnBulidingname", DbType.String, ConnBuildingname);
            objDatabase.AddInParameter(objDbCommand, "@ConnArea", DbType.String, ConnArea);
            objDatabase.AddInParameter(objDbCommand, "@ConnectionAddress", DbType.String, ConnectionAddress);
            objDatabase.AddInParameter(objDbCommand, "@ConnPincode", DbType.String, ConnPincode);
            objDatabase.AddInParameter(objDbCommand, "@ConnPhoneNo", DbType.String, ConnPhoneNo);

            objDatabase.AddInParameter(objDbCommand, "@PHouseno", DbType.String, PHouseno);
            objDatabase.AddInParameter(objDbCommand, "@PBulidingname", DbType.String, PBuildingname);
            objDatabase.AddInParameter(objDbCommand, "@PArea", DbType.String, PArea);


            objDatabase.AddInParameter(objDbCommand, "@PermanentAddress", DbType.String, PermanentAddress);
            objDatabase.AddInParameter(objDbCommand, "@PPincode", DbType.String, PPincode);
            objDatabase.AddInParameter(objDbCommand, "@PPhnoneNo", DbType.String, PPhnoneNo);
            objDatabase.AddInParameter(objDbCommand, "@PlotSizesqft", DbType.Decimal, PlotSizesqft);
            objDatabase.AddInParameter(objDbCommand, "@CoveredAreasqft", DbType.Decimal, CoveredAreasqft);
            objDatabase.AddInParameter(objDbCommand, "@LoadKVA", DbType.Decimal, LoadKVA);
            objDatabase.AddInParameter(objDbCommand, "@SupplyPurpose", DbType.String, SupplyPurpose);
            objDatabase.AddInParameter(objDbCommand, "@VoltRatioCapacityDistance", DbType.String, VoltRatioCapacityDistance);
            objDatabase.AddInParameter(objDbCommand, "@WorkCompltitionCertificateUrl", DbType.String, WorkCompltitionCertificateUrl);
            objDatabase.AddInParameter(objDbCommand, "@evidencetype", DbType.Int32, evidencetype);
            objDatabase.AddInParameter(objDbCommand, "@DocumentaryEvidUrl", DbType.String, DocumentaryEvidUrl);
            objDatabase.AddInParameter(objDbCommand, "@ipaddress", DbType.String, ipaddress);
            objDatabase.AddInParameter(objDbCommand, "@UserId", DbType.Int64, UserId);
            objDatabase.AddInParameter(objDbCommand, "@Amount", DbType.Decimal, Amount);
            objDatabase.AddInParameter(objDbCommand, "@NearestEletricitySubstation", DbType.String, NearestEletricitySubstation);
            objDatabase.AddInParameter(objDbCommand, "@isBPL", DbType.Boolean, isBPL);
            objDatabase.AddInParameter(objDbCommand, "@BPLUrl", DbType.String, BPLUrl);
            objDatabase.AddInParameter(objDbCommand, "@MotherName", DbType.String, Mothername ?? (object)DBNull.Value);
            objDatabase.AddInParameter(objDbCommand, "@IdProofType", DbType.Int32, IDProofType);
            objDatabase.AddInParameter(objDbCommand, "@IdProofUrl", DbType.String, docIdproofUrl);
            objDatabase.AddInParameter(objDbCommand, "@IDnumber", DbType.String, IDnumber);
            objDatabase.AddInParameter(objDbCommand, "@ResponsiblePerson", DbType.String, RespPerson ?? string.Empty);
            objDatabase.AddInParameter(objDbCommand, "@rentAggrType", DbType.String, rentAggrType != "0" ? rentAggrType : (object)DBNull.Value);
            objDatabase.AddInParameter(objDbCommand, "@rentUrl", DbType.String, rentUrl ?? string.Empty);
            objDatabase.AddInParameter(objDbCommand, "@appRequestKey", DbType.String, appRequestKey ?? string.Empty);
            objDatabase.AddInParameter(objDbCommand, "@CDistrict", DbType.String, CommDistrict);
            objDatabase.AddInParameter(objDbCommand, "@PDistrict", DbType.String, PermanentDistrict);
            objDatabase.AddInParameter(objDbCommand, "@ConnDistrict", DbType.String, SiteDistrict);
            objDatabase.AddInParameter(objDbCommand, "@Gender", DbType.String, Gender);
            objDatabase.AddInParameter(objDbCommand, "@IsMartialStatus", DbType.Boolean, IsMartialStatus);
            try
            {
                //result = objDatabase.ExecuteNonQuery(objDbCommand);
                IDataReader dr = objDatabase.ExecuteReader(objDbCommand);
                dt.Load(dr);

            }
            catch (Exception ex)
            {
                dt = null;
            }
            return dt;

        }

        public DataTable GetUnitFirmType(int UnitfirmId)
        {
            DataTable dt = new DataTable();
            string _proc = "Procs_GetUnitFirmType";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDbCommand = objDatabase.GetStoredProcCommand(_proc);
            objDatabase.AddInParameter(objDbCommand, "@UnitfirmId", DbType.Int32, UnitfirmId);
            try
            {
                IDataReader dr = objDatabase.ExecuteReader(objDbCommand);
                dt.Load(dr);
            }
            catch
            {
                dt = null;
            }
            return dt;
        }

        public DataTable GetFinancingAgency(int financingAgencyId)
        {
            DataTable dt = new DataTable();
            string _proc = "Procs_GetFinancingAgency";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDbCommand = objDatabase.GetStoredProcCommand(_proc);
            objDatabase.AddInParameter(objDbCommand, "@financingAgencyId", DbType.Int32, financingAgencyId);
            try
            {
                IDataReader dr = objDatabase.ExecuteReader(objDbCommand);
                dt.Load(dr);
            }
            catch
            {
                dt = null;
            }
            return dt;
        }

        public DataTable GetDistrictDetails(int district_id)
        {
            DataTable dt = new DataTable();
            string _proc = "Procs_GetDistrictDetails";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDbCommand = objDatabase.GetStoredProcCommand(_proc);
            objDatabase.AddInParameter(objDbCommand, "@district_id", DbType.Int32, district_id);
            try
            {
                IDataReader dr = objDatabase.ExecuteReader(objDbCommand);
                dt.Load(dr);
            }
            catch
            {
                dt = null;
            }
            return dt;
        }

        public DataTable GetDivisionDetails(int district_id)
        {
            DataTable dt = new DataTable();
            string _proc = "Procs_GetDivisionDetails";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDbCommand = objDatabase.GetStoredProcCommand(_proc);
            objDatabase.AddInParameter(objDbCommand, "@district_id", DbType.Int32, district_id);
            try
            {
                IDataReader dr = objDatabase.ExecuteReader(objDbCommand);
                dt.Load(dr);
            }
            catch
            {
                dt = null;
            }
            return dt;
        }


        #region  PaymentDetails ANURAG 1062016


        public DataTable insertPaymentDetails(Int64 ApplicationId, string ApplicationNo, string PaymentType, string tenderType, Int32 ProcId)
        {
            DataTable dt = new DataTable();
            try
            {
                string proc_ = "sp_InsertPaymentDetails";
                Database objDatabase = DatabaseFactory.CreateDatabase();
                DbCommand objDbCommand = objDatabase.GetStoredProcCommand(proc_);
                objDatabase.AddInParameter(objDbCommand, "@ApplicationId", DbType.Int64, ApplicationId);
                objDatabase.AddInParameter(objDbCommand, "@ApplicationNo", DbType.String, ApplicationNo);
                objDatabase.AddInParameter(objDbCommand, "@PaymentType", DbType.String, PaymentType);
                objDatabase.AddInParameter(objDbCommand, "@tenderType", DbType.String, tenderType);
                objDatabase.AddInParameter(objDbCommand, "@ProcId", DbType.Int32, ProcId);
                //res = objDatabase.ExecuteNonQuery(objDbCommand);

                IDataReader idr = objDatabase.ExecuteReader(objDbCommand);
                dt.Load(idr);



            }
            catch (Exception ex)
            {
                return null;
            }
            return dt;
        }



        public DataTable GetApplicationDetailsbyApplicationId(Int64 ApplicationId)
        {
            DataTable dt = new DataTable();
            string _proc = "Sp_GetApplicationDetailsbyApplicationId";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDbCommand = objDatabase.GetStoredProcCommand(_proc);
            objDatabase.AddInParameter(objDbCommand, "@ApplicationId", DbType.Int64, ApplicationId);
            try
            {
                IDataReader dr = objDatabase.ExecuteReader(objDbCommand);
                dt.Load(dr);
            }
            catch
            {
                dt = null;
            }
            return dt;
        }

        //Ujjval
        public DataTable GetApplicationDetailsbyApplicationIdForJE(Int64 ApplicationId)
        {
            DataTable dt = new DataTable();
            string _proc = "Sp_GetApplicationDetailsbyApplicationIdForJE";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDbCommand = objDatabase.GetStoredProcCommand(_proc);
            objDatabase.AddInParameter(objDbCommand, "@ApplicationId", DbType.Int64, ApplicationId);
            try
            {
                IDataReader dr = objDatabase.ExecuteReader(objDbCommand);
                dt.Load(dr);
            }
            catch
            {
                dt = null;
            }
            return dt;
        }

        //
        public DataTable GetApplicantPaymentDetailsForMailByDivision(Int64 ApplicantID, string PaymentType)
        {
            DataTable dt = new DataTable();
            string _proc = "Procs_GetApplicantPaymentDetailsForMailByDivision";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDbCommand = objDatabase.GetStoredProcCommand(_proc);
            objDatabase.AddInParameter(objDbCommand, "@ApplicantID", DbType.Int64, ApplicantID);

            objDatabase.AddInParameter(objDbCommand, "@PaymentType", DbType.String, PaymentType);
            try
            {
                IDataReader dr = objDatabase.ExecuteReader(objDbCommand);
                dt.Load(dr);
            }
            catch
            {
                dt = null;
            }
            return dt;
        }
        #endregion

        public DataTable GetDivisionDetailsByApplicantId(long applicantId)
        {

            DataTable dt = new DataTable();
            string _Proc = "proc_GetDivisionDetailsByApplicantId";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                objDatabase.AddInParameter(objDBCommand, "@applicantId", DbType.Int64, applicantId);
                IDataReader dr = objDatabase.ExecuteReader(objDBCommand);
                dt.Load(dr);
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                objDBCommand.Dispose();
                objDatabase = null;
            }
            return dt;
        }

        public DataTable GetApplicantDetails(Int64 ApplicantID, Int64 UserID)
        {
            DataTable dt = new DataTable();
            string _proc = "Procs_GetApplicantDetails";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDbCommand = objDatabase.GetStoredProcCommand(_proc);
            objDatabase.AddInParameter(objDbCommand, "@ApplicantID", DbType.Int64, ApplicantID);
            objDatabase.AddInParameter(objDbCommand, "@UserID", DbType.Int64, UserID);
            try
            {
                IDataReader dr = objDatabase.ExecuteReader(objDbCommand);
                dt.Load(dr);
            }
            catch
            {
                dt = null;
            }
            return dt;
        }

        #region Get Application Feeder Details

        public DataTable GetApllicationFeederDetails(Int64 ApplicationID)
        {
            DataTable dt = new DataTable();
            string _proc = "Procs_GetApllicationFeederDetails";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDbCommand = objDatabase.GetStoredProcCommand(_proc);
            objDatabase.AddInParameter(objDbCommand, "@ApplicationID", DbType.Int64, ApplicationID);

            try
            {
                IDataReader dr = objDatabase.ExecuteReader(objDbCommand);
                dt.Load(dr);
            }
            catch
            {
                dt = null;
            }
            return dt;
        }

        public DataTable GetFeasibilityStatus(Int64 ApplicationID)
        {
            DataTable dt = new DataTable();
            string _proc = "Procs_GetFeasibilityStatus";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDbCommand = objDatabase.GetStoredProcCommand(_proc);
            objDatabase.AddInParameter(objDbCommand, "@ApplicationID", DbType.Int64, ApplicationID);

            try
            {
                IDataReader dr = objDatabase.ExecuteReader(objDbCommand);
                dt.Load(dr);
            }
            catch
            {
                dt = null;
            }
            return dt;
        }
        #endregion

        public DataTable GetInspectorDeginationDetails(int InspectorDeginationId)
        {
            DataTable dt = new DataTable();
            string _proc = "Procs_GetInspectorDeginationDetails";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDbCommand = objDatabase.GetStoredProcCommand(_proc);
            objDatabase.AddInParameter(objDbCommand, "@InspectorDeginationId", DbType.Int32, InspectorDeginationId);
            try
            {
                IDataReader dr = objDatabase.ExecuteReader(objDbCommand);
                dt.Load(dr);
            }
            catch
            {
                dt = null;
            }
            return dt;
        }


        #region  Insert Update Work Completion Details

        public int InsertUpdateWorkCompletionDetails(string ElectricalInspectorReportUrl, bool isApply, Int64 ApplicationId, string ipAddress)
        {
            int res = 0;
            try
            {
                string proc_ = "Procs_InsertUpdateWorkCompletionDetails";
                Database objDatabase = DatabaseFactory.CreateDatabase();
                DbCommand objDbCommand = objDatabase.GetStoredProcCommand(proc_);
                objDatabase.AddInParameter(objDbCommand, "@ElectricalInspectorReportUrl", DbType.String, ElectricalInspectorReportUrl);
                objDatabase.AddInParameter(objDbCommand, "@isApply", DbType.Boolean, isApply);
                objDatabase.AddInParameter(objDbCommand, "@ApplicationID", DbType.Int64, ApplicationId);
                objDatabase.AddInParameter(objDbCommand, "@ipAddress", DbType.String, ipAddress);

                res = objDatabase.ExecuteNonQuery(objDbCommand);

            }
            catch (Exception ex)
            {
                return 0;
            }
            return res;
        }

        #endregion

        public DataSet GetWorkCompletionDetails(Int64 ApplicationID)
        {
            DataSet dt = new DataSet();
            string _Proc = "Procs_GetWorkCompletionDetails";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                objDatabase.AddInParameter(objDBCommand, "@ApplicationID", DbType.String, ApplicationID);
                dt = objDatabase.ExecuteDataSet(objDBCommand);
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                objDBCommand.Dispose();
                objDatabase = null;
            }
            return dt;

            //DataSet dt = new DataSet();
            //string _proc = "Procs_GetWorkCompletionDetails";
            //Database objDatabase = DatabaseFactory.CreateDatabase();
            //DbCommand objDbCommand = objDatabase.GetStoredProcCommand(_proc);
            //objDatabase.AddInParameter(objDbCommand, "@ApplicationID", DbType.Int64, ApplicationID);
            //try
            //{
            //    //IDataReader dr = objDatabase.ExecuteReader(objDbCommand);
            //    //ds.Load(dr);
            //    dt = objDatabase.ExecuteDataSet(objDbCommand);
            //}
            //catch
            //{
            //    dt = null;
            //}
            //return dt;
        }

        #region Get Steps Details of Applicant

        public DataTable GetStepsDetails(Int64 ApplicantionID)
        {


            DataTable dt = new DataTable();
            string _proc = "Procs_GetStepsDetails";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDbCommand = objDatabase.GetStoredProcCommand(_proc);
            objDatabase.AddInParameter(objDbCommand, "@ApplicationID", DbType.Int64, ApplicantionID);
            try
            {
                IDataReader dr = objDatabase.ExecuteReader(objDbCommand);
                dt.Load(dr);
            }
            catch
            {
                dt = null;
            }
            return dt;
        }
        #endregion

        #region Update Application Steps

        public int UpdateApplicationSteps(Int64 ApplicationID, string Step)
        {
            int res = 0;
            try
            {
                string proc_ = "Procs_UpdateApplicationSteps";
                Database objDatabase = DatabaseFactory.CreateDatabase();
                DbCommand objDbCommand = objDatabase.GetStoredProcCommand(proc_);
                objDatabase.AddInParameter(objDbCommand, "@ApplicationID", DbType.Int64, ApplicationID);
                objDatabase.AddInParameter(objDbCommand, "@Step", DbType.String, Step);

                res = objDatabase.ExecuteNonQuery(objDbCommand);

            }
            catch (Exception ex)
            {
                return 0;
            }
            return res;
        }

        #endregion

        #region Insert Application Steps

        public int InsertApplicationSteps(Int64 ApplicationID, string Step)
        {
            int res = 0;
            try
            {
                string proc_ = "Procs_InsertApplicationSteps";
                Database objDatabase = DatabaseFactory.CreateDatabase();
                DbCommand objDbCommand = objDatabase.GetStoredProcCommand(proc_);
                objDatabase.AddInParameter(objDbCommand, "@ApplicationID", DbType.Int64, ApplicationID);
                //objDatabase.AddInParameter(objDbCommand, "@Step", DbType.String, Step);

                res = objDatabase.ExecuteNonQuery(objDbCommand);

            }
            catch (Exception ex)
            {
                return 0;
            }
            return res;
        }

        #endregion

        #region Get Payment Details For Sending MAil

        public DataTable GetApplicantPaymentDetailsForMail(Int64 ApplicantID, Int64 UserID, string PaymentType)
        {
            DataTable dt = new DataTable();
            string _proc = "Procs_GetApplicantPaymentDetailsForMail";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDbCommand = objDatabase.GetStoredProcCommand(_proc);
            objDatabase.AddInParameter(objDbCommand, "@ApplicantID", DbType.Int64, ApplicantID);
            objDatabase.AddInParameter(objDbCommand, "@UserID", DbType.Int64, UserID);
            objDatabase.AddInParameter(objDbCommand, "@PaymentType", DbType.String, PaymentType);
            try
            {
                IDataReader dr = objDatabase.ExecuteReader(objDbCommand);
                dt.Load(dr);
            }
            catch
            {
                dt = null;
            }
            return dt;
        }
        #endregion
        public int InsertApplicationCurrentStatus(long ApplicationId, string status)
        {
            int res = 0;
            try
            {
                string proc_ = "Proc_InsertApplicationStatus";
                Database objDatabase = DatabaseFactory.CreateDatabase();
                DbCommand objDbCommand = objDatabase.GetStoredProcCommand(proc_);
                objDatabase.AddInParameter(objDbCommand, "@applicationId", DbType.Int64, ApplicationId);
                objDatabase.AddInParameter(objDbCommand, "@status", DbType.String, status);

                res = objDatabase.ExecuteNonQuery(objDbCommand);

            }
            catch (Exception ex)
            {
                return 0;
            }
            return res;
        }
        public int insertPaymentModeDetails(Int64 ApplicationId, string DDNo, string DDDate, string details, string DDUrl, string UTRNo, string UTRDate, string UTRUrl, string Paymentmode, string Ipaddress)
        {
            int res = 0;
            try
            {
                string proc_ = "proc_insertPaymentModeDetail";
                Database objDatabase = DatabaseFactory.CreateDatabase();
                DbCommand objDbCommand = objDatabase.GetStoredProcCommand(proc_);
                objDatabase.AddInParameter(objDbCommand, "@applicationId", DbType.Int64, ApplicationId);
                objDatabase.AddInParameter(objDbCommand, "@DDNo", DbType.String, DDNo ?? string.Empty);
                objDatabase.AddInParameter(objDbCommand, "@DDDate", DbType.String, DDDate ?? string.Empty);
                objDatabase.AddInParameter(objDbCommand, "@DDUrl", DbType.String, DDUrl ?? string.Empty);
                objDatabase.AddInParameter(objDbCommand, "@detail", DbType.String, details ?? string.Empty);
                objDatabase.AddInParameter(objDbCommand, "@UTRNo", DbType.String, UTRNo ?? string.Empty);
                objDatabase.AddInParameter(objDbCommand, "@UTRDate", DbType.String, UTRDate ?? string.Empty);
                objDatabase.AddInParameter(objDbCommand, "@UTRUrl", DbType.String, UTRUrl ?? string.Empty);
                objDatabase.AddInParameter(objDbCommand, "@Paymentmode", DbType.String, Paymentmode ?? string.Empty);
                objDatabase.AddInParameter(objDbCommand, "@Ipaddress", DbType.String, Ipaddress ?? string.Empty);
                res = objDatabase.ExecuteNonQuery(objDbCommand);

            }
            catch (Exception ex)
            {
                return 0;
            }
            return res;
        }

        public DataTable GetIDProofType()
        {
            DataTable dt = new DataTable();
            string _proc = "proc_getIdProofType";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDbCommand = objDatabase.GetStoredProcCommand(_proc);

            try
            {
                IDataReader dr = objDatabase.ExecuteReader(objDbCommand);
                dt.Load(dr);
            }
            catch
            {
                dt = null;
            }
            return dt;
        }

        public int insertsdoslogin(string xml)
        {
            int res = 0;
            try
            {
                string proc_ = "proc_insertSDOLogin";
                Database objDatabase = DatabaseFactory.CreateDatabase();
                DbCommand objDbCommand = objDatabase.GetStoredProcCommand(proc_);
                objDatabase.AddInParameter(objDbCommand, "@xmldata", DbType.String, xml);

                res = objDatabase.ExecuteNonQuery(objDbCommand);

            }
            catch (Exception ex)
            {
                return 0;
            }
            return res;
        }

        public DataTable updatePFPayment(Int64 ApplicationId, string challanNo, string PayType, string TransId, DateTime PayDate, string userType, string ExuserId)
        {
            DataTable dt = new DataTable();
            string _proc = "Proc_UpdatePFPayment";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDbCommand = objDatabase.GetStoredProcCommand(_proc);
            objDatabase.AddInParameter(objDbCommand, "@applicationId", DbType.Int64, ApplicationId);
            objDatabase.AddInParameter(objDbCommand, "@ChallanNo", DbType.String, challanNo ?? string.Empty);
            objDatabase.AddInParameter(objDbCommand, "@PaymType", DbType.String, PayType ?? string.Empty);
            objDatabase.AddInParameter(objDbCommand, "@TransId", DbType.String, TransId ?? string.Empty);
            objDatabase.AddInParameter(objDbCommand, "@PaymentDate", DbType.Date, PayDate);
            objDatabase.AddInParameter(objDbCommand, "@UserType", DbType.String, userType);
            objDatabase.AddInParameter(objDbCommand, "@UserId", DbType.String, ExuserId);
            try
            {
                IDataReader dr = objDatabase.ExecuteReader(objDbCommand);
                dt.Load(dr);
            }
            catch
            {
                dt = null;
            }
            return dt;
        }

        public DataTable getEstimationCostLastDate(long applicationId)
        {
            DataTable dt = new DataTable();
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDbcommand = objDatabase.GetStoredProcCommand("proc_getEstimationCostLastDate");
            objDatabase.AddInParameter(objDbcommand, "@applicationId", DbType.Int64, applicationId);
            try
            {
                using (IDataReader dr = objDatabase.ExecuteReader(objDbcommand))
                {
                    dt.Load(dr);
                }
            }
            catch (Exception ex)
            {
                dt = null;
            }
            return dt;
        }

        public DataTable getWorkCompletionLastDate(long applicationId)
        {
            DataTable dt = new DataTable();
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDbcommand = objDatabase.GetStoredProcCommand("Proc_getWorkCompletionLastDate");
            objDatabase.AddInParameter(objDbcommand, "@applicationId", DbType.Int64, applicationId);
            try
            {
                using (IDataReader dr = objDatabase.ExecuteReader(objDbcommand))
                {
                    dt.Load(dr);
                }
            }
            catch (Exception ex)
            {
                dt = null;
            }
            return dt;
        }

        #region Querydetails_Aditi

        public DataTable GetQueryDetails(long applicantId)
        {
            DataTable dt = new DataTable();
            try
            {


                string proc_ = "proc_getQueryDetailbyId";
                Database objDatabase = DatabaseFactory.CreateDatabase();
                DbCommand objDbCommand = objDatabase.GetStoredProcCommand(proc_);
                objDatabase.AddInParameter(objDbCommand, "@applicationId", DbType.Int64, applicantId);
                IDataReader idr = objDatabase.ExecuteReader(objDbCommand);
                dt.Load(idr);



            }
            catch (Exception ex)
            {
                return null;
            }
            return dt;
        }
        public DataTable SendReplyQuery(string Rply, Int64 ApplicationId, string Query, string QueryDocByApplicant)
        {
            DataTable dt = new DataTable();
            string _proc = "proc_sendRplyForQuery";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDbCommand = objDatabase.GetStoredProcCommand(_proc);
            objDatabase.AddInParameter(objDbCommand, "@Rply", DbType.String, Rply);
            objDatabase.AddInParameter(objDbCommand, "@ApplicationId", DbType.Int64, ApplicationId);
            objDatabase.AddInParameter(objDbCommand, "@QueryDocByApplicant", DbType.String, QueryDocByApplicant);
            objDatabase.AddInParameter(objDbCommand, "@query", DbType.String, Query);
            try
            {
                IDataReader dr = objDatabase.ExecuteReader(objDbCommand);
                dt.Load(dr);
            }
            catch
            {
                dt = null;
            }
            return dt;
        }
        #endregion


    }

}