﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;
using System.Net.Mail;
using System.Configuration;
using UPPCL_WebAPI.Models;
namespace UPPCL_WebAPI.Filters
{
    /// <summary>
    /// Summary description for MailMsg
    /// </summary>
    public class MailMsg
    {
        #region SMS
        public static String SMSSend(String Message, String Recipient, bool isEng)
        {
            string s = string.Empty;
            try
            {
                WebClient Client = new WebClient();

                //string baseurl = "http://sms.cellapps.com/sendsms_bulk.php?UserId=ETIPCL&Pwd=ETIPCL&Mobileno=" + Recipient + "&Msg=" + Message + "&SenderId=ETIPCL";

                string baseurl = "";

                if (isEng)
                {
                    baseurl = "http://httpapi.zone:7501/failsafe/HttpLink?aid=648388&pin=abc@!23&mnumber=91" + Recipient + "&signature=BIJLEE&message=" + Message;  // new api for message
                }
                else
                {
                    baseurl = "http://httpapi.zone:7501/failsafe/HttpLink?aid=648388&pin=abc@!23&mnumber=91" + Recipient + "&signature=BIJLEE&msgType=UC&message=" + ConvertToUTF16(Message);  // new api for message
                }

                //string baseurl = "http://india.timessms.com/http-api/receiverall.aspx?username=titus_otpl&password=71919800&sender=OMNINET&cdmasender=9935536635&to=" + Recipient + "&message=" + Message;

                Stream data = Client.OpenRead(baseurl);
                StreamReader reader = new StreamReader(data);
                s = reader.ReadToEnd();
                data.Close();
                reader.Close();
            }
            catch (Exception ex)
            {
                return s + " " + ex.Message;
            }
            return s;
        }

        public static string ConvertToUTF16(string str)
        {
            byte[] ArrayOFBytes = System.Text.Encoding.Unicode.GetBytes(str);
            string UTF16 = "";
            int v;
            for (v = 0; (v
                        <= (ArrayOFBytes.Length - 1)); v++)
            {
                if (((v % 2)
                            == 0))
                {
                    byte t = ArrayOFBytes[v];
                    ArrayOFBytes[v] = ArrayOFBytes[(v + 1)];
                    ArrayOFBytes[(v + 1)] = t;
                }

            }

            for (v = 0; (v
                        <= (ArrayOFBytes.Length - 1)); v++)
            {
                string c = (ArrayOFBytes[v]).ToString("X2");
                if ((c.Length == 1))
                {
                    c = ("0" + c);
                }

                UTF16 = (UTF16 + c);
            }

            return UTF16;
        }

        public static void SMSLog(String Message, String MobileNo, String SMSStatus, Int64 ApplicationId)
        {
            try
            {
                Common obj = new Common();
                obj.InserSMSLog(MobileNo, Message, SMSStatus, ApplicationId);
            }
            catch
            { }
        }

        public static Int64 InsertOTP(string OTP, string OTPFor, string IPAddress, string mobileno, string SmsText, string smsStatus, Int64 ApplicationId, Int64 TransId, string LoginId, int flag)
        {
            try
            {
                //  Common obj = new Common();
                NewAdoContext obj = new NewAdoContext();
                return obj.InsertOTP(OTP, OTPFor, IPAddress, mobileno, SmsText, smsStatus, ApplicationId, TransId, LoginId, flag);
            }
            catch
            { }
            return 0;
        }
        public static Int64 CheckOTP(string OTP, Int64 TransId, string LoginId, int flag)
        {
            try
            {
               // Common obj = new Common();
                NewAdoContext obj = new NewAdoContext();

                return obj.CheckOTP(OTP, TransId, LoginId, flag);
            }
            catch
            { }
            return 0;
        }
        #endregion

        public static string FromMail
        {
            get
            {
                String _fromEmail = System.Configuration.ConfigurationManager.ConnectionStrings["FromMail"].ConnectionString;
                if (String.IsNullOrEmpty(_fromEmail))
                    return String.Empty;

                else
                    return _fromEmail;
            }
        }

        public static string ServerIP
        {
            get
            {
                String _serverIP = System.Configuration.ConfigurationManager.ConnectionStrings["serverIP"].ConnectionString;
                if (String.IsNullOrEmpty(_serverIP))
                    return String.Empty;

                else
                    return _serverIP;
            }
        }

        public static string CCMailID
        {
            get
            {
                String _CCMailID = System.Configuration.ConfigurationManager.ConnectionStrings["ccMail"].ConnectionString;
                if (String.IsNullOrEmpty(_CCMailID))
                    return String.Empty;

                else
                    return _CCMailID;
            }
        }

        public static string BCCMailID
        {
            get
            {
                String _BCCEmail = System.Configuration.ConfigurationManager.ConnectionStrings["BccMail"].ConnectionString;
                if (String.IsNullOrEmpty(_BCCEmail))
                    return String.Empty;

                else
                    return _BCCEmail;
            }
        }

        public static string ServerName
        {
            get
            {
                String _ServerName = System.Configuration.ConfigurationManager.ConnectionStrings["ServerName"].ConnectionString;
                if (String.IsNullOrEmpty(_ServerName))
                    return "Admin";

                else
                    return _ServerName;
            }
        }

        public static void sendMail(string mailTo, string mailCC, string mailSub, string mailMsg)
        {
            string mailerHost = MailMsg.ServerIP;
            string mailFrom = MailMsg.FromMail;
            string bccmail = MailMsg.BCCMailID;

            if (ConfigurationManager.AppSettings["MailType"] == "E")
            {
                //string[] tmp = new string[1];

                //MailService.Service1 objs = new MailService.Service1();
                //MailService.EmailDataNew msg = new MailService.EmailDataNew();

                //msg.frommail = mailFrom;

                //tmp[0] = bccmail;

                //msg.bccemail = tmp;

                //tmp = new string[1];
                //tmp[0] = mailTo;

                //msg.toemail = tmp;

                //tmp = new string[1];
                //msg.ccemail = tmp;

                //msg.subject = mailSub;
                //msg.mailbody = mailMsg;

                //objs.sendMailNew(msg);
            }
            else if (ConfigurationManager.AppSettings["MailType"] == "N")
            {

                MailerClass objmail = new MailerClass();

                string[] BccMaill = new string[1];
                string[] mailtol = new string[1];
                string[] ccMaill = new string[1];
                mailtol[0] = mailTo;
                ccMaill[0] = mailCC;
                string FMail = "\"" + MailMsg.ServerName + "\"" + MailMsg.FromMail;
                objmail.sendMail(mailtol, BccMaill, ccMaill, FMail, mailMsg, mailSub);
                try
                {

                    Common.InserEmailLog(mailTo, mailCC, mailSub, mailMsg, true, "Mail Send Successfully");
                }
                catch (Exception ex)
                {
                    Common.InserEmailLog(mailTo, mailCC, mailSub, mailMsg, false, ex.Message);
                }

            }
            else
            {

                MailMessage mlMsg = new MailMessage();
                SmtpClient smpt = new SmtpClient();

                if (mailerHost.Trim() != "")
                    smpt.Host = mailerHost;
                mlMsg.To.Add(mailTo);
                if (mailCC != "")
                    mlMsg.Bcc.Add(mailCC);


                mlMsg.From = new MailAddress(mailFrom, MailMsg.ServerName);



                mlMsg.IsBodyHtml = true;
                mlMsg.Body = mailMsg;
                mlMsg.Subject = mailSub;

                try
                {
                    smpt.Send(mlMsg);

                    Common.InserEmailLog(mailTo, mailCC, mailSub, mailMsg, true, "Mail Send Successfully");
                }
                catch (Exception ex)
                {
                    Common.InserEmailLog(mailTo, mailCC, mailSub, mailMsg, false, ex.Message);
                }
            }
        }

        public static void sendMail(string mailTo, string mailCC, string mailSub, string mailMsg, string Attachment)
        {
            string mailerHost = MailMsg.ServerIP;
            string mailFrom = MailMsg.FromMail;
            string bccmail = MailMsg.BCCMailID;

            if (ConfigurationManager.AppSettings["MailType"] == "E")
            {
                //string[] tmp = new string[1];

                //MailService.Service1 objs = new MailService.Service1();
                //MailService.EmailDataNew msg = new MailService.EmailDataNew();

                //msg.frommail = mailFrom;

                //tmp[0] = bccmail;

                //msg.bccemail = tmp;

                //tmp = new string[1];
                //tmp[0] = mailTo;

                //msg.toemail = tmp;

                //tmp = new string[1];
                //msg.ccemail = tmp;

                //msg.subject = mailSub;
                //msg.mailbody = mailMsg;

                //objs.sendMailNew(msg);
            }
            else if (ConfigurationManager.AppSettings["MailType"] == "N")
            {

                MailerClass objmail = new MailerClass();

                string[] BccMaill = new string[1];
                string[] mailtol = new string[1];
                string[] ccMaill = new string[1];
                mailtol[0] = mailTo;
                ccMaill[0] = mailCC;
                string FMail = "\"" + MailMsg.ServerName + "\"" + MailMsg.FromMail;

                try
                {

                    objmail.sendMail(mailtol, BccMaill, ccMaill, FMail, mailMsg, mailSub, Attachment);
                    Common.InserEmailLog(mailTo, mailCC, mailSub, mailMsg, true, "Mail Send Successfully");
                }
                catch (Exception ex)
                {
                    Common.InserEmailLog(mailTo, mailCC, mailSub, mailMsg, false, ex.Message);
                }

            }
            else
            {

                MailMessage mlMsg = new MailMessage();
                SmtpClient smpt = new SmtpClient();

                if (mailerHost.Trim() != "")
                    smpt.Host = mailerHost;
                mlMsg.To.Add(mailTo);
                if (mailCC != "")
                    mlMsg.Bcc.Add(mailCC);


                mlMsg.From = new MailAddress(mailFrom, MailMsg.ServerName);



                mlMsg.IsBodyHtml = true;
                mlMsg.Body = mailMsg;
                mlMsg.Subject = mailSub;

                try
                {
                    smpt.Send(mlMsg);

                    Common.InserEmailLog(mailTo, mailCC, mailSub, mailMsg, true, "Mail Send Successfully");
                }
                catch (Exception ex)
                {
                    Common.InserEmailLog(mailTo, mailCC, mailSub, mailMsg, false, ex.Message);
                }
            }
        }
    }
}