﻿using Swashbuckle.Swagger;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http.Description;

namespace UPPCL_WebAPI.Filters
{

    public class FileOperationFilter : IOperationFilter
    {
        [AttributeUsage(AttributeTargets.Method)]
        public sealed class SwaggerFormAttribute : Attribute
        {
            public SwaggerFormAttribute()
            {

            }
        }
        public void Apply(Operation operation, SchemaRegistry schemaRegistry, ApiDescription apiDescription)
        {
            var requestAttributes = apiDescription.GetControllerAndActionAttributes<SwaggerFormAttribute>();
            foreach(var attr in requestAttributes)
            {
                operation.parameters = new[]
                {
                    new Parameter { name ="SupplyPurpose",@in = "formData",description = "Purpose of Supplyc",required = true,type = "file"},
                    new Parameter{ name = "ImageCaption", @in  = "formData",description = "Pic Name.",required = true,type = "string"},
                    new Parameter{ name = "ImageCaption", @in  = "formData",description = "Pic Name.",required = true,type = "string"},
                    new Parameter{ name = "ImageCaption", @in  = "formData",description = "Pic Name.",required = true,type = "string"},
                    new Parameter{ name = "ImageCaption", @in  = "formData",description = "Pic Name.",required = true,type = "string"},
                    new Parameter{ name = "ImageCaption", @in  = "formData",description = "Pic Name.",required = true,type = "string"},
                    new Parameter{ name = "ImageCaption", @in  = "formData",description = "Pic Name.",required = true,type = "string"},
                    new Parameter{ name = "ImageCaption", @in  = "formData",description = "Pic Name.",required = true,type = "string"},
                    new Parameter{ name = "ImageCaption", @in  = "formData",description = "Pic Name.",required = true,type = "string"},
                    new Parameter{ name = "ImageCaption", @in  = "formData",description = "Pic Name.",required = true,type = "string"},
                    new Parameter{ name = "ImageCaption", @in  = "formData",description = "Pic Name.",required = true,type = "string"},
                    new Parameter{ name = "ImageCaption", @in  = "formData",description = "Pic Name.",required = true,type = "string"},
                    new Parameter{ name = "ImageCaption", @in  = "formData",description = "Pic Name.",required = true,type = "string"},
                    new Parameter{ name = "ImageCaption", @in  = "formData",description = "Pic Name.",required = true,type = "string"},
                    new Parameter{ name = "ImageCaption", @in  = "formData",description = "Pic Name.",required = true,type = "string"},
                    new Parameter{ name = "ImageCaption", @in  = "formData",description = "Pic Name.",required = true,type = "string"},
                    new Parameter{ name = "ImageCaption", @in  = "formData",description = "Pic Name.",required = true,type = "string"},
                    new Parameter{ name = "ImageCaption", @in  = "formData",description = "Pic Name.",required = true,type = "string"},
                    new Parameter{ name = "ImageCaption", @in  = "formData",description = "Pic Name.",required = true,type = "string"},
                    new Parameter{ name = "ImageCaption", @in  = "formData",description = "Pic Name.",required = true,type = "string"},
                    new Parameter{ name = "ImageCaption", @in  = "formData",description = "Pic Name.",required = true,type = "string"},
                    new Parameter{ name = "ImageCaption", @in  = "formData",description = "Pic Name.",required = true,type = "string"},
                    new Parameter{ name = "ImageCaption", @in  = "formData",description = "Pic Name.",required = true,type = "string"},
                    new Parameter{ name = "ImageCaption", @in  = "formData",description = "Pic Name.",required = true,type = "string"},
                    new Parameter{ name = "ImageCaption", @in  = "formData",description = "Pic Name.",required = true,type = "string"},
                    new Parameter{ name = "ImageCaption", @in  = "formData",description = "Pic Name.",required = true,type = "string"},
                    new Parameter{ name = "ImageCaption", @in  = "formData",description = "Pic Name.",required = true,type = "string"},
                    new Parameter{ name = "ImageCaption", @in  = "formData",description = "Pic Name.",required = true,type = "string"},
                    new Parameter{ name = "ImageCaption", @in  = "formData",description = "Pic Name.",required = true,type = "string"},
                    new Parameter{ name = "ImageCaption", @in  = "formData",description = "Pic Name.",required = true,type = "string"},
                    new Parameter{ name = "ImageCaption", @in  = "formData",description = "Pic Name.",required = true,type = "string"},

                };
                operation.consumes.Add("multipart/form-data");
            }
        }
    }
}