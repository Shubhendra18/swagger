﻿using Microsoft.Practices.EnterpriseLibrary.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;

using System.Linq;
using System.Web;


namespace UPPCL_WebAPI.Filters
{

    /// <summary>
    /// Summary description for clsDivision
    /// </summary>
    public class clsDivision
    {
        public clsDivision()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        public DataTable InsertUserDetails(string name, DateTime DOB, string mobileno, string EmailId, string password, string usertype, string passwordenc)
        {
            DataTable dt = new DataTable();
            string _proc = "Proc_InsertRegistrationDetails";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDbCommand = objDatabase.GetStoredProcCommand(_proc);
            objDatabase.AddInParameter(objDbCommand, "@Name", DbType.String, name);
            objDatabase.AddInParameter(objDbCommand, "@Dob", DbType.DateTime, DOB);
            objDatabase.AddInParameter(objDbCommand, "@MobileNo", DbType.String, mobileno);
            objDatabase.AddInParameter(objDbCommand, "@EmailId", DbType.String, EmailId);
            objDatabase.AddInParameter(objDbCommand, "@Password", DbType.String, password);
            objDatabase.AddInParameter(objDbCommand, "@UserType", DbType.String, usertype);
            objDatabase.AddInParameter(objDbCommand, "@ClientIPAddress", DbType.String, Common.GetIPAddress());
            objDatabase.AddInParameter(objDbCommand, "@PasswordEncrypt", DbType.String, passwordenc);
            try
            {
                IDataReader dr = objDatabase.ExecuteReader(objDbCommand);
                dt.Load(dr);
            }
            catch
            {
                dt = null;
            }
            return dt;
        }

        public int UpdateUserDetails(Int64 UserID, string name, DateTime DOB, string mobileno, string EmailId, string ProfilePic)
        {
            int i = 0;
            string _proc = "procs_UpdateProfileDetails";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDbCommand = objDatabase.GetStoredProcCommand(_proc);
            objDatabase.AddInParameter(objDbCommand, "@UserID", DbType.Int64, UserID);
            objDatabase.AddInParameter(objDbCommand, "@Name", DbType.String, name);
            objDatabase.AddInParameter(objDbCommand, "@Dob", DbType.DateTime, DOB);
            objDatabase.AddInParameter(objDbCommand, "@MobileNo", DbType.String, mobileno);
            objDatabase.AddInParameter(objDbCommand, "@EmailId", DbType.String, EmailId);
            objDatabase.AddInParameter(objDbCommand, "@ClientIPAddress", DbType.String, Common.GetIPAddress());
            objDatabase.AddInParameter(objDbCommand, "@ProfilePic", DbType.String, ProfilePic);
            try
            {
                i = objDatabase.ExecuteNonQuery(objDbCommand);
            }
            catch (Exception ex)
            {
                i = 0;
            }
            return i;
        }


        public DataTable getUserLoginDetails(string LoginId)
        {

            DataTable dt = new DataTable();
            string _Proc = "Proc_getUserLogin";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                objDatabase.AddInParameter(objDBCommand, "@LoginId", DbType.String, LoginId);

                IDataReader dr = objDatabase.ExecuteReader(objDBCommand);
                dt.Load(dr);

            }
            catch (Exception)
            {
                throw;
            }
            finally
            {

                objDBCommand.Dispose();
                objDatabase = null;
            }
            return dt;
        }


        public DataTable getDeptLoginDetails(string LoginId)
        {

            DataTable dt = new DataTable();
            string _Proc = "Proc_getUserLogin_Dept";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                objDatabase.AddInParameter(objDBCommand, "@LoginId", DbType.String, LoginId);

                IDataReader dr = objDatabase.ExecuteReader(objDBCommand);
                dt.Load(dr);

            }
            catch (Exception)
            {
                throw;
            }
            finally
            {

                objDBCommand.Dispose();
                objDatabase = null;
            }
            return dt;
        }

        public DataTable getUserLoginDetailsForEDistrict()
        {

            DataTable dt = new DataTable();
            string _Proc = "Proc_getUserLoginForEDistrcit";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {

                IDataReader dr = objDatabase.ExecuteReader(objDBCommand);
                dt.Load(dr);

            }
            catch (Exception)
            {
                throw;
            }
            finally
            {

                objDBCommand.Dispose();
                objDatabase = null;
            }
            return dt;
        }
        //Proc_DashboardCount_Direct
        public DataTable getDashBoardCountDirect(string DivisionId)
        {

            DataTable dt = new DataTable();
            string _Proc = "Proc_DashboardCount_Direct";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                objDatabase.AddInParameter(objDBCommand, "@DivisionId", DbType.String, DivisionId);

                IDataReader dr = objDatabase.ExecuteReader(objDBCommand);
                dt.Load(dr);

            }
            catch (Exception)
            {
                throw;
            }
            finally
            {

                objDBCommand.Dispose();
                objDatabase = null;
            }
            return dt;
        }
        public DataTable getDashBoardCountNIC(string DivisionId)
        {

            DataTable dt = new DataTable();
            string _Proc = "Proc_DashboardCount_Div";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                objDatabase.AddInParameter(objDBCommand, "@DivisionId", DbType.String, DivisionId);

                IDataReader dr = objDatabase.ExecuteReader(objDBCommand);
                dt.Load(dr);

            }
            catch (Exception)
            {
                throw;
            }
            finally
            {

                objDBCommand.Dispose();
                objDatabase = null;
            }
            return dt;
        }

        public DataTable getNewConnectionListNIC(string DivisionId, string applicationNo, int year, int AppId)
        {

            DataTable dt = new DataTable();
            string _Proc = "Proc_get_DivWiseNewConnectionList";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                objDatabase.AddInParameter(objDBCommand, "@DivisionId", DbType.String, DivisionId);
                objDatabase.AddInParameter(objDBCommand, "@applicationNo", DbType.String, applicationNo);
                objDatabase.AddInParameter(objDBCommand, "@Year", DbType.Int32, year);
                objDatabase.AddInParameter(objDBCommand, "@Applicationid", DbType.Int32, AppId);

                IDataReader dr = objDatabase.ExecuteReader(objDBCommand);
                dt.Load(dr);

            }
            catch (Exception)
            {
                throw;
            }
            finally
            {

                objDBCommand.Dispose();
                objDatabase = null;
            }
            return dt;
        }

        public DataTable getNewConnectionListDirect(string DivisionId, string applicationNo, int year, int AppId)
        {

            DataTable dt = new DataTable();
            string _Proc = "Proc_get_DivWiseNewConnectionListDirect";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                objDatabase.AddInParameter(objDBCommand, "@DivisionId", DbType.String, DivisionId);
                objDatabase.AddInParameter(objDBCommand, "@applicationNo", DbType.String, applicationNo);
                objDatabase.AddInParameter(objDBCommand, "@Year", DbType.Int32, year);
                objDatabase.AddInParameter(objDBCommand, "@Applicationid", DbType.Int32, AppId);

                IDataReader dr = objDatabase.ExecuteReader(objDBCommand);
                dt.Load(dr);

            }
            catch (Exception)
            {
                throw;
            }
            finally
            {

                objDBCommand.Dispose();
                objDatabase = null;
            }
            return dt;
        }

        public DataSet GetFederDetails(int ApplicantId)
        {
            DataSet ds = new DataSet();
            string _Proc = "Proc_GetFeedertypeDetailsForfill";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                objDatabase.AddInParameter(objDBCommand, "@ApplicantId", DbType.String, ApplicantId);
                ds = objDatabase.ExecuteDataSet(objDBCommand);

            }
            catch (Exception)
            {
                throw;
            }
            finally
            {

                objDBCommand.Dispose();
                objDatabase = null;
            }
            return ds;
        }




        public DataSet GetAllTotalChargesofFeder(int ApplicantId, int ConnectionPowerTypeId, int IndependentrFeederTypeId, string areaType)
        {
            DataSet ds = new DataSet();
            string _Proc = "Proc_GetAllchargesOfFeeder";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                objDatabase.AddInParameter(objDBCommand, "@ApplicantId", DbType.Int64, Convert.ToInt64(ApplicantId));
                objDatabase.AddInParameter(objDBCommand, "@ConnectionPowerTypeId", DbType.Int32, ConnectionPowerTypeId);
                objDatabase.AddInParameter(objDBCommand, "@IndependentrFeederTypeId", DbType.Int32, IndependentrFeederTypeId);
                objDatabase.AddInParameter(objDBCommand, "@areaType", DbType.String, areaType);
                ds = objDatabase.ExecuteDataSet(objDBCommand);

            }
            catch (Exception)
            {
                throw;
            }
            finally
            {

                objDBCommand.Dispose();
                objDatabase = null;
            }
            return ds;
        }

        public DataTable getLineCharges(int Applicationid, int lineid)
        {

            DataTable dt = new DataTable();
            string _Proc = "Proc_getLineCharges";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                objDatabase.AddInParameter(objDBCommand, "@applicantid", DbType.Int32, Applicationid);
                objDatabase.AddInParameter(objDBCommand, "@Lineid", DbType.Int32, lineid);

                IDataReader dr = objDatabase.ExecuteReader(objDBCommand);
                dt.Load(dr);

            }
            catch (Exception)
            {
                throw;
            }
            finally
            {

                objDBCommand.Dispose();
                objDatabase = null;
            }
            return dt;
        }

        public DataTable InsertApplicationFeederDetails(int FeederTypeId, string FeederCode, int ConnectionTypeId, string LetterReferenceNo, DateTime LetterDate, string Upload, string AreaType, decimal SystemLoadingcharge, int IndependentfeedertypeId,
            string ipAddress
           , bool IsOverHead, bool IsUnderGround, decimal OverHeadLengthLine, decimal UnderGroundLengthLine, Int64 ApplicationId, decimal TotalPaybalAmount, string SuccSertificateUrl, string RelevantDocumentURL
           , string ConnType, string RouteSeq, string Sypplycode, string CusTType, string IsSbmCust, string IsIndemnityBond, string IsOwnerConsentLetter, string SDOOffice
           , string TaxforHV, string EDEXEMPTIONFLAG, int TownId, string SecDepAmnt, string OtherAmnt, int CustClassID
           )
        {
            DataTable dt = new DataTable();
            string _proc = "Proc_insertApplicationFeederDetails";

            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDbCommand = objDatabase.GetStoredProcCommand(_proc);
            objDatabase.AddInParameter(objDbCommand, "@FeederTypeId", DbType.Int32, FeederTypeId);
            objDatabase.AddInParameter(objDbCommand, "@ConnectionTypeId", DbType.Int32, ConnectionTypeId);
            objDatabase.AddInParameter(objDbCommand, "@LetterReferenceNo", DbType.String, LetterReferenceNo);
            objDatabase.AddInParameter(objDbCommand, "@LetterDate", DbType.DateTime, LetterDate);
            objDatabase.AddInParameter(objDbCommand, "@Upload", DbType.String, Upload);
            objDatabase.AddInParameter(objDbCommand, "@AreaType", DbType.String, AreaType);
            objDatabase.AddInParameter(objDbCommand, "@ConnectionPowerTypeId", DbType.Int32, 0);
            objDatabase.AddInParameter(objDbCommand, "@SystemLoadingcharge", DbType.Decimal, SystemLoadingcharge);
            objDatabase.AddInParameter(objDbCommand, "@IndependentfeedertypeId", DbType.Int32, IndependentfeedertypeId);
            objDatabase.AddInParameter(objDbCommand, "@ipAddress", DbType.String, ipAddress);
            objDatabase.AddInParameter(objDbCommand, "@IsOverHead", DbType.Boolean, IsOverHead);
            objDatabase.AddInParameter(objDbCommand, "@IsUnderGround", DbType.Boolean, IsUnderGround);
            objDatabase.AddInParameter(objDbCommand, "@OverHeadLengthLine", DbType.Decimal, OverHeadLengthLine);
            objDatabase.AddInParameter(objDbCommand, "@UnderGroundLengthLine", DbType.Decimal, UnderGroundLengthLine);
            objDatabase.AddInParameter(objDbCommand, "@ApplicationId", DbType.Int64, ApplicationId);
            objDatabase.AddInParameter(objDbCommand, "@TotalPaybalAmount", DbType.Decimal, TotalPaybalAmount);
            objDatabase.AddInParameter(objDbCommand, "@SuccessCerurl", DbType.String, SuccSertificateUrl);
            objDatabase.AddInParameter(objDbCommand, "@RelevantDocumentUrl", DbType.String, RelevantDocumentURL);


            objDatabase.AddInParameter(objDbCommand, "@ConnType", DbType.String, ConnType ?? string.Empty);
            objDatabase.AddInParameter(objDbCommand, "@RouteSeq", DbType.String, RouteSeq ?? string.Empty);
            //objDatabase.AddInParameter(objDbCommand, "@LoadUnit", DbType.String,  string.Empty);
            objDatabase.AddInParameter(objDbCommand, "@Supplycode", DbType.String, Sypplycode ?? string.Empty);
            objDatabase.AddInParameter(objDbCommand, "@CustType", DbType.String, CusTType ?? string.Empty);
            objDatabase.AddInParameter(objDbCommand, "@IsSbmCust", DbType.String, IsSbmCust ?? string.Empty);

            objDatabase.AddInParameter(objDbCommand, "@isIndemnityBond", DbType.String, IsIndemnityBond ?? string.Empty);
            objDatabase.AddInParameter(objDbCommand, "@IsOwnerConsentLetter", DbType.String, IsOwnerConsentLetter ?? string.Empty);
            objDatabase.AddInParameter(objDbCommand, "@SDOOffice", DbType.String, SDOOffice ?? string.Empty);
            objDatabase.AddInParameter(objDbCommand, "@TaxforHV", DbType.String, TaxforHV ?? string.Empty);
            objDatabase.AddInParameter(objDbCommand, "@EDEXEMPTIONFLAG", DbType.String, EDEXEMPTIONFLAG ?? string.Empty);
            //------------------------------------------------------
            objDatabase.AddInParameter(objDbCommand, "@TownId", DbType.Int32, TownId);
            objDatabase.AddInParameter(objDbCommand, "@CustId", DbType.Int32, CustClassID);
            objDatabase.AddInParameter(objDbCommand, "@SecDepAmnt", DbType.String, SecDepAmnt ?? "0");
            objDatabase.AddInParameter(objDbCommand, "@otherAmnt", DbType.String, OtherAmnt ?? "0");
            objDatabase.AddInParameter(objDbCommand, "@FeederCode", DbType.String, FeederCode);
            try
            {
                //objDatabase.ExecuteNonQuery(objDbCommand);
                IDataReader dr = objDatabase.ExecuteReader(objDbCommand);
                dt.Load(dr);
            }
            catch (Exception ex)
            {
                dt = null;
            }
            return dt;
        }


        public int InsertFeaibilityStatus(int ApplicantId, int isfisible, string Remark)
        {
            int res = 0;
            string _Proc = "Proc_InserApplicationfeaibility";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                objDatabase.AddInParameter(objDBCommand, "@ApplicationId", DbType.Int32, ApplicantId);
                objDatabase.AddInParameter(objDBCommand, "@Isfeasible", DbType.Int32, isfisible);
                objDatabase.AddInParameter(objDBCommand, "@Remark", DbType.String, Remark);
                res = objDatabase.ExecuteNonQuery(objDBCommand);

            }
            catch (Exception)
            {
                throw;
            }
            finally
            {

                objDBCommand.Dispose();
                objDatabase = null;
            }
            return res;
        }
        public int RejectInsertFeaibilityReport(int ApplicantId, string path)
        {
            int res = 0;
            string _Proc = "Proc_InsertApplicationfeaibilityReport";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                objDatabase.AddInParameter(objDBCommand, "@ApplicationId", DbType.Int32, ApplicantId);
                objDatabase.AddInParameter(objDBCommand, "@feasiblityreport", DbType.String, path);
                res = objDatabase.ExecuteNonQuery(objDBCommand);

            }
            catch (Exception)
            {
                throw;
            }
            finally
            {

                objDBCommand.Dispose();
                objDatabase = null;
            }
            return res;
        }
        #region Anurag 11062016
        public DataTable getRejectedApplicationforms(string ApplicationNo, string divisionId)
        {
            string proc_ = "sp_getRejectedApplicationforms";
            DataTable dt = new DataTable();

            Database objDatabae = DatabaseFactory.CreateDatabase();
            DbCommand objDbCommand = objDatabae.GetStoredProcCommand(proc_);
            try
            {


                objDatabae.AddInParameter(objDbCommand, "@ApplicationNo", DbType.String, ApplicationNo);
                objDatabae.AddInParameter(objDbCommand, "@divisionId", DbType.String, divisionId);

                IDataReader Idr = objDatabae.ExecuteReader(objDbCommand);
                dt.Load(Idr);
            }

            catch
            {

                dt = null;
            }
            return dt;
        }

        #endregion
        public DataTable getOfficeRejectedApplicationforms(string DiscomId, string ZoneId, string circleId, string ApplicationNo, string divisionId)
        {
            string proc_ = "sp_getOfficeRejectedApplicationforms";
            DataTable dt = new DataTable();

            Database objDatabae = DatabaseFactory.CreateDatabase();
            DbCommand objDbCommand = objDatabae.GetStoredProcCommand(proc_);
            try
            {
                objDatabae.AddInParameter(objDbCommand, "@DiscomId", DbType.String, DiscomId);
                objDatabae.AddInParameter(objDbCommand, "@ZoneId", DbType.String, ZoneId);
                objDatabae.AddInParameter(objDbCommand, "@circleId", DbType.String, circleId);
                objDatabae.AddInParameter(objDbCommand, "@ApplicationNo", DbType.String, ApplicationNo);
                objDatabae.AddInParameter(objDbCommand, "@divisionId", DbType.String, divisionId);
                IDataReader Idr = objDatabae.ExecuteReader(objDbCommand);
                dt.Load(Idr);
            }
            catch
            {
                dt = null;
            }
            return dt;
        }
        public DataTable getOfficeRejectedApplicationformsDirect(string DiscomId, string ZoneId, string circleId, string ApplicationNo, string divisionId)
        {
            string proc_ = "sp_getOfficeRejectedApplicationformsDirect";
            DataTable dt = new DataTable();

            Database objDatabae = DatabaseFactory.CreateDatabase();
            DbCommand objDbCommand = objDatabae.GetStoredProcCommand(proc_);
            try
            {
                objDatabae.AddInParameter(objDbCommand, "@DiscomId", DbType.String, DiscomId);
                objDatabae.AddInParameter(objDbCommand, "@ZoneId", DbType.String, ZoneId);
                objDatabae.AddInParameter(objDbCommand, "@circleId", DbType.String, circleId);
                objDatabae.AddInParameter(objDbCommand, "@ApplicationNo", DbType.String, ApplicationNo);
                objDatabae.AddInParameter(objDbCommand, "@divisionId", DbType.String, divisionId);
                IDataReader Idr = objDatabae.ExecuteReader(objDbCommand);
                dt.Load(Idr);
            }
            catch
            {
                dt = null;
            }
            return dt;
        }
        public DataTable getRejectedApplicationformsDirect(string ApplicationNo, string divisionId)
        {
            string proc_ = "sp_getRejectedApplicationformsDirect";
            DataTable dt = new DataTable();

            Database objDatabae = DatabaseFactory.CreateDatabase();
            DbCommand objDbCommand = objDatabae.GetStoredProcCommand(proc_);
            try
            {
                objDatabae.AddInParameter(objDbCommand, "@ApplicationNo", DbType.String, ApplicationNo);
                objDatabae.AddInParameter(objDbCommand, "@divisionId", DbType.String, divisionId);
                IDataReader Idr = objDatabae.ExecuteReader(objDbCommand);
                dt.Load(Idr);
            }
            catch
            {
                dt = null;
            }
            return dt;
        }
        public DataTable GetOfficeFeasibilConnectionList(string DiscomId, string ZoneId, string circleId, string DivisionId, string applicationNo, int year, int Status)
        {
            DataTable dt = new DataTable();
            string _Proc = "proc_getOfficeFeasibilConnectionList";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                objDatabase.AddInParameter(objDBCommand, "@DiscomId", DbType.String, DiscomId);
                objDatabase.AddInParameter(objDBCommand, "@ZoneId", DbType.String, ZoneId);
                objDatabase.AddInParameter(objDBCommand, "@circleId", DbType.String, circleId);
                objDatabase.AddInParameter(objDBCommand, "@DivisionId", DbType.String, DivisionId);
                objDatabase.AddInParameter(objDBCommand, "@applicationNo", DbType.String, applicationNo);
                objDatabase.AddInParameter(objDBCommand, "@Year", DbType.Int32, year);
                objDatabase.AddInParameter(objDBCommand, "@status", DbType.Int32, Status);
                IDataReader dr = objDatabase.ExecuteReader(objDBCommand);
                dt.Load(dr);
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                objDBCommand.Dispose();
                objDatabase = null;
            }
            return dt;
        }
        public DataTable GetOfficeFeasibilConnectionListDirect(string DiscomId, string ZoneId, string circleId, string DivisionId, string applicationNo, int year, int Status)
        {
            DataTable dt = new DataTable();
            string _Proc = "proc_getOfficeFeasibilConnectionListDirect";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                objDatabase.AddInParameter(objDBCommand, "@DiscomId", DbType.String, DiscomId);
                objDatabase.AddInParameter(objDBCommand, "@ZoneId", DbType.String, ZoneId);
                objDatabase.AddInParameter(objDBCommand, "@circleId", DbType.String, circleId);
                objDatabase.AddInParameter(objDBCommand, "@DivisionId", DbType.String, DivisionId);
                objDatabase.AddInParameter(objDBCommand, "@applicationNo", DbType.String, applicationNo);
                objDatabase.AddInParameter(objDBCommand, "@Year", DbType.Int32, year);
                objDatabase.AddInParameter(objDBCommand, "@status", DbType.Int32, Status);
                IDataReader dr = objDatabase.ExecuteReader(objDBCommand);
                dt.Load(dr);
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                objDBCommand.Dispose();
                objDatabase = null;
            }
            return dt;
        }

        public DataTable GetFeasibilConnectionList(string DivisionId, string applicationNo, int year, int Status)
        {
            DataTable dt = new DataTable();
            string _Proc = "proc_getFeasibilConnectionList";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                objDatabase.AddInParameter(objDBCommand, "@DivisionId", DbType.String, DivisionId);
                objDatabase.AddInParameter(objDBCommand, "@applicationNo", DbType.String, applicationNo);
                objDatabase.AddInParameter(objDBCommand, "@Year", DbType.Int32, year);
                objDatabase.AddInParameter(objDBCommand, "@status", DbType.Int32, Status);

                IDataReader dr = objDatabase.ExecuteReader(objDBCommand);
                dt.Load(dr);

            }
            catch (Exception)
            {
                throw;
            }
            finally
            {

                objDBCommand.Dispose();
                objDatabase = null;
            }
            return dt;
        }

        public DataTable GetFeasibilConnectionListDirect(string DivisionId, string applicationNo, int year, int Status)
        {

            DataTable dt = new DataTable();
            string _Proc = "proc_getFeasibilConnectionListDirect";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                objDatabase.AddInParameter(objDBCommand, "@DivisionId", DbType.String, DivisionId);
                objDatabase.AddInParameter(objDBCommand, "@applicationNo", DbType.String, applicationNo);
                objDatabase.AddInParameter(objDBCommand, "@Year", DbType.Int32, year);
                objDatabase.AddInParameter(objDBCommand, "@status", DbType.Int32, Status);

                IDataReader dr = objDatabase.ExecuteReader(objDBCommand);
                dt.Load(dr);

            }
            catch (Exception)
            {
                throw;
            }
            finally
            {

                objDBCommand.Dispose();
                objDatabase = null;
            }
            return dt;
        }

        public DataTable GetEstimatedCostPayedList(string DivisionId, string applicationNo, int year, int Status)
        {

            DataTable dt = new DataTable();
            string _Proc = "proc_getEstimatedCostPayedList";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                objDatabase.AddInParameter(objDBCommand, "@DivisionId", DbType.String, DivisionId);
                objDatabase.AddInParameter(objDBCommand, "@applicationNo", DbType.String, applicationNo);
                objDatabase.AddInParameter(objDBCommand, "@Year", DbType.Int32, year);
                objDatabase.AddInParameter(objDBCommand, "@status", DbType.Int32, Status);

                IDataReader dr = objDatabase.ExecuteReader(objDBCommand);
                dt.Load(dr);

            }
            catch (Exception)
            {
                throw;
            }
            finally
            {

                objDBCommand.Dispose();
                objDatabase = null;
            }
            return dt;
        }

        public DataTable GetEstimatedCostPayedListDirect(string DivisionId, string applicationNo, int year, int Status)
        {

            DataTable dt = new DataTable();
            string _Proc = "proc_getEstimatedCostPayedListDirect";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                objDatabase.AddInParameter(objDBCommand, "@DivisionId", DbType.String, DivisionId);
                objDatabase.AddInParameter(objDBCommand, "@applicationNo", DbType.String, applicationNo);
                objDatabase.AddInParameter(objDBCommand, "@Year", DbType.Int32, year);
                objDatabase.AddInParameter(objDBCommand, "@status", DbType.Int32, Status);

                IDataReader dr = objDatabase.ExecuteReader(objDBCommand);
                dt.Load(dr);

            }
            catch (Exception)
            {
                throw;
            }
            finally
            {

                objDBCommand.Dispose();
                objDatabase = null;
            }
            return dt;
        }



        public DataTable GetSubmittedWorkComplitionCertificate(string DivisionId, string applicationNo, int year)
        {
            DataTable dt = new DataTable();
            string _Proc = "Proc_getSubmittedWorkComplitionCertificate";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                objDatabase.AddInParameter(objDBCommand, "@DivisionId", DbType.String, DivisionId);
                objDatabase.AddInParameter(objDBCommand, "@applicationNo", DbType.String, applicationNo);
                objDatabase.AddInParameter(objDBCommand, "@Year", DbType.Int32, year);
                IDataReader dr = objDatabase.ExecuteReader(objDBCommand);
                dt.Load(dr);
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                objDBCommand.Dispose();
                objDatabase = null;
            }
            return dt;
        }

        public DataTable GetSubmittedWorkComplitionCertificateDirect(string DivisionId, string applicationNo, int year)
        {
            DataTable dt = new DataTable();
            string _Proc = "Proc_getSubmittedWorkComplitionCertificateDirect";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                objDatabase.AddInParameter(objDBCommand, "@DivisionId", DbType.String, DivisionId);
                objDatabase.AddInParameter(objDBCommand, "@applicationNo", DbType.String, applicationNo);
                objDatabase.AddInParameter(objDBCommand, "@Year", DbType.Int32, year);
                IDataReader dr = objDatabase.ExecuteReader(objDBCommand);
                dt.Load(dr);
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                objDBCommand.Dispose();
                objDatabase = null;
            }
            return dt;
        }

        public DataTable GetRelesedConnectionList(string DivisionId, string applicationNo, int year)
        {
            DataTable dt = new DataTable();
            string _Proc = "Proc_getReleaseConnectionList";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                objDatabase.AddInParameter(objDBCommand, "@DivisionId", DbType.String, DivisionId);
                objDatabase.AddInParameter(objDBCommand, "@applicationNo", DbType.String, applicationNo);
                objDatabase.AddInParameter(objDBCommand, "@Year", DbType.Int32, year);


                IDataReader dr = objDatabase.ExecuteReader(objDBCommand);
                dt.Load(dr);

            }
            catch (Exception)
            {
                throw;
            }
            finally
            {

                objDBCommand.Dispose();
                objDatabase = null;
            }
            return dt;
        }
        public DataTable GetOfficeRelesedConnectionList(string DiscomId, string ZoneId, string circleId, string DivisionId, string applicationNo, int year)
        {
            DataTable dt = new DataTable();
            string _Proc = "Proc_getOfficeReleaseConnectionList";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                objDatabase.AddInParameter(objDBCommand, "@DiscomId", DbType.String, DiscomId);
                objDatabase.AddInParameter(objDBCommand, "@ZoneId", DbType.String, ZoneId);
                objDatabase.AddInParameter(objDBCommand, "@circleId", DbType.String, circleId);
                objDatabase.AddInParameter(objDBCommand, "@DivisionId", DbType.String, DivisionId);
                objDatabase.AddInParameter(objDBCommand, "@applicationNo", DbType.String, applicationNo);
                objDatabase.AddInParameter(objDBCommand, "@Year", DbType.Int32, year);


                IDataReader dr = objDatabase.ExecuteReader(objDBCommand);
                dt.Load(dr);

            }
            catch (Exception)
            {
                throw;
            }
            finally
            {

                objDBCommand.Dispose();
                objDatabase = null;
            }
            return dt;
        }
        public DataTable GetOfficeRelesedConnectionListDirect(string DiscomId, string ZoneId, string circleId, string DivisionId, string applicationNo, int year)
        {
            DataTable dt = new DataTable();
            string _Proc = "Proc_getOfficeReleaseConnectionListDirect";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                objDatabase.AddInParameter(objDBCommand, "@DiscomId", DbType.String, DiscomId);
                objDatabase.AddInParameter(objDBCommand, "@ZoneId", DbType.String, ZoneId);
                objDatabase.AddInParameter(objDBCommand, "@circleId", DbType.String, circleId);
                objDatabase.AddInParameter(objDBCommand, "@DivisionId", DbType.String, DivisionId);
                objDatabase.AddInParameter(objDBCommand, "@applicationNo", DbType.String, applicationNo);
                objDatabase.AddInParameter(objDBCommand, "@Year", DbType.Int32, year);


                IDataReader dr = objDatabase.ExecuteReader(objDBCommand);
                dt.Load(dr);

            }
            catch (Exception)
            {
                throw;
            }
            finally
            {

                objDBCommand.Dispose();
                objDatabase = null;
            }
            return dt;
        }
        public DataTable GetRelesedConnectionListDirect(string DivisionId, string applicationNo, int year)
        {
            DataTable dt = new DataTable();
            string _Proc = "Proc_getReleaseConnectionListDirect";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                objDatabase.AddInParameter(objDBCommand, "@DivisionId", DbType.String, DivisionId);
                objDatabase.AddInParameter(objDBCommand, "@applicationNo", DbType.String, applicationNo);
                objDatabase.AddInParameter(objDBCommand, "@Year", DbType.Int32, year);
                IDataReader dr = objDatabase.ExecuteReader(objDBCommand);
                dt.Load(dr);

            }
            catch (Exception)
            {
                throw;
            }
            finally
            {

                objDBCommand.Dispose();
                objDatabase = null;
            }
            return dt;
        }
        #region Insert Record of Metering and Connection release

        public DataTable InsertUpdateMeteringAndConnReleaseDetails(Int64 ApplicantId, string MeterCompany, string MeterType, string MeterPhase, string Ipaddress, string CatOfSupply, string ConsumerType, int Manufacture, string MeterManufactureNo, string MeterNoLab, string InstilledCTR, string InstilledPTR, string MeterCTR, string MeterPTR, string InitialReadingKW, string InitialReadingKWH, string InitialReadingKVA, string InitialReadingKVAH, int TotalMeterSealNo, int TotalBoxSealNo, int TotalCTPTChamberNo, string MeterCertificateUrl, string MeterSealingCertificateUrl, string ServiceConnectionNo, string AccountNo, string GroupNo, string BookNo, DateTime DateConnectionRelease, string MeterSealingCertificateNo, string MeterSerialNo,
            string BadgeNumber, int MeterStatus, int RatingMeter, DateTime DataRcv, string StockLoc, DateTime Effcdate, string FulScvalRegis, string MeterId, string MtrConfig, string DigitLeft
            , string PoleNumb, DateTime StartreadDtTime, string strtReadTime, int MF, int NoofloomsLS60, int NoofloomsGT60, string villagecode, string HabitationCode)
        {
            DataTable dt = new DataTable();
            int res = 0;
            string _Proc = "Procs_InsertUpdateMeteringAndConnReleaseDetails";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                objDatabase.AddInParameter(objDBCommand, "@ApplicationId", DbType.Int64, ApplicantId);
                // objDatabase.AddInParameter(objDBCommand, "@MeterNo", DbType.String, MeterNo);
                objDatabase.AddInParameter(objDBCommand, "@MeterCompany", DbType.String, MeterCompany);
                objDatabase.AddInParameter(objDBCommand, "@MeterType", DbType.String, MeterType);
                objDatabase.AddInParameter(objDBCommand, "@MeterPhase", DbType.String, MeterPhase);
                objDatabase.AddInParameter(objDBCommand, "@Ipaddress", DbType.String, Ipaddress);
                // objDatabase.AddInParameter(objDBCommand, "@ConnectionAccNo", DbType.String, ConnectionAccNo);
                objDatabase.AddInParameter(objDBCommand, "@CatOfSupply", DbType.String, CatOfSupply);
                objDatabase.AddInParameter(objDBCommand, "@consumerType", DbType.String, ConsumerType);
                objDatabase.AddInParameter(objDBCommand, "@Manufacture", DbType.Int32, Manufacture);
                objDatabase.AddInParameter(objDBCommand, "@MeterManufactureNo", DbType.String, MeterManufactureNo);
                objDatabase.AddInParameter(objDBCommand, "@MeterNoLab", DbType.String, MeterNoLab);
                objDatabase.AddInParameter(objDBCommand, "@InstilledCTR", DbType.String, InstilledCTR);
                objDatabase.AddInParameter(objDBCommand, "@InstilledPTR", DbType.String, InstilledPTR);
                objDatabase.AddInParameter(objDBCommand, "@MeterCTR", DbType.String, MeterCTR);
                objDatabase.AddInParameter(objDBCommand, "@MeterPTR", DbType.String, MeterPTR);
                objDatabase.AddInParameter(objDBCommand, "@InitialReadingKW", DbType.String, InitialReadingKW);
                objDatabase.AddInParameter(objDBCommand, "@InitialReadingKWH", DbType.String, InitialReadingKWH);
                objDatabase.AddInParameter(objDBCommand, "@InitialReadingKVA", DbType.String, InitialReadingKVA);
                objDatabase.AddInParameter(objDBCommand, "@InitialReadingKVAH", DbType.String, InitialReadingKVAH);
                //  objDatabase.AddInParameter(objDBCommand, "@MeterSealID", DbType.String, MeterSeal);
                objDatabase.AddInParameter(objDBCommand, "@TotalMeterSealNo", DbType.Int32, TotalMeterSealNo);
                // objDatabase.AddInParameter(objDBCommand, "@BoxSealID", DbType.String, BoxSeal);
                objDatabase.AddInParameter(objDBCommand, "@TotalBoxSealNo", DbType.Int32, TotalBoxSealNo);
                // objDatabase.AddInParameter(objDBCommand, "@CTPTChamberID", DbType.String, CTPTChamberNo);
                objDatabase.AddInParameter(objDBCommand, "@TotalCTPTChamberNo", DbType.Int32, TotalCTPTChamberNo);
                objDatabase.AddInParameter(objDBCommand, "@MeterCertificateUrl", DbType.String, MeterCertificateUrl);
                objDatabase.AddInParameter(objDBCommand, "@MeterSealingCertificateUrl", DbType.String, MeterSealingCertificateUrl);
                objDatabase.AddInParameter(objDBCommand, "@ServiceConnectionNo", DbType.String, ServiceConnectionNo);
                objDatabase.AddInParameter(objDBCommand, "@AccountNo", DbType.String, AccountNo);
                objDatabase.AddInParameter(objDBCommand, "@GroupNo", DbType.String, GroupNo);
                objDatabase.AddInParameter(objDBCommand, "@BookNo", DbType.String, BookNo);
                objDatabase.AddInParameter(objDBCommand, "@DateConnectionRelease", DbType.DateTime, DateConnectionRelease);
                objDatabase.AddInParameter(objDBCommand, "@MeterSealingCertificateNo", DbType.String, MeterSealingCertificateNo);
                objDatabase.AddInParameter(objDBCommand, "@MeterSerialNo", DbType.String, MeterSerialNo);
                objDatabase.AddInParameter(objDBCommand, "@BadgeNumber", DbType.String, BadgeNumber);
                objDatabase.AddInParameter(objDBCommand, "@MtrStatusId", DbType.Int32, MeterStatus);
                objDatabase.AddInParameter(objDBCommand, "@MtrRatingId", DbType.Int32, RatingMeter);
                objDatabase.AddInParameter(objDBCommand, "@DataReceived", DbType.DateTime, DataRcv);
                objDatabase.AddInParameter(objDBCommand, "@StockLocation", DbType.String, StockLoc);
                objDatabase.AddInParameter(objDBCommand, "@EffectiveDated", DbType.DateTime, Effcdate);
                objDatabase.AddInParameter(objDBCommand, "@FullScalevalueofRegisters", DbType.String, FulScvalRegis);
                objDatabase.AddInParameter(objDBCommand, "@MeterID", DbType.String, MeterId);
                objDatabase.AddInParameter(objDBCommand, "@MtrConfigurationType", DbType.String, MtrConfig);
                objDatabase.AddInParameter(objDBCommand, "@DigitsLeft", DbType.String, DigitLeft);
                objDatabase.AddInParameter(objDBCommand, "@TFRPoleNumber", DbType.String, PoleNumb);
                objDatabase.AddInParameter(objDBCommand, "@StrReadDateTime", DbType.DateTime, StartreadDtTime);
                objDatabase.AddInParameter(objDBCommand, "@time", DbType.String, strtReadTime);
                objDatabase.AddInParameter(objDBCommand, "@MF", DbType.Int32, MF);
                objDatabase.AddInParameter(objDBCommand, "@NoofloomsLS60", DbType.Int32, NoofloomsLS60);
                objDatabase.AddInParameter(objDBCommand, "@NoofloomsGT60", DbType.Int32, NoofloomsGT60);
                objDatabase.AddInParameter(objDBCommand, "@villagecode", DbType.String, villagecode);
                objDatabase.AddInParameter(objDBCommand, "@HabitationCode", DbType.String, HabitationCode);
                // res = objDatabase.ExecuteNonQuery(objDBCommand);
                IDataReader dr = objDatabase.ExecuteReader(objDBCommand);
                dt.Load(dr);

            }
            catch (Exception)
            {
                throw;
            }
            finally
            {

                objDBCommand.Dispose();
                objDatabase = null;
            }
            //return res;
            return dt;
        }

        public DataSet GetMeterAndConnReleaseDetails(Int64 ApplicationID)
        {
            DataSet dt = new DataSet();
            string _Proc = "Procs_GetMeterAndConnReleaseDetails";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                objDatabase.AddInParameter(objDBCommand, "@ApplicationID", DbType.String, ApplicationID);
                dt = objDatabase.ExecuteDataSet(objDBCommand);
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                objDBCommand.Dispose();
                objDatabase = null;
            }
            return dt;
        }
        public DataSet GetTentativeDate(int flag, int Count, int ApplicationId)
        {
            DataSet dt = new DataSet();
            string _Proc = "proc_getTentativeDate ";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                objDatabase.AddInParameter(objDBCommand, "@flag", DbType.String, flag);
                objDatabase.AddInParameter(objDBCommand, "@Count", DbType.String, Count);
                objDatabase.AddInParameter(objDBCommand, "@ApplicationId", DbType.String, ApplicationId);
                dt = objDatabase.ExecuteDataSet(objDBCommand);
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                objDBCommand.Dispose();
                objDatabase = null;
            }
            return dt;
        }
        public DataTable saveTentativeDate(int flag, string DateType, string ApplicantId, string tdata, int TentativeID = 0)
        {
            DataTable dt = new DataTable();
            string _Proc = "PROC_TentativeDate";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                objDatabase.AddInParameter(objDBCommand, "@flag", DbType.Int32, flag);
                objDatabase.AddInParameter(objDBCommand, "@DateType", DbType.String, DateType);
                objDatabase.AddInParameter(objDBCommand, "@ApplicationId", DbType.String, ApplicantId);
                objDatabase.AddInParameter(objDBCommand, "@tdata", DbType.String, tdata);
                objDatabase.AddInParameter(objDBCommand, "@TentativeID", DbType.Int32, TentativeID);
                IDataReader dr = objDatabase.ExecuteReader(objDBCommand);
                dt.Load(dr);
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                objDBCommand.Dispose();
                objDatabase = null;
            }
            return dt;
        }
        #endregion

        #region  To Get Completed Connection List     By:-Shekher Khare  Date:-15/06/2016


        public DataTable GetCompleteConnectionList(string _year, string _applicationNumber, string divisionId)
        {

            DataTable dt = new DataTable();
            string _Proc = "PROC_GETCOMPLETECONNECTIONLIST";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {

                objDatabase.AddInParameter(objDBCommand, "@YEAR", DbType.Int32, _year);
                objDatabase.AddInParameter(objDBCommand, "@APPLICANTNO", DbType.String, _applicationNumber);
                objDatabase.AddInParameter(objDBCommand, "@DivisionId", DbType.String, divisionId);


                IDataReader dr = objDatabase.ExecuteReader(objDBCommand);
                dt.Load(dr);

            }
            catch (Exception)
            {

                objDBCommand.Dispose();
                objDatabase = null;
            }
            finally
            {

                objDBCommand.Dispose();
                objDatabase = null;
            }
            return dt;
        }

        #endregion
        public DataTable GetCompleteConnectionListDirect(string _year, string _applicationNumber)
        {

            DataTable dt = new DataTable();
            string _Proc = "PROC_GETCOMPLETECONNECTIONLISTDirect";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {

                objDatabase.AddInParameter(objDBCommand, "@YEAR", DbType.Int32, _year);
                objDatabase.AddInParameter(objDBCommand, "@APPLICANTNO", DbType.String, _applicationNumber);

                IDataReader dr = objDatabase.ExecuteReader(objDBCommand);
                dt.Load(dr);

            }
            catch (Exception)
            {

                objDBCommand.Dispose();
                objDatabase = null;
            }
            finally
            {

                objDBCommand.Dispose();
                objDatabase = null;
            }
            return dt;
        }

        #region To Get Revenue Report By:-Shekher Khare Date:-17/06/2016

        public DataTable GetRevenueReport(string _yearNumber, string _applicationNumber, string _paymentType)
        {
            DataTable dt = new DataTable();
            string _Proc = "proc_RevenueReport";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {

                objDatabase.AddInParameter(objDBCommand, "@YEAR", DbType.Int32, _yearNumber);
                objDatabase.AddInParameter(objDBCommand, "@APPLICANTNO", DbType.String, _applicationNumber);
                objDatabase.AddInParameter(objDBCommand, "@PaymentType", DbType.String, _paymentType);

                IDataReader dr = objDatabase.ExecuteReader(objDBCommand);
                dt.Load(dr);

            }
            catch (Exception)
            {

                objDBCommand.Dispose();
                objDatabase = null;
            }
            finally
            {

                objDBCommand.Dispose();
                objDatabase = null;
            }
            return dt;

        }
        #endregion

        public DataTable GetOfficeRevenueReport(string DiscomId, string ZoneId, string circleId, string DivisionId, string _yearNumber, string _applicationNumber, string _paymentType)
        {
            DataTable dt = new DataTable();
            string _Proc = "proc_OfficeRevenueReport";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                objDatabase.AddInParameter(objDBCommand, "@DiscomId", DbType.String, DiscomId);
                objDatabase.AddInParameter(objDBCommand, "@ZoneId", DbType.String, ZoneId);
                objDatabase.AddInParameter(objDBCommand, "@circleId", DbType.String, circleId);
                objDatabase.AddInParameter(objDBCommand, "@DivisionId", DbType.String, DivisionId);
                objDatabase.AddInParameter(objDBCommand, "@YEAR", DbType.Int32, _yearNumber);
                objDatabase.AddInParameter(objDBCommand, "@APPLICANTNO", DbType.String, _applicationNumber);
                objDatabase.AddInParameter(objDBCommand, "@PaymentType", DbType.String, _paymentType);

                IDataReader dr = objDatabase.ExecuteReader(objDBCommand);
                dt.Load(dr);

            }
            catch (Exception)
            {

                objDBCommand.Dispose();
                objDatabase = null;
            }
            finally
            {

                objDBCommand.Dispose();
                objDatabase = null;
            }
            return dt;
        }

        public DataTable GetOfficeRevenueReportDirect(string DiscomId, string ZoneId, string circleId, string DivisionId, string _yearNumber, string _applicationNumber, string _paymentType)
        {
            DataTable dt = new DataTable();
            string _Proc = "proc_OfficeRevenueReportDirect";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                objDatabase.AddInParameter(objDBCommand, "@DiscomId", DbType.String, DiscomId);
                objDatabase.AddInParameter(objDBCommand, "@ZoneId", DbType.String, ZoneId);
                objDatabase.AddInParameter(objDBCommand, "@circleId", DbType.String, circleId);
                objDatabase.AddInParameter(objDBCommand, "@DivisionId", DbType.String, DivisionId);
                objDatabase.AddInParameter(objDBCommand, "@YEAR", DbType.Int32, _yearNumber);
                objDatabase.AddInParameter(objDBCommand, "@APPLICANTNO", DbType.String, _applicationNumber);
                objDatabase.AddInParameter(objDBCommand, "@PaymentType", DbType.String, _paymentType);

                IDataReader dr = objDatabase.ExecuteReader(objDBCommand);
                dt.Load(dr);

            }
            catch (Exception)
            {

                objDBCommand.Dispose();
                objDatabase = null;
            }
            finally
            {

                objDBCommand.Dispose();
                objDatabase = null;
            }
            return dt;

        }
        public DataTable GetRevenueReportDirect(string _yearNumber, string _applicationNumber, string _paymentType, string _divisionId)
        {
            DataTable dt = new DataTable();
            string _Proc = "proc_RevenueReportDirect";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                objDatabase.AddInParameter(objDBCommand, "@YEAR", DbType.Int32, _yearNumber);
                objDatabase.AddInParameter(objDBCommand, "@APPLICANTNO", DbType.String, _applicationNumber);
                objDatabase.AddInParameter(objDBCommand, "@PaymentType", DbType.String, _paymentType);
                objDatabase.AddInParameter(objDBCommand, "@DivisionId", DbType.String, _divisionId);


                IDataReader dr = objDatabase.ExecuteReader(objDBCommand);
                dt.Load(dr);

            }
            catch (Exception)
            {

                objDBCommand.Dispose();
                objDatabase = null;
            }
            finally
            {

                objDBCommand.Dispose();
                objDatabase = null;
            }
            return dt;

        }

        #region Get Detail of User for Update Profile

        public DataTable GetProfileDetails(Int64 UserId)
        {

            DataTable dt = new DataTable();
            string _Proc = "Proc_getProfileDetails";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                objDatabase.AddInParameter(objDBCommand, "@UserId", DbType.Int64, UserId);
                IDataReader dr = objDatabase.ExecuteReader(objDBCommand);
                dt.Load(dr);
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {

                objDBCommand.Dispose();
                objDatabase = null;
            }
            return dt;
        }

        public DataTable GetProfileDetails_LoginId(string LoginId)
        {

            DataTable dt = new DataTable();
            string _Proc = "Proc_getProfileDetails_LoginId";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                objDatabase.AddInParameter(objDBCommand, "@UserId", DbType.String, LoginId);
                IDataReader dr = objDatabase.ExecuteReader(objDBCommand);
                dt.Load(dr);
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {

                objDBCommand.Dispose();
                objDatabase = null;
            }
            return dt;
        }

        #endregion



        public DataTable getPasswordResetRequest(string Emailid, string Mobileno, int procid)
        {

            DataTable dt = new DataTable();
            string _Proc = "Proc_CheckUserIdByEmailAndMobileInsertRequest";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                objDatabase.AddInParameter(objDBCommand, "@Email", DbType.String, Emailid);
                objDatabase.AddInParameter(objDBCommand, "@mobile", DbType.String, Mobileno);
                objDatabase.AddInParameter(objDBCommand, "@procId", DbType.Int32, procid);


                IDataReader dr = objDatabase.ExecuteReader(objDBCommand);
                dt.Load(dr);

            }
            catch (Exception)
            {
                throw;
            }
            finally
            {

                objDBCommand.Dispose();
                objDatabase = null;
            }
            return dt;
        }

        public DataTable updatePassword(int TransId, int UserId, string Password, string PasswordEncrypt, string IPAddress)
        {
            DataTable dt = new DataTable();
            string _Proc = "Proc_UpdatePassword";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                objDatabase.AddInParameter(objDBCommand, "@TransId", DbType.Int32, TransId);
                objDatabase.AddInParameter(objDBCommand, "@UserId", DbType.Int32, UserId);
                objDatabase.AddInParameter(objDBCommand, "@Password", DbType.String, Password);
                objDatabase.AddInParameter(objDBCommand, "@IPAddress", DbType.String, IPAddress);
                objDatabase.AddInParameter(objDBCommand, "@PasswordEncrypt", DbType.String, PasswordEncrypt);

                IDataReader dr = objDatabase.ExecuteReader(objDBCommand);
                dt.Load(dr);

            }
            catch (Exception)
            {
                throw;
            }
            finally
            {

                objDBCommand.Dispose();
                objDatabase = null;
            }
            return dt;
        }

        public int updatePasswordBYuserId(string Password, string encryptPassword, Int64 UserId)
        {
            int r = 0;
            string _Proc = "Proc_UpdatePasswordByUserId";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {

                objDatabase.AddInParameter(objDBCommand, "@userId", DbType.Int32, UserId);
                objDatabase.AddInParameter(objDBCommand, "@Password", DbType.String, Password);
                objDatabase.AddInParameter(objDBCommand, "@encryptPassword", DbType.String, encryptPassword);
                objDatabase.AddInParameter(objDBCommand, "@IpAddress", DbType.String, Common.GetIPAddress());
                objDatabase.AddInParameter(objDBCommand, "@IpPwdChangeAddress", DbType.String, Common.GetIPAddress());

                r = objDatabase.ExecuteNonQuery(objDBCommand);

            }
            catch (Exception)
            {
                throw;
            }
            finally
            {

                objDBCommand.Dispose();
                objDatabase = null;
            }
            return r;
        }

        public DataTable PasswordChange(Int64 userid, string oldpassword, string password, string Newpassword)
        {

            DataTable dt = new DataTable();
            string _Proc = "Proc_ChangePassword";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                objDatabase.AddInParameter(objDBCommand, "@userId", DbType.Int64, userid);
                objDatabase.AddInParameter(objDBCommand, "@oldpassword", DbType.String, oldpassword);
                objDatabase.AddInParameter(objDBCommand, "@password", DbType.String, password);
                objDatabase.AddInParameter(objDBCommand, "@newpassword", DbType.String, Newpassword);
                objDatabase.AddInParameter(objDBCommand, "@ipaddress", DbType.String, Common.GetIPAddress());

                IDataReader dr = objDatabase.ExecuteReader(objDBCommand);
                dt.Load(dr);

            }
            catch (Exception)
            {
                throw;
            }
            finally
            {

                objDBCommand.Dispose();
                objDatabase = null;
            }
            return dt;
        }


        public DataTable GetApplicantDetailsforMail(int Applicationid)
        {

            DataTable dt = new DataTable();
            string _Proc = "Proc_GetApplicantDetailsforMail";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                objDatabase.AddInParameter(objDBCommand, "@applicantid", DbType.Int32, Applicationid);


                IDataReader dr = objDatabase.ExecuteReader(objDBCommand);
                dt.Load(dr);

            }
            catch (Exception)
            {
                throw;
            }
            finally
            {

                objDBCommand.Dispose();
                objDatabase = null;
            }
            return dt;
        }

        public DataTable getUserDetailsforDisp(int Applicationid)
        {

            DataTable dt = new DataTable();
            string _Proc = "Proc_get_UserDetailsforDisp";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                objDatabase.AddInParameter(objDBCommand, "@Applicationid", DbType.Int32, Applicationid);


                IDataReader dr = objDatabase.ExecuteReader(objDBCommand);
                dt.Load(dr);

            }
            catch (Exception)
            {
                throw;
            }
            finally
            {

                objDBCommand.Dispose();
                objDatabase = null;
            }
            return dt;
        }

        public DataSet GetIndependentFederDetails(int ApplicantId)
        {
            DataSet ds = new DataSet();
            string _Proc = "Proc_GetIndependentFeederList";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                objDatabase.AddInParameter(objDBCommand, "@ApplicantId", DbType.String, ApplicantId);
                ds = objDatabase.ExecuteDataSet(objDBCommand);

            }
            catch (Exception)
            {
                throw;
            }
            finally
            {

                objDBCommand.Dispose();
                objDatabase = null;
            }
            return ds;
        }

        public int InsertMeterConnRelChildRecord(Int64 ApplicationID, string MeterSeal, string BoxSeal, string Chamber)
        {
            int r = 0;
            string _Proc = "Procs_InsertMeterConnRelChildRecord";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                objDatabase.AddInParameter(objDBCommand, "@ApplicationID", DbType.Int64, ApplicationID);
                objDatabase.AddInParameter(objDBCommand, "@MeterSeal", DbType.Xml, MeterSeal);
                objDatabase.AddInParameter(objDBCommand, "@BoxSeal", DbType.Xml, BoxSeal);
                objDatabase.AddInParameter(objDBCommand, "@Chamber", DbType.Xml, Chamber);
                r = objDatabase.ExecuteNonQuery(objDBCommand);

            }
            catch (Exception)
            {
                throw;
            }
            finally
            {

                objDBCommand.Dispose();
                objDatabase = null;
            }
            return r;
        }

        public DataTable GetApplicantionDetailsAll(Int64 AppId, string applicationNo, int year)
        {

            DataTable dt = new DataTable();
            string _Proc = "Procs_GetApplicantionDetailsAll";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                objDatabase.AddInParameter(objDBCommand, "@ApplicantID", DbType.Int64, AppId);
                objDatabase.AddInParameter(objDBCommand, "@ApplicatinoNo", DbType.String, applicationNo);
                objDatabase.AddInParameter(objDBCommand, "@Year", DbType.Int32, year);
                IDataReader dr = objDatabase.ExecuteReader(objDBCommand);
                dt.Load(dr);
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                objDBCommand.Dispose();
                objDatabase = null;
            }
            return dt;
        }


        #region calcuLator Method by Radhey on Date (01/07/2016)


        public DataSet GetFederDetails(decimal LoadKVA)
        {
            DataSet ds = new DataSet();
            string _Proc = "Proc_GetFeedertypeDetailsForCalcuLator";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                objDatabase.AddInParameter(objDBCommand, "@LoadKVA", DbType.Decimal, LoadKVA);
                ds = objDatabase.ExecuteDataSet(objDBCommand);

            }
            catch (Exception)
            {
                throw;
            }
            finally
            {

                objDBCommand.Dispose();
                objDatabase = null;
            }
            return ds;
        }

        public DataSet GetAllTotalChargesofFeder(decimal LoadKVA, int ConnectionPowerTypeId, int IndependentrFeederTypeId, string areaType)
        {
            DataSet ds = new DataSet();
            string _Proc = "Proc_GetAllchargesOfFeederForCalculator";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                objDatabase.AddInParameter(objDBCommand, "@LoadKVA", DbType.Decimal, LoadKVA);
                objDatabase.AddInParameter(objDBCommand, "@ConnectionPowerTypeId", DbType.Int32, ConnectionPowerTypeId);
                objDatabase.AddInParameter(objDBCommand, "@IndependentrFeederTypeId", DbType.Int32, IndependentrFeederTypeId);
                objDatabase.AddInParameter(objDBCommand, "@areaType", DbType.String, areaType);
                ds = objDatabase.ExecuteDataSet(objDBCommand);

            }
            catch (Exception)
            {
                throw;
            }
            finally
            {

                objDBCommand.Dispose();
                objDatabase = null;
            }
            return ds;
        }

        public DataTable getLineCharges(decimal LoadKVA, int lineid)
        {

            DataTable dt = new DataTable();
            string _Proc = "Proc_getLineChargesForCalculator";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                objDatabase.AddInParameter(objDBCommand, "@LoadKVA", DbType.Decimal, LoadKVA);
                objDatabase.AddInParameter(objDBCommand, "@Lineid", DbType.Int32, lineid);
                IDataReader dr = objDatabase.ExecuteReader(objDBCommand);
                dt.Load(dr);
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {

                objDBCommand.Dispose();
                objDatabase = null;
            }
            return dt;
        }



        public DataSet GetAllTotalUnitRate(decimal LoadKVA, int ConnectionPowerTypeId, int IndependentrFeederTypeId, string areaType)
        {
            DataSet ds = new DataSet();
            string _Proc = "Procs_getUnitRate";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                objDatabase.AddInParameter(objDBCommand, "@LoadKVA", DbType.Decimal, LoadKVA);
                objDatabase.AddInParameter(objDBCommand, "@ConnectionPowerTypeId", DbType.Int32, ConnectionPowerTypeId);
                objDatabase.AddInParameter(objDBCommand, "@IndependentrFeederTypeId", DbType.Int32, IndependentrFeederTypeId);
                objDatabase.AddInParameter(objDBCommand, "@areaType", DbType.String, areaType);
                ds = objDatabase.ExecuteDataSet(objDBCommand);

            }
            catch (Exception)
            {
                throw;
            }
            finally
            {

                objDBCommand.Dispose();
                objDatabase = null;
            }
            return ds;
        }



        public DataSet GetCDBDetails(int CDBID)
        {
            DataSet ds = new DataSet();
            string _Proc = "Procs_GetCDBDetails";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                objDatabase.AddInParameter(objDBCommand, "@CDBID", DbType.Int32, CDBID);
                ds = objDatabase.ExecuteDataSet(objDBCommand);

            }
            catch (Exception)
            {
                throw;
            }
            finally
            {

                objDBCommand.Dispose();
                objDatabase = null;
            }
            return ds;
        }


        #endregion


        public int InsertQuery(Int64 ApplicationID, string Query)
        {
            int r = 0;
            string _Proc = "Procs_InsertApplicantQuery";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                objDatabase.AddInParameter(objDBCommand, "@ApplicationID", DbType.Int64, ApplicationID);
                objDatabase.AddInParameter(objDBCommand, "@Query", DbType.String, Query);
                r = objDatabase.ExecuteNonQuery(objDBCommand);

            }
            catch (Exception)
            {
                throw;
            }
            finally
            {

                objDBCommand.Dispose();
                objDatabase = null;
            }
            return r;
        }

        #region InsertQuery_Aditi

        public DataTable InsertQuerynew(Int64 ApplicationID, string Query, string CurrentStep, string rply)
        {
            DataTable dt = new DataTable();
            string _Proc = "Procs_InsertApplicantQuery";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                objDatabase.AddInParameter(objDBCommand, "@ApplicationID", DbType.Int64, ApplicationID);
                objDatabase.AddInParameter(objDBCommand, "@Query", DbType.String, Query);
                objDatabase.AddInParameter(objDBCommand, "@CurrentStep", DbType.String, CurrentStep);
                objDatabase.AddInParameter(objDBCommand, "@rply", DbType.String, rply);
                IDataReader dr = objDatabase.ExecuteReader(objDBCommand);
                dt.Load(dr);
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                objDBCommand.Dispose();
                objDatabase = null;
            }
            return dt;
        }

        public DataTable UpdateSupplySdoCode(Int64 ApplicantId, string SuppTypeCode, string SDOOffice)
        {
            DataTable dt = new DataTable();
            int res = 0;
            string _Proc = "proc_UpdateSupplySdoCode";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                objDatabase.AddInParameter(objDBCommand, "@ApplicationId", DbType.Int64, ApplicantId);
                objDatabase.AddInParameter(objDBCommand, "@SuppTypeCode", DbType.String, SuppTypeCode);
                objDatabase.AddInParameter(objDBCommand, "@SDOOffice", DbType.String, SDOOffice);
                IDataReader dr = objDatabase.ExecuteReader(objDBCommand);
                dt.Load(dr);

            }
            catch (Exception)
            {
                throw;
            }
            finally
            {

                objDBCommand.Dispose();
                objDatabase = null;
            }
            return dt;
        }

        #endregion

        // for Connection Release report

        public DataTable GetMeterAndConnReleaseCertificate(Int64 ApplicationID)
        {

            DataTable dt = new DataTable();
            string _Proc = "Procs_GetMeterAndConnReleaseCertificate";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                objDatabase.AddInParameter(objDBCommand, "@ApplicationID", DbType.Int64, ApplicationID);
                IDataReader dr = objDatabase.ExecuteReader(objDBCommand);
                dt.Load(dr);
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                objDBCommand.Dispose();
                objDatabase = null;
            }
            return dt;
        }

        public int UpdateEnergisationCertificateUrl(Int64 ApplicationID, string EnergisationCertificateUrl)
        {
            int r = 0;
            string _Proc = "Procs_UpdateEnergisationCertificateUrl";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                objDatabase.AddInParameter(objDBCommand, "@ApplicationID", DbType.Int64, ApplicationID);
                objDatabase.AddInParameter(objDBCommand, "@EnergisationCertificateUrl", DbType.String, EnergisationCertificateUrl);
                r = objDatabase.ExecuteNonQuery(objDBCommand);

            }
            catch (Exception)
            {
                throw;
            }
            finally
            {

                objDBCommand.Dispose();
                objDatabase = null;
            }
            return r;
        }

        #region Step Wise Count
        public DataTable GetStepWiseCount(long ExternalUserId)
        {
            DataTable dt = new DataTable();
            string _Proc = "Proc_GetStepWiseCountReport";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                objDatabase.AddInParameter(objDBCommand, "@ExternalUserId", DbType.Int64, ExternalUserId);
                IDataReader dr = objDatabase.ExecuteReader(objDBCommand);
                dt.Load(dr);
            }
            catch (Exception)
            {
                objDBCommand.Dispose();
                objDatabase = null;
            }
            finally
            {
                objDBCommand.Dispose();
                objDatabase = null;
            }
            return dt;
        }
        #endregion
        #region Progress Summary Report
        public DataSet GetProgressSummaryReport(long ExternalUserId, string DiscomId, string ZoneId, string circleId, string DivisionId)
        {
            DataSet ds = new DataSet();
            DataTable dt = new DataTable();
            string _proc = "Proc_GetProgressSummaryReport";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDbCommand = objDatabase.GetStoredProcCommand(_proc);
            objDatabase.AddInParameter(objDbCommand, "@externalUserId", DbType.Int64, ExternalUserId);
            objDatabase.AddInParameter(objDbCommand, "@DiscomId", DbType.String, DiscomId);
            objDatabase.AddInParameter(objDbCommand, "@ZoneId", DbType.String, ZoneId);
            objDatabase.AddInParameter(objDbCommand, "@circleId", DbType.String, circleId);
            objDatabase.AddInParameter(objDbCommand, "@DivisionId", DbType.String, DivisionId);
            try
            {
                ds = objDatabase.ExecuteDataSet(objDbCommand);
                //IDataReader dr = objDatabase.ExecuteReader(objDbCommand);
                //dt.Load(dr);
            }
            catch
            {
                dt = null;
            }
            return ds;
        }
        #endregion

        public DataTable getNiveshMitraPaymentDetails(DateTime RecocileFromDate)
        {

            DataTable dt = new DataTable();
            string _Proc = "PROC_getPaymentDetails_Division_WindowService";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            objDatabase.AddInParameter(objDBCommand, "@ReconcileFromDate", DbType.DateTime, RecocileFromDate);
            try
            {


                IDataReader dr = objDatabase.ExecuteReader(objDBCommand);
                dt.Load(dr);

            }
            catch (Exception)
            {
                throw;
            }
            finally
            {

                objDBCommand.Dispose();
                objDatabase = null;
            }
            return dt;
        }


        public DataTable getDivisionDetailsByApplicantID(Int64 ApplicantID)
        {

            DataTable dt = new DataTable();
            string _Proc = "proc_GetDivisionDetailsByApplicantId";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                objDatabase.AddInParameter(objDBCommand, "@applicantId", DbType.Int64, ApplicantID);

                IDataReader dr = objDatabase.ExecuteReader(objDBCommand);
                dt.Load(dr);

            }
            catch (Exception)
            {
                throw;
            }
            finally
            {

                objDBCommand.Dispose();
                objDatabase = null;
            }
            return dt;
        }
        public DataTable getProc_getPendingFeasibilityWithinSevenDays(string DivisionID)
        {

            DataTable dt = new DataTable();
            string _Proc = "Proc_getPendingFeasibilityWithinSevenDays";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                objDatabase.AddInParameter(objDBCommand, "@DivisionID", DbType.String, DivisionID);

                IDataReader dr = objDatabase.ExecuteReader(objDBCommand);
                dt.Load(dr);

            }
            catch (Exception)
            {
                throw;
            }
            finally
            {

                objDBCommand.Dispose();
                objDatabase = null;
            }
            return dt;
        }
        public DataTable getProc_getApplicanttoSendSMSForEstimateCost(string DivisionID)
        {

            DataTable dt = new DataTable();
            string _Proc = "Proc_GetFeasibilityDoneToSubmitEstimateCost";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                objDatabase.AddInParameter(objDBCommand, "@DivisionID", DbType.String, DivisionID);

                IDataReader dr = objDatabase.ExecuteReader(objDBCommand);
                dt.Load(dr);

            }
            catch (Exception)
            {
                throw;
            }
            finally
            {

                objDBCommand.Dispose();
                objDatabase = null;
            }
            return dt;
        }
        public DataTable getProc_getApplicationListtoRelaseConnection(string DivisionID)
        {

            DataTable dt = new DataTable();
            string _Proc = "Proc_getPendingConnectionReleaseApplication";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                objDatabase.AddInParameter(objDBCommand, "@DivisionID", DbType.String, DivisionID);

                IDataReader dr = objDatabase.ExecuteReader(objDBCommand);
                dt.Load(dr);

            }
            catch (Exception)
            {
                throw;
            }
            finally
            {

                objDBCommand.Dispose();
                objDatabase = null;
            }
            return dt;
        }


        public int InsertApplicationCurrentStatus(long ApplicationId, string status)
        {
            int res = 0;
            try
            {
                string proc_ = "Proc_InsertApplicationStatus";
                Database objDatabase = DatabaseFactory.CreateDatabase();
                DbCommand objDbCommand = objDatabase.GetStoredProcCommand(proc_);
                objDatabase.AddInParameter(objDbCommand, "@applicationId", DbType.Int64, ApplicationId);
                objDatabase.AddInParameter(objDbCommand, "@status", DbType.String, status);

                res = objDatabase.ExecuteNonQuery(objDbCommand);

            }
            catch (Exception ex)
            {
                return 0;
            }
            return res;
        }
        public DataTable UpdatePendingVerifyPayment(long ApplicationId)
        {
            DataTable dt = new DataTable();
            try
            {
                string proc_ = "Proc_UpdateVerifyPayment";
                Database objDatabase = DatabaseFactory.CreateDatabase();
                DbCommand objDbCommand = objDatabase.GetStoredProcCommand(proc_);
                objDatabase.AddInParameter(objDbCommand, "@applicationId", DbType.Int64, ApplicationId);
                IDataReader dr = objDatabase.ExecuteReader(objDbCommand);
                dt.Load(dr);

            }
            catch (Exception ex)
            {
                return dt = null;
            }
            return dt;
        }
        public DataTable GetApplicantPaymentDetailsForMail(Int64 ApplicantID, Int64 UserID, string PaymentType)
        {
            DataTable dt = new DataTable();
            string _proc = "Procs_GetApplicantPaymentDetailsForMail";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDbCommand = objDatabase.GetStoredProcCommand(_proc);
            objDatabase.AddInParameter(objDbCommand, "@ApplicantID", DbType.Int64, ApplicantID);
            objDatabase.AddInParameter(objDbCommand, "@UserID", DbType.Int64, UserID);
            objDatabase.AddInParameter(objDbCommand, "@PaymentType", DbType.String, PaymentType);
            try
            {
                IDataReader dr = objDatabase.ExecuteReader(objDbCommand);
                dt.Load(dr);
            }
            catch
            {
                dt = null;
            }
            return dt;
        }
        public DataTable GetPendingVerifyPaymentList(string DivisionId, string applicationNo, int year, int Status)
        {

            DataTable dt = new DataTable();
            string _Proc = "proc_getPendingVerifyPayment";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                objDatabase.AddInParameter(objDBCommand, "@DivisionId", DbType.String, DivisionId);
                objDatabase.AddInParameter(objDBCommand, "@applicationNo", DbType.String, applicationNo);
                objDatabase.AddInParameter(objDBCommand, "@Year", DbType.Int32, year);
                objDatabase.AddInParameter(objDBCommand, "@status", DbType.Int32, Status);

                IDataReader dr = objDatabase.ExecuteReader(objDBCommand);
                dt.Load(dr);

            }
            catch (Exception)
            {
                throw;
            }
            finally
            {

                objDBCommand.Dispose();
                objDatabase = null;
            }
            return dt;
        }
        #region Riya
        public DataTable GetVillageHabitaion(string DivisionId, string userType, string villageName, string HabitaionName)
        {

            DataTable dt = new DataTable();
            string _Proc = "proc_getVillageHabitaion";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                objDatabase.AddInParameter(objDBCommand, "@DivisionId", DbType.String, DivisionId);
                objDatabase.AddInParameter(objDBCommand, "@userType", DbType.String, userType);
                objDatabase.AddInParameter(objDBCommand, "@villageName", DbType.String, villageName);
                objDatabase.AddInParameter(objDBCommand, "@HabitaionName", DbType.String, HabitaionName);

                IDataReader dr = objDatabase.ExecuteReader(objDBCommand);
                dt.Load(dr);

            }
            catch (Exception)
            {
                throw;
            }
            finally
            {

                objDBCommand.Dispose();
                objDatabase = null;
            }
            return dt;
        }

        #endregion
        #region Muheeb
        public DataTable GetMeterStatus()
        {
            DataTable dt = new DataTable();
            string _Proc = "Procs_GetMeterStats";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                IDataReader dr = objDatabase.ExecuteReader(objDBCommand);
                dt.Load(dr);
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                objDBCommand.Dispose();
                objDatabase = null;
            }
            return dt;

        }
        public DataTable GetMeterrating()
        {
            DataTable dt = new DataTable();
            string _Proc = "Procs_GetMeterrating";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                IDataReader dr = objDatabase.ExecuteReader(objDBCommand);
                dt.Load(dr);
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                objDBCommand.Dispose();
                objDatabase = null;
            }
            return dt;

        }
        #endregion
        public DataTable GetManufacture(string areaType, int descomId)
        {
            DataTable dt = new DataTable();
            string _Proc = "getAllManufacture";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                objDatabase.AddInParameter(objDBCommand, "@AreaType", DbType.String, areaType);
                objDatabase.AddInParameter(objDBCommand, "@descomId", DbType.Int32, descomId);
                IDataReader dr = objDatabase.ExecuteReader(objDBCommand);
                dt.Load(dr);
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                objDBCommand.Dispose();
                objDatabase = null;
            }
            return dt;

        }

        #region Aditi_CategorySupply
        public DataTable Get_CategorySupply(string areaType, string flag, string SupplyPurpose)
        {
            DataTable dt = new DataTable();
            string _proc = "proc_Get_CategorySupply";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_proc);
            try
            {
                objDatabase.AddInParameter(objDBCommand, "@AreaType", DbType.String, areaType);
                objDatabase.AddInParameter(objDBCommand, "@Flag", DbType.String, flag);
                objDatabase.AddInParameter(objDBCommand, "@SupplyPurpose", DbType.String, SupplyPurpose);
                IDataReader dr = objDatabase.ExecuteReader(objDBCommand);
                dt.Load(dr);
            }
            catch (Exception)
            { throw; }
            finally
            {
                objDBCommand.Dispose();
                objDatabase = null;
            }
            return dt;
        }

        public DataTable getsecurityamount(string AreaType, string SubCategory, int Load, int IsBPL, string connType)
        {
            DataTable dt = new DataTable();
            string _proc = "Proc_GetSecurityDepositAmount";
            Database objdatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objdatabase.GetStoredProcCommand(_proc);
            try
            {
                objdatabase.AddInParameter(objDBCommand, "@AreaType", DbType.String, AreaType);
                objdatabase.AddInParameter(objDBCommand, "@SubCategory", DbType.String, SubCategory);
                objdatabase.AddInParameter(objDBCommand, "@Load", DbType.Int16, Load);
                objdatabase.AddInParameter(objDBCommand, "@IsBPL", DbType.Int16, IsBPL);
                objdatabase.AddInParameter(objDBCommand, "@ConnType", DbType.String, connType);
                IDataReader dr = objdatabase.ExecuteReader(objDBCommand);
                dt.Load(dr);
            }
            catch (Exception)
            { throw; }
            finally
            {
                objDBCommand.Dispose();
                objdatabase = null;
            }
            return dt;
        }
        #endregion

        public DataTable GetSupplyCategory(int LMVId)
        {
            DataTable dt = new DataTable();
            string _Proc = "proc_getCategorySupply";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                objDatabase.AddInParameter(objDBCommand, "@LMVID", DbType.Int32, LMVId);
                IDataReader dr = objDatabase.ExecuteReader(objDBCommand);
                dt.Load(dr);
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                objDBCommand.Dispose();
                objDatabase = null;
            }
            return dt;

        }
        public DataTable GetMetertype(long ApplicationId)
        {
            DataTable dt = new DataTable();
            string _Proc = "proc_getAllMeterType";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                objDatabase.AddInParameter(objDBCommand, "@ApplicationId", DbType.Int64, ApplicationId);
                IDataReader dr = objDatabase.ExecuteReader(objDBCommand);
                dt.Load(dr);
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                objDBCommand.Dispose();
                objDatabase = null;
            }
            return dt;

        }
        public DataTable GetMeterConfiguration(long ApplicationId)
        {
            DataTable dt = new DataTable();
            string _Proc = "proc_getMeterConfigurationType";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                objDatabase.AddInParameter(objDBCommand, "@ApplicationId", DbType.Int64, ApplicationId);
                IDataReader dr = objDatabase.ExecuteReader(objDBCommand);
                dt.Load(dr);
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                objDBCommand.Dispose();
                objDatabase = null;
            }
            return dt;

        }
        #region SDO_DashBoardCount And

        public DataTable getSDO_DashBoardCount(string SDoid)
        {

            DataTable dt = new DataTable();
            string _Proc = "Proc_SDODashboardCount_Div";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                objDatabase.AddInParameter(objDBCommand, "@SDOId", DbType.String, SDoid);

                IDataReader dr = objDatabase.ExecuteReader(objDBCommand);
                dt.Load(dr);

            }
            catch (Exception)
            {
                throw;
            }
            finally
            {

                objDBCommand.Dispose();
                objDatabase = null;
            }
            return dt;
        }
        public DataTable getNewConnectionListDirect_SDO(string SDOId, string applicationNo, int year, int Procid = 0, string DivId = "0")
        {

            DataTable dt = new DataTable();
            string _Proc = "Proc_NewConnectionListFor_SDO";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                objDatabase.AddInParameter(objDBCommand, "@SDOId", DbType.String, SDOId);
                objDatabase.AddInParameter(objDBCommand, "@applicationNo", DbType.String, applicationNo ?? "0");
                objDatabase.AddInParameter(objDBCommand, "@Year", DbType.Int32, year > 0 ? year : 0);
                objDatabase.AddInParameter(objDBCommand, "@Procid", DbType.Int32, Procid > 0 ? Procid : 0);
                objDatabase.AddInParameter(objDBCommand, "@divsionid", DbType.String, DivId ?? "0");


                IDataReader dr = objDatabase.ExecuteReader(objDBCommand);
                dt.Load(dr);

            }
            catch (Exception)
            {
                throw;
            }
            finally
            {

                objDBCommand.Dispose();
                objDatabase = null;
            }
            return dt;
        }

        #endregion

        //#region SDO

        //public DataTable getSDO_DashBoardCount(string SDoid)
        //{

        //    DataTable dt = new DataTable();
        //    string _Proc = "Proc_SDODashboardCount_Div";
        //    Database objDatabase = DatabaseFactory.CreateDatabase();
        //    DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
        //    try
        //    {
        //        objDatabase.AddInParameter(objDBCommand, "@SDOId", DbType.String, SDoid);

        //        IDataReader dr = objDatabase.ExecuteReader(objDBCommand);
        //        dt.Load(dr);

        //    }
        //    catch (Exception)
        //    {
        //        throw;
        //    }
        //    finally
        //    {

        //        objDBCommand.Dispose();
        //        objDatabase = null;
        //    }
        //    return dt;
        //}
        //public DataTable getNewConnectionListDirect_SDO(string SDOId, string applicationNo, int year)
        //{

        //    DataTable dt = new DataTable();
        //    string _Proc = "Proc_NewConnectionListFor_SDO";
        //    Database objDatabase = DatabaseFactory.CreateDatabase();
        //    DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
        //    try
        //    {
        //        objDatabase.AddInParameter(objDBCommand, "@SDOId", DbType.String, SDOId);
        //        objDatabase.AddInParameter(objDBCommand, "@applicationNo", DbType.String, applicationNo ?? "0");
        //        objDatabase.AddInParameter(objDBCommand, "@Year", DbType.Int32, year > 0 ? year : 0);


        //        IDataReader dr = objDatabase.ExecuteReader(objDBCommand);
        //        dt.Load(dr);

        //    }
        //    catch (Exception)
        //    {
        //        throw;
        //    }
        //    finally
        //    {

        //        objDBCommand.Dispose();
        //        objDatabase = null;
        //    }
        //    return dt;
        //}

        //#endregion

        public DataTable getSDO()
        {

            DataTable dt = new DataTable();
            string _Proc = "proc_getSDO";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {

                IDataReader dr = objDatabase.ExecuteReader(objDBCommand);
                dt.Load(dr);

            }
            catch (Exception)
            {
                throw;
            }
            finally
            {

                objDBCommand.Dispose();
                objDatabase = null;
            }
            return dt;
        }

        public DataTable AssingToSDO(Int64 ApplicationID, string divisionId, int SDOId, string status)
        {
            DataTable dt = new DataTable();
            string _Proc = "proc_AssignSDOByDivision";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                objDatabase.AddInParameter(objDBCommand, "@applicantId", DbType.Int64, ApplicationID);
                objDatabase.AddInParameter(objDBCommand, "@divisionId", DbType.String, divisionId);
                objDatabase.AddInParameter(objDBCommand, "@SDOId", DbType.Int64, SDOId);
                objDatabase.AddInParameter(objDBCommand, "@status", DbType.String, status);
                IDataReader dr = objDatabase.ExecuteReader(objDBCommand);
                dt.Load(dr);

            }
            catch (Exception)
            {
                dt = null;
            }
            finally
            {

                objDBCommand.Dispose();
                objDatabase = null;
            }
            return dt;
        }

        #region Muheeb
        public DataTable GetSDOOffice(int DivId)
        {
            DataTable dt = new DataTable();
            string _Proc = "Procs_GetSDOOffice";
            Database objDatabase = DatabaseFactory.CreateDatabase();

            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                objDatabase.AddInParameter(objDBCommand, "@DivisionId", DbType.Int32, DivId);
                IDataReader dr = objDatabase.ExecuteReader(objDBCommand);
                dt.Load(dr);
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                objDBCommand.Dispose();
                objDatabase = null;
            }
            return dt;

        }

        public DataTable GetSDOCode(int DivId, string userType, long applicantId)
        {
            DataTable dt = new DataTable();
            string _Proc = "Procs_GetSDOCode";
            Database objDatabase = DatabaseFactory.CreateDatabase();

            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                objDatabase.AddInParameter(objDBCommand, "@DivisionId", DbType.Int32, DivId);
                objDatabase.AddInParameter(objDBCommand, "@userType", DbType.String, userType);
                objDatabase.AddInParameter(objDBCommand, "@applicantId", DbType.Int32, applicantId);
                IDataReader dr = objDatabase.ExecuteReader(objDBCommand);
                dt.Load(dr);
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                objDBCommand.Dispose();
                objDatabase = null;
            }
            return dt;

        }
        public DataTable GetTownDropdown()
        {
            DataTable dt = new DataTable();
            string _Proc = "Procs_GetTownDetails";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                IDataReader dr = objDatabase.ExecuteReader(objDBCommand);
                dt.Load(dr);
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                objDBCommand.Dispose();
                objDatabase = null;
            }
            return dt;

        }
        public DataTable GetCustomerClass(int ApplicationId = 0)
        {
            DataTable dt = new DataTable();
            string _Proc = "Procs_GetCustomerClass";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                objDatabase.AddInParameter(objDBCommand, "@ApplicationId", DbType.Int32, ApplicationId);
                IDataReader dr = objDatabase.ExecuteReader(objDBCommand);
                dt.Load(dr);
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                objDBCommand.Dispose();
                objDatabase = null;
            }
            return dt;

        }

        #endregion
        public DataTable GetSDOCodeById(long applicantId)
        {
            DataTable dt = new DataTable();
            string _Proc = "proc_getSDOCodeById";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                objDatabase.AddInParameter(objDBCommand, "@applicantId", DbType.Int64, applicantId);
                IDataReader dr = objDatabase.ExecuteReader(objDBCommand);
                dt.Load(dr);
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                objDBCommand.Dispose();
                objDatabase = null;
            }
            return dt;

        }

        public DataTable getCSCConnectionList(long UserId, string applicationNo, int year, bool flag)
        {

            DataTable dt = new DataTable();
            string _Proc = "Proc_getCSCNewConnectionList";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                objDatabase.AddInParameter(objDBCommand, "@userId", DbType.Int64, UserId);
                objDatabase.AddInParameter(objDBCommand, "@applicationNo", DbType.String, applicationNo);
                objDatabase.AddInParameter(objDBCommand, "@Year", DbType.Int32, year);
                objDatabase.AddInParameter(objDBCommand, "@flag", DbType.Boolean, flag);
                IDataReader dr = objDatabase.ExecuteReader(objDBCommand);
                dt.Load(dr);

            }
            catch (Exception)
            {
                throw;
            }
            finally
            {

                objDBCommand.Dispose();
                objDatabase = null;
            }
            return dt;
        }
        public DataTable GetSDOList(string DivisionId)
        {
            DataTable dt = new DataTable();
            string _Proc = "proc_getAllSDOList";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                objDatabase.AddInParameter(objDBCommand, "@DivisionId", DbType.String, DivisionId);
                IDataReader dr = objDatabase.ExecuteReader(objDBCommand);
                dt.Load(dr);

            }
            catch (Exception)
            {
                throw;
            }
            finally
            {

                objDBCommand.Dispose();
                objDatabase = null;
            }
            return dt;
        }

        public int UpdateSDPDetails(Int64 UserID, string divisionId, string SDOName, string SDOAreaName, string Mobile, string EmailId)
        {
            int i = 0;
            string _proc = "proc_updateSDO";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDbCommand = objDatabase.GetStoredProcCommand(_proc);
            objDatabase.AddInParameter(objDbCommand, "@UserID", DbType.Int64, UserID);
            objDatabase.AddInParameter(objDbCommand, "@divisionId", DbType.String, divisionId);
            objDatabase.AddInParameter(objDbCommand, "@SDOName", DbType.String, SDOName);
            objDatabase.AddInParameter(objDbCommand, "@SDOAreaName", DbType.String, SDOAreaName);
            objDatabase.AddInParameter(objDbCommand, "@Mobile", DbType.String, Mobile);
            objDatabase.AddInParameter(objDbCommand, "@EmailId", DbType.String, EmailId);
            try
            {
                i = objDatabase.ExecuteNonQuery(objDbCommand);
            }
            catch (Exception ex)
            {
                i = 0;
            }
            return i;
        }


        #region Ujjval
        public DataTable getPendingProFeeByDivision(string DivisionId, string applicationNo, int year, int AppId)
        {
            DataTable dt = new DataTable();
            string _Proc = "Proc_get_DivWisePendingFeeApplicant";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                objDatabase.AddInParameter(objDBCommand, "@DivisionId", DbType.String, DivisionId);
                objDatabase.AddInParameter(objDBCommand, "@applicationNo", DbType.String, applicationNo);
                objDatabase.AddInParameter(objDBCommand, "@Year", DbType.Int32, year);
                objDatabase.AddInParameter(objDBCommand, "@Applicationid", DbType.Int32, AppId);

                IDataReader dr = objDatabase.ExecuteReader(objDBCommand);
                dt.Load(dr);
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {

                objDBCommand.Dispose();
                objDatabase = null;
            }
            return dt;
        }


        public DataTable getPendingEstimationFeeByDivision(string DivisionId, string applicationNo, int year, int AppId)
        {
            DataTable dt = new DataTable();
            string _Proc = "Proc_get_DivWisePendingEstimationFeeApplicant";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                objDatabase.AddInParameter(objDBCommand, "@DivisionId", DbType.String, DivisionId);
                objDatabase.AddInParameter(objDBCommand, "@applicationNo", DbType.String, applicationNo);
                objDatabase.AddInParameter(objDBCommand, "@Year", DbType.Int32, year);
                objDatabase.AddInParameter(objDBCommand, "@Applicationid", DbType.Int32, AppId);

                IDataReader dr = objDatabase.ExecuteReader(objDBCommand);
                dt.Load(dr);
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {

                objDBCommand.Dispose();
                objDatabase = null;
            }
            return dt;
        }


        public DataTable getPendingProFeeAppDtl(Int64 AppId)
        {
            DataTable dt = new DataTable();
            string _Proc = "Proc_GetPendProFeeAppDtl";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                objDatabase.AddInParameter(objDBCommand, "@Applicationid", DbType.Int64, AppId);
                IDataReader dr = objDatabase.ExecuteReader(objDBCommand);
                dt.Load(dr);

            }
            catch (Exception)
            {
                throw;
            }
            finally
            {

                objDBCommand.Dispose();
                objDatabase = null;
            }
            return dt;
        }

        public DataTable getPendingEstFeeAppDtl(Int64 AppId)
        {
            DataTable dt = new DataTable();
            string _Proc = "Proc_GetPendEstimationFeeAppDtl";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                objDatabase.AddInParameter(objDBCommand, "@Applicationid", DbType.Int64, AppId);
                IDataReader dr = objDatabase.ExecuteReader(objDBCommand);
                dt.Load(dr);

            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                objDBCommand.Dispose();
                objDatabase = null;
            }
            return dt;
        }


        public DataTable getPendingWorkCompeltionList(string divisionId, string applicationNo, int year)
        {

            DataTable dt = new DataTable();
            string _Proc = "Proc_getPendingWorkCompletioListByDiv";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                objDatabase.AddInParameter(objDBCommand, "@DivisionId", DbType.String, divisionId);
                objDatabase.AddInParameter(objDBCommand, "@applicationNo", DbType.String, applicationNo);
                objDatabase.AddInParameter(objDBCommand, "@Year", DbType.Int32, year);
                IDataReader dr = objDatabase.ExecuteReader(objDBCommand);
                dt.Load(dr);
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {

                objDBCommand.Dispose();
                objDatabase = null;
            }
            return dt;
        }

        public DataTable getDivisionWisePendingSummary(string DivisionId, DateTime DateFrom, DateTime DateTo)
        {
            DataTable dt = new DataTable();
            Database objDb = DatabaseFactory.CreateDatabase();
            DbCommand objCmd = objDb.GetStoredProcCommand("Proc_GetDivisionWisePendingSummary");
            try
            {

                //objDb.AddInParameter(objCmd, "@userID", DbType.Int64, UserId);
                objDb.AddInParameter(objCmd, "@DivisionId", DbType.String, DivisionId);
                objDb.AddInParameter(objCmd, "@DateFrom", DbType.DateTime, DateFrom);
                objDb.AddInParameter(objCmd, "@DateTo", DbType.DateTime, DateTo);
                IDataReader dr = objDb.ExecuteReader(objCmd);
                dt.Load(dr);
            }
            catch (Exception)
            {
                dt = null;
                throw;
            }
            finally
            {
                objCmd.Dispose();
                objDb = null;
            }
            return dt;
        }
        #endregion

        #region ujjval
        public string insertTFRDetail(long applicationId, bool isTFR, int distributionMainCategory, string successCertiUrl, string remarks, string ipAddress)
        {
            int i;
            Database objdatabase = DatabaseFactory.CreateDatabase();
            DbCommand objdbcommand = objdatabase.GetStoredProcCommand("Proc_InsertTFRDetail");
            objdatabase.AddInParameter(objdbcommand, "@applicationId", DbType.Int64, applicationId);
            objdatabase.AddInParameter(objdbcommand, "@isTFR", DbType.Boolean, isTFR);
            objdatabase.AddInParameter(objdbcommand, "@distributionMainCategory", DbType.Int32, distributionMainCategory);
            objdatabase.AddInParameter(objdbcommand, "@successCertiUrl", DbType.String, successCertiUrl);
            objdatabase.AddInParameter(objdbcommand, "@remarks", DbType.String, remarks);
            objdatabase.AddInParameter(objdbcommand, "@ipAddress", DbType.String, ipAddress);
            objdatabase.AddOutParameter(objdbcommand, "@msg", DbType.String, 200);
            string msg = ""; int recordInserted = 0;
            try
            {
                recordInserted = objdatabase.ExecuteNonQuery(objdbcommand);
                msg = (string)objdatabase.GetParameterValue(objdbcommand, "@msg");
            }
            catch (Exception ex)
            {
                msg = ex.Message.ToString();
            }
            return msg;
        }

        public DataSet getTFRUploadDetail(long applicationId)
        {
            DataSet ds = new DataSet();
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDbcommand = objDatabase.GetStoredProcCommand("Proc_getTFRDetail");
            objDatabase.AddInParameter(objDbcommand, "@applicationId", DbType.Int64, applicationId);
            try
            {
                ds = objDatabase.ExecuteDataSet(objDbcommand);
            }
            catch (Exception ex)
            {
                ds = null;
            }
            return ds;

        }

        public DataTable getDistributionMainsCategory()
        {
            DataTable dt = new DataTable();
            Database objDatabse = DatabaseFactory.CreateDatabase();
            DbCommand objDbcommand = objDatabse.GetStoredProcCommand("Proc_Get_Distribution_Mains_Category");
            try
            {
                using (IDataReader dr = objDatabse.ExecuteReader(objDbcommand))
                {
                    dt.Load(dr);
                }
            }
            catch (Exception ex)
            {
                dt = null;
            }
            return dt;
        }

        public DataTable InsertFeasibilityAndEstimationDetails(int FeederTypeId, string FeederCode, int ConnectionTypeId, string LetterReferenceNo, DateTime LetterDate, string Upload, string AreaType, decimal SystemLoadingcharge, int IndependentfeedertypeId,
           string ipAddress
          , bool IsOverHead, bool IsUnderGround, decimal OverHeadLengthLine, decimal UnderGroundLengthLine, Int64 ApplicationId, decimal TotalPaybalAmount, string RelevantDocumentURL
          , string ConnType, string RouteSeq, string Sypplycode, string CusTType, string IsSbmCust, string IsIndemnityBond, string IsOwnerConsentLetter, string SDOOffice
          , string TaxforHV, string EDEXEMPTIONFLAG, int TownId, string SecDepAmnt, string OtherAmnt, int CustClassID
          )
        {
            DataTable dt = new DataTable();
            //string _proc = "Proc_insertApplicationFeederDetails"; 
            string _proc = "proc_InsertEstimationAndFeasibility";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDbCommand = objDatabase.GetStoredProcCommand(_proc);
            objDatabase.AddInParameter(objDbCommand, "@FeederTypeId", DbType.Int32, FeederTypeId);
            objDatabase.AddInParameter(objDbCommand, "@ConnectionTypeId", DbType.Int32, ConnectionTypeId);
            objDatabase.AddInParameter(objDbCommand, "@LetterReferenceNo", DbType.String, LetterReferenceNo);
            objDatabase.AddInParameter(objDbCommand, "@LetterDate", DbType.DateTime, LetterDate);
            objDatabase.AddInParameter(objDbCommand, "@Upload", DbType.String, Upload);
            objDatabase.AddInParameter(objDbCommand, "@AreaType", DbType.String, AreaType);
            objDatabase.AddInParameter(objDbCommand, "@ConnectionPowerTypeId", DbType.Int32, 0);
            objDatabase.AddInParameter(objDbCommand, "@SystemLoadingcharge", DbType.Decimal, SystemLoadingcharge);
            objDatabase.AddInParameter(objDbCommand, "@IndependentfeedertypeId", DbType.Int32, IndependentfeedertypeId);
            objDatabase.AddInParameter(objDbCommand, "@ipAddress", DbType.String, ipAddress);
            objDatabase.AddInParameter(objDbCommand, "@IsOverHead", DbType.Boolean, IsOverHead);
            objDatabase.AddInParameter(objDbCommand, "@IsUnderGround", DbType.Boolean, IsUnderGround);
            objDatabase.AddInParameter(objDbCommand, "@OverHeadLengthLine", DbType.Decimal, OverHeadLengthLine);
            objDatabase.AddInParameter(objDbCommand, "@UnderGroundLengthLine", DbType.Decimal, UnderGroundLengthLine);
            objDatabase.AddInParameter(objDbCommand, "@ApplicationId", DbType.Int64, ApplicationId);
            objDatabase.AddInParameter(objDbCommand, "@TotalPaybalAmount", DbType.Decimal, TotalPaybalAmount);
            //objDatabase.AddInParameter(objDbCommand, "@SuccessCerurl", DbType.String, SuccSertificateUrl);
            objDatabase.AddInParameter(objDbCommand, "@RelevantDocumentUrl", DbType.String, RelevantDocumentURL);


            objDatabase.AddInParameter(objDbCommand, "@ConnType", DbType.String, ConnType ?? string.Empty);
            objDatabase.AddInParameter(objDbCommand, "@RouteSeq", DbType.String, RouteSeq ?? string.Empty);
            //objDatabase.AddInParameter(objDbCommand, "@LoadUnit", DbType.String,  string.Empty);
            objDatabase.AddInParameter(objDbCommand, "@Supplycode", DbType.String, Sypplycode ?? string.Empty);
            objDatabase.AddInParameter(objDbCommand, "@CustType", DbType.String, CusTType ?? string.Empty);
            objDatabase.AddInParameter(objDbCommand, "@IsSbmCust", DbType.String, IsSbmCust ?? string.Empty);

            objDatabase.AddInParameter(objDbCommand, "@isIndemnityBond", DbType.String, IsIndemnityBond ?? string.Empty);
            objDatabase.AddInParameter(objDbCommand, "@IsOwnerConsentLetter", DbType.String, IsOwnerConsentLetter ?? string.Empty);
            objDatabase.AddInParameter(objDbCommand, "@SDOOffice", DbType.String, SDOOffice ?? string.Empty);
            objDatabase.AddInParameter(objDbCommand, "@TaxforHV", DbType.String, TaxforHV ?? string.Empty);
            objDatabase.AddInParameter(objDbCommand, "@EDEXEMPTIONFLAG", DbType.String, EDEXEMPTIONFLAG ?? string.Empty);
            //------------------------------------------------------
            objDatabase.AddInParameter(objDbCommand, "@TownId", DbType.Int32, TownId);
            objDatabase.AddInParameter(objDbCommand, "@CustId", DbType.Int32, CustClassID);
            objDatabase.AddInParameter(objDbCommand, "@SecDepAmnt", DbType.String, SecDepAmnt ?? "0");
            objDatabase.AddInParameter(objDbCommand, "@otherAmnt", DbType.String, OtherAmnt ?? "0");
            objDatabase.AddInParameter(objDbCommand, "@FeederCode", DbType.String, FeederCode);
            try
            {
                //objDatabase.ExecuteNonQuery(objDbCommand);
                IDataReader dr = objDatabase.ExecuteReader(objDbCommand);
                dt.Load(dr);
            }
            catch (Exception ex)
            {
                dt = null;
            }
            return dt;
        }

        public DataTable getMeteringConnLastDate(long applicationId)
        {
            DataTable dt = new DataTable();
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDbcommand = objDatabase.GetStoredProcCommand("Proc_getMeteringConnLastDate");
            objDatabase.AddInParameter(objDbcommand, "@applicationId", DbType.Int64, applicationId);
            try
            {
                using (IDataReader dr = objDatabase.ExecuteReader(objDbcommand))
                {
                    dt.Load(dr);
                }
            }
            catch (Exception ex)
            {
                dt = null;
            }
            return dt;
        }

        public DataTable getBookNo(long applicationId)
        {
            DataTable dt = new DataTable();
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDbcommand = objDatabase.GetStoredProcCommand("Proc_getBookNo");
            objDatabase.AddInParameter(objDbcommand, "@applicationId", DbType.Int64, applicationId);
            try
            {
                using (IDataReader dr = objDatabase.ExecuteReader(objDbcommand))
                {
                    dt.Load(dr);
                }
            }
            catch (Exception ex)
            {
                dt = null;
            }
            return dt;

        }

        public DataTable GetSDOCodeNew(string areaType, int DivId, string userType, long applicantId)
        {
            DataTable dt = new DataTable();
            string _Proc = "Procs_GetSDOCode_New";
            Database objDatabase = DatabaseFactory.CreateDatabase();

            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                objDatabase.AddInParameter(objDBCommand, "@areaType", DbType.String, areaType);
                objDatabase.AddInParameter(objDBCommand, "@DivisionId", DbType.Int32, DivId);
                objDatabase.AddInParameter(objDBCommand, "@userType", DbType.String, userType);
                objDatabase.AddInParameter(objDBCommand, "@applicantId", DbType.Int32, applicantId);
                IDataReader dr = objDatabase.ExecuteReader(objDBCommand);
                dt.Load(dr);
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                objDBCommand.Dispose();
                objDatabase = null;
            }
            return dt;

        }

        public DataTable GetVillageAndHabitation(int procId, string divisionId, string userType, long applicationId, string villageCode)
        {
            DataTable dt = new DataTable();
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDbcommand = objDatabase.GetStoredProcCommand("proc_getVillageAndHabitation");
            try
            {
                objDatabase.AddInParameter(objDbcommand, "@procId", DbType.Int32, procId);
                objDatabase.AddInParameter(objDbcommand, "@DivisionId", DbType.String, divisionId);
                objDatabase.AddInParameter(objDbcommand, "@userType", DbType.String, userType);
                objDatabase.AddInParameter(objDbcommand, "@applicationId", DbType.Int64, applicationId);
                objDatabase.AddInParameter(objDbcommand, "@VillageCode", DbType.String, villageCode);
                IDataReader dr = objDatabase.ExecuteReader(objDbcommand);
                dt.Load(dr);
            }
            catch (Exception ex)
            {
                throw;
            }
            finally
            {
                objDbcommand.Dispose();
                objDatabase = null;
            }
            return dt;
        }

        public DataTable InsertRuralAccountNo(long applicationId, string responsMsg, string @accountNo, string ipAddress, long userId)
        {
            DataTable dt = new DataTable();
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDbCommand = objDatabase.GetStoredProcCommand("proc_InsertRuralAccountNo");
            try
            {
                objDatabase.AddInParameter(objDbCommand, "@applicationId", DbType.Int64, applicationId);
                objDatabase.AddInParameter(objDbCommand, "@responseMsg", DbType.String, responsMsg);
                objDatabase.AddInParameter(objDbCommand, "@accountNo", DbType.String, accountNo);
                objDatabase.AddInParameter(objDbCommand, "@ipAddress", DbType.String, ipAddress);
                objDatabase.AddInParameter(objDbCommand, "@userId", DbType.Int64, userId);
                using (IDataReader dr = objDatabase.ExecuteReader(objDbCommand))
                {
                    dt.Load(dr);
                }

            }
            catch (Exception ex)
            {
                objDbCommand.Dispose();
                objDatabase = null;
            }
            finally
            {
                objDbCommand.Dispose();
                objDatabase = null;
            }
            return dt;
        }


        public DataTable InsertUpdateKescoAccountNo(long applicationId, string responsMsg, string @accountNo, string ipAddress, long userId)
        {
            DataTable dt = new DataTable();
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDbCommand = objDatabase.GetStoredProcCommand("ProcInsertUpdateKescoAcccountNo");
            try
            {
                objDatabase.AddInParameter(objDbCommand, "@applicationId", DbType.Int64, applicationId);
                objDatabase.AddInParameter(objDbCommand, "@responseMsg", DbType.String, responsMsg);
                objDatabase.AddInParameter(objDbCommand, "@accountNo", DbType.String, accountNo);
                objDatabase.AddInParameter(objDbCommand, "@ipAddress", DbType.String, ipAddress);
                objDatabase.AddInParameter(objDbCommand, "@userId", DbType.Int64, userId);
                using (IDataReader dr = objDatabase.ExecuteReader(objDbCommand))
                {
                    dt.Load(dr);
                }

            }
            catch (Exception ex)
            {
                objDbCommand.Dispose();
                objDatabase = null;
            }
            finally
            {
                objDbCommand.Dispose();
                objDatabase = null;
            }
            return dt;
        }

        public DataTable getSDOTownMapping(string areaType, int sdoId)
        {
            DataTable dt = new DataTable();
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDbcommand = objDatabase.GetStoredProcCommand("Proc_GetSDOTownMapping");
            try
            {
                objDatabase.AddInParameter(objDbcommand, "@areaType", DbType.String, areaType);
                objDatabase.AddInParameter(objDbcommand, "@sdoId", DbType.Int32, sdoId);
                using (IDataReader dr = objDatabase.ExecuteReader(objDbcommand))
                {
                    dt.Load(dr);
                }
            }
            catch (Exception ex)
            {
                objDbcommand.Dispose();
                objDatabase = null;
            }
            finally
            {
                objDbcommand.Dispose();
                objDatabase = null;
            }
            return dt;
        }

        #endregion
        #region RIYA
        public DataSet getSatusReport_Pdf(int ZoneId, int CircleId, int DivisionId, DateTime? fromdate, DateTime? todate)
        {
            DataSet ds = new DataSet();
            DataTable dt = new DataTable();
            string _proc = "proc_Office_Pdf";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDbCommand = objDatabase.GetStoredProcCommand(_proc);
            objDatabase.AddInParameter(objDbCommand, "@ZoneId", DbType.Int32, ZoneId);
            objDatabase.AddInParameter(objDbCommand, "@CircleId", DbType.Int32, CircleId);
            objDatabase.AddInParameter(objDbCommand, "@DivisionId", DbType.Int32, DivisionId);
            objDatabase.AddInParameter(objDbCommand, "@FromDate", DbType.DateTime, fromdate);
            objDatabase.AddInParameter(objDbCommand, "@Todate", DbType.DateTime, todate);
            objDatabase.AddInParameter(objDbCommand, "@Action", DbType.String, "statusreport");
            try
            {
                ds = objDatabase.ExecuteDataSet(objDbCommand);
                //IDataReader dr = objDatabase.ExecuteReader(objDbCommand);
                //dt.Load(dr);
            }
            catch
            {
                ds = null;
            }
            return ds;
        }
        public DataSet GetOfficeRelesedConnectionList_Pdf(string DiscomId, string ZoneId, string circleId, string DivisionId, string applicationNo, int year)
        {
            DataSet ds = new DataSet();
            DataTable dt = new DataTable();
            string _Proc = "Proc_getOfficeReleaseConnectionList";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);

            objDatabase.AddInParameter(objDBCommand, "@DiscomId", DbType.String, DiscomId);
            objDatabase.AddInParameter(objDBCommand, "@ZoneId", DbType.String, ZoneId);
            objDatabase.AddInParameter(objDBCommand, "@circleId", DbType.String, circleId);
            objDatabase.AddInParameter(objDBCommand, "@DivisionId", DbType.String, DivisionId);
            objDatabase.AddInParameter(objDBCommand, "@applicationNo", DbType.String, applicationNo);
            objDatabase.AddInParameter(objDBCommand, "@Year", DbType.Int32, year);

            try
            {
                ds = objDatabase.ExecuteDataSet(objDBCommand);

            }
            catch
            {
                ds = null;
            }
            return ds;


        }
        public DataSet GetOfficeFeasibilConnectionList_Pdf(string DiscomId, string ZoneId, string circleId, string DivisionId, string applicationNo, int year, int Status)
        {
            DataSet ds = new DataSet();
            DataTable dt = new DataTable();
            string _Proc = "proc_getOfficeFeasibilConnectionList";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);

            objDatabase.AddInParameter(objDBCommand, "@DiscomId", DbType.String, DiscomId);
            objDatabase.AddInParameter(objDBCommand, "@ZoneId", DbType.String, ZoneId);
            objDatabase.AddInParameter(objDBCommand, "@circleId", DbType.String, circleId);
            objDatabase.AddInParameter(objDBCommand, "@DivisionId", DbType.String, DivisionId);
            objDatabase.AddInParameter(objDBCommand, "@applicationNo", DbType.String, applicationNo);
            objDatabase.AddInParameter(objDBCommand, "@Year", DbType.Int32, year);
            objDatabase.AddInParameter(objDBCommand, "@status", DbType.Int32, Status);
            try
            {
                ds = objDatabase.ExecuteDataSet(objDBCommand);

            }
            catch
            {
                ds = null;
            }
            return ds;
        }
        public DataSet getOfficeRejectedApplicationforms_Pdf(string DiscomId, string ZoneId, string circleId, string ApplicationNo, string divisionId)
        {
            DataSet ds = new DataSet();
            DataTable dt = new DataTable();

            string _Proc = "sp_getOfficeRejectedApplicationforms";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);


            objDatabase.AddInParameter(objDBCommand, "@DiscomId", DbType.String, DiscomId);
            objDatabase.AddInParameter(objDBCommand, "@ZoneId", DbType.String, ZoneId);
            objDatabase.AddInParameter(objDBCommand, "@circleId", DbType.String, circleId);
            objDatabase.AddInParameter(objDBCommand, "@ApplicationNo", DbType.String, ApplicationNo);
            objDatabase.AddInParameter(objDBCommand, "@divisionId", DbType.String, divisionId);
            try
            {
                ds = objDatabase.ExecuteDataSet(objDBCommand);

            }
            catch
            {
                ds = null;
            }
            return ds;


        }
        public DataSet GetOfficeRevenueReport_Pdf(string DiscomId, string ZoneId, string circleId, string DivisionId, string _yearNumber, string _applicationNumber, string _paymentType)
        {
            DataSet ds = new DataSet();
            DataTable dt = new DataTable();

            string _Proc = "proc_OfficeRevenueReport";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);

            objDatabase.AddInParameter(objDBCommand, "@DiscomId", DbType.String, DiscomId);
            objDatabase.AddInParameter(objDBCommand, "@ZoneId", DbType.String, ZoneId);
            objDatabase.AddInParameter(objDBCommand, "@circleId", DbType.String, circleId);
            objDatabase.AddInParameter(objDBCommand, "@DivisionId", DbType.String, DivisionId);
            objDatabase.AddInParameter(objDBCommand, "@YEAR", DbType.Int32, _yearNumber);
            objDatabase.AddInParameter(objDBCommand, "@APPLICANTNO", DbType.String, _applicationNumber);
            objDatabase.AddInParameter(objDBCommand, "@PaymentType", DbType.String, _paymentType);
            try
            {
                ds = objDatabase.ExecuteDataSet(objDBCommand);

            }
            catch
            {
                ds = null;
            }
            return ds;




        }

        #endregion

        #region Query_Aditi

        public DataTable GetQueryDetails(long applicantId)
        {
            DataTable dt = new DataTable();
            try
            {


                string proc_ = "proc_getQueryDetailbyId";
                Database objDatabase = DatabaseFactory.CreateDatabase();
                DbCommand objDbCommand = objDatabase.GetStoredProcCommand(proc_);
                objDatabase.AddInParameter(objDbCommand, "@applicationId", DbType.Int64, applicantId);
                IDataReader idr = objDatabase.ExecuteReader(objDbCommand);
                dt.Load(idr);



            }
            catch (Exception ex)
            {
                return null;
            }
            return dt;
        }

        #endregion

        #region Get Account ID
        public DataTable getAccountNumber(string areaType, long applicationId)
        {
            DataTable dt = new DataTable();
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDbcommand = objDatabase.GetStoredProcCommand("Proc_GetAccountId");
            try
            {
                objDatabase.AddInParameter(objDbcommand, "@AreaType", DbType.String, areaType);
                objDatabase.AddInParameter(objDbcommand, "@ApplicationId", DbType.Int64, applicationId);
                using (IDataReader dr = objDatabase.ExecuteReader(objDbcommand))
                {
                    dt.Load(dr);
                }
            }
            catch (Exception ex)
            {
                objDbcommand.Dispose();
                objDatabase = null;
            }
            finally
            {
                objDbcommand.Dispose();
                objDatabase = null;
            }
            return dt;
        }
        #endregion

        #region GetBookNoBySDO
        public DataTable GetBookNoBySDO(long ApplicationId, string sdooffice)
        {
            DataTable dt = new DataTable();
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDbcommand = objDatabase.GetStoredProcCommand("Proc_GetBookNoBySDO");
            try
            {
                objDatabase.AddInParameter(objDbcommand, "@ApplicationId", DbType.String, ApplicationId);
                objDatabase.AddInParameter(objDbcommand, "@sdoOffice", DbType.Int64, sdooffice);
                using (IDataReader dr = objDatabase.ExecuteReader(objDbcommand))
                {
                    dt.Load(dr);
                }
            }
            catch (Exception ex)
            {
                objDbcommand.Dispose();
                objDatabase = null;
            }
            finally
            {
                objDbcommand.Dispose();
                objDatabase = null;
            }
            return dt;

        }
        #endregion

        #region GetDiscom
        public DataTable GetDiscomByDivisionSDO(string UserType, string externaId)
        {

            DataTable dt = new DataTable();
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDbcommand = objDatabase.GetStoredProcCommand("GetDiscomByDivisionSDO");
            try
            {
                objDatabase.AddInParameter(objDbcommand, "@UserType", DbType.String, UserType);
                objDatabase.AddInParameter(objDbcommand, "@ExternalID", DbType.String, externaId);
                using (IDataReader dr = objDatabase.ExecuteReader(objDbcommand))
                {
                    dt.Load(dr);
                }
            }
            catch (Exception ex)
            {
                objDbcommand.Dispose();
                objDatabase = null;
            }
            finally
            {
                objDbcommand.Dispose();
                objDatabase = null;
            }
            return dt;
        }
        #endregion

        #region Get Supply Through
        public DataTable GetSupplyThrough(long ApplicationId, int areaType)
        {
            DataTable dt = new DataTable();
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDbcommand = objDatabase.GetStoredProcCommand("Proc_GetSupplyThrough");
            try
            {
                objDatabase.AddInParameter(objDbcommand, "@ApplicationId", DbType.Int64, ApplicationId);
                objDatabase.AddInParameter(objDbcommand, "@AreaType", DbType.Int32, areaType);
                using (IDataReader dr = objDatabase.ExecuteReader(objDbcommand))
                {
                    dt.Load(dr);
                }
            }
            catch (Exception ex)
            {
                objDbcommand.Dispose();
                objDatabase = null;
            }
            finally
            {
                objDbcommand.Dispose();
                objDatabase = null;
            }
            return dt;

        }
        #endregion

        #region GetLoad By ApplicationID
        public DataTable GetLoadByApplicationId(long ApplicationId)
        {
            DataTable dt = new DataTable();
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDbcommand = objDatabase.GetStoredProcCommand("GetLoadByApplicationId");
            try
            {

                objDatabase.AddInParameter(objDbcommand, "@ApplicationId", DbType.Int64, ApplicationId);
                using (IDataReader dr = objDatabase.ExecuteReader(objDbcommand))
                {
                    dt.Load(dr);
                }
            }
            catch (Exception ex)
            {
                objDbcommand.Dispose();
                objDatabase = null;
            }
            finally
            {
                objDbcommand.Dispose();
                objDatabase = null;
            }
            return dt;
        }
        #endregion

        #region getConsumerType
        public DataTable GetConsumerType(long ApplicationId)
        {
            DataTable dt = new DataTable();
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDbcommand = objDatabase.GetStoredProcCommand("Proc_GetConsumerType");
            try
            {
                objDatabase.AddInParameter(objDbcommand, "@ApplicationId", DbType.Int64, ApplicationId);
                using (IDataReader dr = objDatabase.ExecuteReader(objDbcommand))
                {
                    dt.Load(dr);
                }
            }
            catch (Exception ex)
            {
                objDbcommand.Dispose();
                objDatabase = null;
            }
            finally
            {
                objDbcommand.Dispose();
                objDatabase = null;
            }
            return dt;
        }
        #endregion

        #region Aditi

        public DataTable gettentativedatebyid(string DateType, string ApplicantId)
        {
            DataTable dt = new DataTable();
            string _Proc = "proc_gettentativedatebyid";
            Database objDatabase = DatabaseFactory.CreateDatabase();
            DbCommand objDBCommand = objDatabase.GetStoredProcCommand(_Proc);
            try
            {
                objDatabase.AddInParameter(objDBCommand, "@DateType", DbType.String, DateType);
                objDatabase.AddInParameter(objDBCommand, "@ApplicationId", DbType.String, ApplicantId);
                IDataReader dr = objDatabase.ExecuteReader(objDBCommand);
                dt.Load(dr);
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                objDBCommand.Dispose();
                objDatabase = null;
            }
            return dt;
        }


        #endregion
    }
}
