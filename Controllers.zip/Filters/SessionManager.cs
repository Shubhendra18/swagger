﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for SessionManager
/// </summary>
public class SessionManager
{
    public static void RemoveSession()
    {
        try
        {
            HttpContext.Current.Session.Clear();
            HttpContext.Current.Session.Abandon();
            HttpContext.Current.Session.RemoveAll();
        }
        catch
        { }
    }
       

    public static string Username
    {
        get
        {
            if (HttpContext.Current.Session["username"] != null)
            {
                return HttpContext.Current.Session["username"].ToString();
            }
            else
            {
                return null;
            }
        }
        set
        {
            HttpContext.Current.Session["username"] = value;
        }
    }

   

    public static Int64 UserID
    {
        get
        {
            if (HttpContext.Current.Session["userID"] != null)
            {
                return Convert.ToInt64(HttpContext.Current.Session["userID"].ToString());
            }
            else
            {
                return 0;
            }
        }
        set
        {
            HttpContext.Current.Session["userID"] = value;
        }
    }

    public static Int64 ApplicantId
    {
        get
        {
            if (HttpContext.Current.Session["ApplicantId"] != null)
            {
                return Convert.ToInt64(HttpContext.Current.Session["ApplicantId"].ToString());
            }
            else
            {
                return 0;
            }
        }
        set
        {
            HttpContext.Current.Session["ApplicantId"] = value;
        }
    }

    public static string RoleID
    {
        get
        {
            if (HttpContext.Current.Session["roleID"] != null)
            {
                return (HttpContext.Current.Session["roleID"]).ToString();
            }
            else
            {
                return "";
            }
        }
        set
        {
            HttpContext.Current.Session["roleID"] = value;
        }
    }

    public static string ExternalUserId
    {
        get
        {
            if (HttpContext.Current.Session["ExternalUserId"] != null)
            {
                return Convert.ToString(HttpContext.Current.Session["ExternalUserId"].ToString());
            }
            else
            {
                return "0";
            }
        }
        set
        {
            HttpContext.Current.Session["ExternalUserId"] = value;
        }
    }
    public static bool Descom1912
    {
        get
        {
            if (HttpContext.Current.Session["Descom1912"] != null)
            {
                return Convert.ToBoolean(HttpContext.Current.Session["Descom1912"].ToString());
            }
            else
            {
                return false;
            }
        }
        set
        {
            HttpContext.Current.Session["Descom1912"] = value;
        }
    }
    public static string DisplayName
    {
        get
        {
            if (HttpContext.Current.Session["displayName"] != null)
            {
                return HttpContext.Current.Session["displayName"].ToString();
            }
            else
            {
                return null;
            }
        }
        set
        {
            HttpContext.Current.Session["displayName"] = value;
        }
    }

    public static Int32 TempAppid
    {
        get
        {
            if (HttpContext.Current.Session["TempAppid"] != null)
            {
                return Convert.ToInt32(HttpContext.Current.Session["TempAppid"]);
            }
            else
            {
                return 0;
            }
        }
        set
        {
            HttpContext.Current.Session["TempAppid"] = value;
        }
    }

    public static string ProfilePic
    {
        get
        {
            if (HttpContext.Current.Session["ProfilePic"] != null)
            {
                return HttpContext.Current.Session["ProfilePic"].ToString();
            }
            else
            {
                return null;
            }
        }
        set
        {
            HttpContext.Current.Session["ProfilePic"] = value;
        }
    }

    public static bool isOuterRequest
    {
        get
        {
            if (HttpContext.Current.Session["SESisOuterRequest"] != null)
            {
                return Convert.ToBoolean(HttpContext.Current.Session["SESisOuterRequest"]);
            }
            else
            {
                return false;
            }
        }
        set
        {
            HttpContext.Current.Session["SESisOuterRequest"] = value;
        }
    }

    public static string ControlID
    {
        get
        {
            if (HttpContext.Current.Session["sesControlID"] != null)
            {
                return HttpContext.Current.Session["sesControlID"].ToString();
            }
            else
            {
                return null;
            }
        }
        set
        {
            HttpContext.Current.Session["sesControlID"] = value;
        }
    }

    public static string UnitID
    {
        get
        {
            if (HttpContext.Current.Session["sesUnitID"] != null)
            {
                return HttpContext.Current.Session["sesUnitID"].ToString();
            }
            else
            {
                return null;
            }
        }
        set
        {
            HttpContext.Current.Session["sesUnitID"] = value;
        }
    }
    
    public static string ServiceID
    {
        get
        {
            if (HttpContext.Current.Session["sesServiceID"] != null)
            {
                return HttpContext.Current.Session["sesServiceID"].ToString();
            }
            else
            {
                return null;
            }
        }
        set
        {
            HttpContext.Current.Session["sesServiceID"] = value;
        }
    }

    public static string ProcessIndustryID
    {
        get
        {
            if (HttpContext.Current.Session["sesProcessIndustryID"] != null)
            {
                return HttpContext.Current.Session["sesProcessIndustryID"].ToString();
            }
            else
            {
                return null;
            }
        }
        set
        {
            HttpContext.Current.Session["sesProcessIndustryID"] = value;
        }
    }

    public static string passsalt
    {
        get
        {
            if (HttpContext.Current.Session["sespasssalt"] != null)
            {
                return HttpContext.Current.Session["sespasssalt"].ToString();
            }
            else
            {
                return null;
            }
        }
        set
        {
            HttpContext.Current.Session["sespasssalt"] = value;
        }
    }

    public static string ApplicationNo
    {
        get
        {
            if (HttpContext.Current.Session["sesApplicationNo"] != null)
            {
                return HttpContext.Current.Session["sesApplicationNo"].ToString();
            }
            else
            {
                return null;
            }
        }
        set
        {
            HttpContext.Current.Session["sesApplicationNo"] = value;
        }
    }


    public static string userType
    {
        get
        {
            if (HttpContext.Current.Session["userType"] != null)
            {
                return HttpContext.Current.Session["userType"].ToString();
            }
            else
            {
                return null;
            }
        }
        set
        {
            HttpContext.Current.Session["userType"] = value;
        }
    }

    #region Aditi
    public static string MobileNo
    {
        get
        {
            if (HttpContext.Current.Session["MobileNo"] != null)
            {
                return HttpContext.Current.Session["MobileNo"].ToString();
            }
            else
            {
                return null;
            }
        }
        set
        {
            HttpContext.Current.Session["MobileNo"] = value;
        }
    } 
    #endregion

    public static string AppRequestKey
    {
        get
        {
            if (HttpContext.Current.Session["AppRequestKey"] != null)
            {
                return HttpContext.Current.Session["AppRequestKey"].ToString();
            }
            else
            {
                return null;
            }
        }
        set
        {
            HttpContext.Current.Session["AppRequestKey"] = value;
        }
    }

    public static string DiscomId
    {
        get
        {
            if (HttpContext.Current.Session["DiscomId"] != null)
            {
                return HttpContext.Current.Session["DiscomId"].ToString();
            }
            else
            {
                return null;
            }
        }
        set
        {
            HttpContext.Current.Session["DiscomId"] = value;
        }
    }
}