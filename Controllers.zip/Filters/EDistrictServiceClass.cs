﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.IO;
using System.Xml;
using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;

namespace UPPCL_WebAPI.Filters
{
    public class EDistrictServiceClass
    {
        string Application_Number = "", Service_Code = "", returnres = "", username = "";
        public static string DepartmentRegistrationID = "64D493ACEC0A30FE21DE676344D4B804";
        Common objcommdb = new Common();
        public bool sendServiceRequest(string RequestKey)
        {

            ServiceModel sm = new ServiceModel();
            sm.requestKey = RequestKey;
            sm.deptRegistrationId = EDistrictServiceClass.DepartmentRegistrationID;
            sm.transIp = Common.GetIPAddress();
            try
            {
                //EDistrictService.Service objSvc = new EDistrictService.Service();
               // string resXML = objSvc.SendRequest(RequestKey, EDistrictServiceClass.DepartmentRegistrationID);
               // sm.serviceResponse = resXML;
               // XmlDocument myXML = new XmlDocument();
                //myXML.LoadXml(resXML);
                //returnres = myXML.GetElementsByTagName("ReturnType")[0].InnerText;
                if (returnres == "Success")
                {
                    //username = myXML.GetElementsByTagName("UserName")[0].InnerText;
                    objcommdb.InsertSendRequest(sm.requestKey, sm.deptRegistrationId, sm.serviceResponse, sm.transIp);
                    return true;
                }
                else
                {
                    objcommdb.InsertSendRequest(sm.requestKey, sm.deptRegistrationId, sm.serviceResponse, sm.transIp);
                    return false;

                }
            }
            catch (Exception ex)
            {


                sm.serviceResponse = sm.serviceResponse + "_" + ex.Message;

                objcommdb.InsertSendRequest(sm.requestKey, sm.deptRegistrationId, sm.serviceResponse, sm.transIp);

                return false;
            }
        }


        public bool postServiceResponse(string RequestKey, string ApplicationNo, string ServiceCode, string ApplicationType)
        {

            ServiceModel sm = new ServiceModel();
            sm.requestKey = RequestKey;
            sm.deptRegistrationId = EDistrictServiceClass.DepartmentRegistrationID;
            sm.transIp = Common.GetIPAddress();
            sm.applicationNumber = ApplicationNo;
            sm.serviceCode = ServiceCode;
            sm.applicationType = ApplicationType;

            try
            {
                //EDistrictService.Service objSvc = new EDistrictService.Service();
                //string resXML = objSvc.SendResponse(RequestKey, EDistrictServiceClass.DepartmentRegistrationID, ApplicationNo, ServiceCode);
                //sm.serviceResponse = resXML;
                //XmlDocument myXML = new XmlDocument();
                //myXML.LoadXml(resXML);
                //returnres = myXML.GetElementsByTagName("ReturnType")[0].InnerText;

                //if (returnres == "1")
                //{

                //    objcommdb.InsertSendResponse(sm.requestKey, sm.deptRegistrationId, sm.serviceResponse, sm.applicationNumber, sm.serviceCode, sm.applicationNumber, sm.transIp);
                //    return true;

                //}
                //else
                //{
                //    objcommdb.InsertSendResponse(sm.requestKey, sm.deptRegistrationId, sm.serviceResponse, sm.applicationNumber, sm.serviceCode, sm.applicationNumber, sm.transIp);
                //    return false;

                //}
            return false;
            }
            catch (Exception ex)
            {
                sm.serviceResponse = sm.serviceResponse + "_" + ex.Message;
                objcommdb.InsertSendResponse(sm.requestKey, sm.deptRegistrationId, sm.serviceResponse, sm.applicationNumber, sm.serviceCode, sm.applicationNumber, sm.transIp);
                return false;
            }
        }
    }

    public enum EDistrict_ServiceCode
    {
        EP = 13401
        //,OD = 13401,
        //SY = 13402,
        //SD = 13404,
        //KM = 13403
    }    
}